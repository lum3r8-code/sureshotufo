const fs = require('fs');
let code = fs.readFileSync('src/components/LiveInnovationRadar.tsx', 'utf8');

const s3 = `<div className="flex flex-col gap-2 border-b border-slate-850 pb-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 flex-wrap">
                    <span className={\`px-2 py-0.5 text-[10px] rounded-md font-bold border font-mono \${
                      isVip ? 'bg-purple-950/60 text-purple-300 border-purple-500/40' :
                      isBot ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40' :
                      isInd ? 'bg-amber-950/60 text-amber-300 border-amber-500/40' :
                      isAi ? 'bg-fuchsia-950/60 text-fuchsia-300 border-fuchsia-500/40' :
                      'bg-indigo-950/60 text-indigo-300 border-indigo-500/40'
                    }\`}>
                      {item.categoryLabel}
                    </span>
                    {isNewItem && (
                      <span className="px-1.5 py-0.5 text-[9px] rounded-md font-bold bg-fuchsia-950 text-fuchsia-300 border border-fuchsia-500/50 animate-pulse">
                        جديد 2026 🔥
                      </span>
                    )}
                    <span className="text-[10px] text-slate-500 font-mono truncate max-w-[120px]" title={item.source}>
                      {item.source}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 w-full mt-1.5 mb-1 bg-slate-900/60 p-1.5 rounded border border-slate-800">
                    <span className="text-cyan-400 text-[10px] font-bold">⏱️ توقيت الرصد (مباشر):</span>
                    <span className="text-slate-300 text-[10px] font-mono tracking-tighter" style={{ direction: 'ltr', display: 'inline-block' }}>
                      {item.timestamp || 'جاري المزامنة...'}
                    </span>
                  </div>
                  <span className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-500/30 font-bold whitespace-nowrap">
                    <CheckCircle className="w-3 h-3 text-emerald-400" />
                    <span>مدمج بالمحرك: {item.verifiedWinRate}</span>
                  </span>
                </div>`;

const r3 = `<div className="flex flex-col gap-2 border-b border-slate-850 pb-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className={\`px-2 py-0.5 text-[10px] rounded-md font-bold border font-mono \${
                        isVip ? 'bg-purple-950/60 text-purple-300 border-purple-500/40' :
                        isBot ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40' :
                        isInd ? 'bg-amber-950/60 text-amber-300 border-amber-500/40' :
                        isAi ? 'bg-fuchsia-950/60 text-fuchsia-300 border-fuchsia-500/40' :
                        'bg-indigo-950/60 text-indigo-300 border-indigo-500/40'
                      }\`}>
                        {item.categoryLabel}
                      </span>
                      {isNewItem && (
                        <span className="px-1.5 py-0.5 text-[9px] rounded-md font-bold bg-fuchsia-950 text-fuchsia-300 border border-fuchsia-500/50 animate-pulse">
                          جديد 2026 🔥
                        </span>
                      )}
                      <span className="text-[10px] text-slate-500 font-mono truncate max-w-[120px]" title={item.source}>
                        {item.source}
                      </span>
                    </div>
                    <span className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-500/30 font-bold whitespace-nowrap">
                      <CheckCircle className="w-3 h-3 text-emerald-400" />
                      <span>مدمج بالمحرك: {item.verifiedWinRate}</span>
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 w-full mt-1.5 mb-1 bg-slate-900/60 p-1.5 rounded border border-slate-800">
                    <span className="text-cyan-400 text-[10px] font-bold">⏱️ توقيت الرصد والاختراق (مباشر):</span>
                    <span className="text-slate-300 text-[10px] font-mono tracking-tighter" style={{ direction: 'ltr', display: 'inline-block' }}>
                      {item.timestamp || 'جاري المزامنة...'}
                    </span>
                  </div>
                </div>`;

code = code.replace(s3, r3);
fs.writeFileSync('src/components/LiveInnovationRadar.tsx', code);
console.log('patched divs');
