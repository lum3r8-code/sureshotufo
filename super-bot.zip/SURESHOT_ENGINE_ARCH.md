# 🚀 SURESHOT ROCKET & EXECUTIVE INST-SUITE: UNIVERSAL SOVEREIGN KERNEL ARCHITECTURE
**المخطط الهندسي الشامل والوثيقة السيادية العبقرية لكامل المنظومة - مصمم للذكاء الاصطناعي والتنفيذ المستقل السلس**

---

## 🌟 MASTER ARCHITECTURAL PHILOSOPHY / فلسفة النظام الموحد
This document serves as the **Absolute Universal AI-Readable Blueprint** for the entire trading, financial, and administrative application. It catalogs, defines, and maps **every single component, file, database schema, and mathematical algorithm** in this ecosystem. 

Whether it is the core execution engines, the Undercover Agent system, the financial interfaces, or the advanced arbitrage and security systems, this manifest provides a cohesive, unified structure enabling any future AI to instantly parse, understand, and transplant the entire platform cleanly to any server without missing a single feature.

تم إعداد هذا المخطط ليكون **المرجع السيادي الهيكلي الكامل لكافة مكونات المنظومة**. لا يقتصر المخطط على محرك التداول أو العميل السري فحسب، بل يجمع ويوثق **كل ملف، واجهة مستخدم، قاعدة بيانات، ومفهوم برمجي** داخل نظامك لضمان سهولة كشفه برمجياً وفهمه كجسد واحد ملتحم غير مفكك.

---

## 🗺️ FULL COMPONENT DIRECTORY / الدليل الشامل لجميع الملفات والواجهات

### 1️⃣ Core Services & Computational Engines (الخدمات ومحركات الحساب)
| File Path / مسار الملف | Component Name / المكون | Mathematical & Technical Logic / الدور الرياضي والفني |
| :--- | :--- | :--- |
| `/server.ts` | **The Core Backend Server** | يضم خوارزمية التوافق السباعي (7-Layer Confluence)، ومحاكاة مونت كارلو الكمية، وإدارة مسارات الاقتصاد الكلي وجدول التحقق من فتح وإغلاق الأسواق. |
| `/src/services/telegramBot.ts` | **Telegram Sentinel Bot** | يتحكم في بث الإشارات، تشفير المحتوى وحمايته من النسخ والتسريب، والتنبؤ بمخاطر كيلي، وجدولة الحذف التلقائي بعد 24 ساعة. |
| `/src/services/chartCardRenderer.ts` | **GRS Visual Engine** | الرسام الذكي الذي يولد بطاقات الشارت والمؤشرات بصيغة PNG مباشرة من الذاكرة لضمان الحصرية الكاملة. |
| `/src/services/sulionCupData.ts` | **System State & Schema** | يدير هياكل المفاتيح، والتحقق المالي من المعاملات، واشتراكات الـ VIP. |
| `/src/services/sulionCupSelfHealingEngine.ts`| **Sovereign Self-Healing Engine** | محرك الإصلاح التلقائي الذي يراقب تراجع الأداء ويعيد هيكلة ثغرات الصفقات لحظر تكرار الخسارة. |

---

### 2️⃣ The Executive UI Suite / كافة مكونات واجهة المستخدم التفاعلية (`src/components/`)
تتكامل هذه المكونات مع لوحة التحكم الرئيسية وتتصل بالباكيند وقواعد البيانات لتقديم نظام متناسق:

| File Path / مسار الملف | Component Name / المكون | UI & Functional Purpose / الوظيفة التفاعلية والعملية |
| :--- | :--- | :--- |
| `UndercoverAgentLab.tsx` | **Undercover Agent Lab** | مختبر العميل السري لمراقبة الخادم، ضبط معاملات الدخول، ومراقبة الـ KPIs وإحصائيات الفيدباك الحي من المشتركين. |
| `LiveArbitrageMonitor.tsx` | **Live Arbitrage Monitor** | شاشة رصد فروق الأسعار والفرص التحكيمية اللحظية بين البنوك والمنصات (Arbitrage). |
| `WhaleTrackerPanel.tsx` | **Whale Flow Tracker** | رادار تتبع حركات الحيتان وتدفق السيولة البنكية الكبرى وجدران التسييل (Spoof Walls). |
| `TacticalStrikeMatrix.tsx` | **Tactical Strike Matrix** | مصفوفة قناص التوقيت الدقيق (:03s Tactical Delay) لرصد ذيول الشموع وتجاوز تلاعب البروكرز. |
| `LiveInnovationRadar.tsx` | **Live Innovation & Tech Radar** | رادار تتبع الابتكارات وفك تشفير الـ VIP Bots والسكريبتات المحقونة وتسريب مفاتيحها ومصادرها. |
| `DeviceAuthorizationGate.tsx` | **Device Auth Gate** | بوابة الأمان والتحقق من هوية وأجهزة المشتركين المعتمدين لمنع تسريب الحسابات. |
| `GovernorPanel.tsx` | **AI Governor Panel** | لوحة الحوكمة والتحكم في قرارات البوت وقفل الحسابات واستدعاء سجلات النظام. |
| `SandboxConsole.tsx` | **Interactive Sandbox** | الكونسول التفاعلي لاختبار الأكواد والسكريبتات وتجربة خوارزميات التداول حياً. |
| `HighImpactNewsModal.tsx` | **OSINT News Shield** | شاشة رصد الأخبار الاقتصادية العنيفة والتحكم في مفتاح القفل التلقائي (Kill-Switch). |
| `MarketVsSystemPowerChart.tsx`| **Market vs System Power** | شارت D3 / Recharts لمقارنة قوة خوارزميات النظام ضد اتجاه تقلبات السوق الفعلي. |
| `BillingModal.tsx` | **Billing & Subscription Hub** | نظام الفوترة الرقمي لتفعيل اشتراكات المشتركين عبر نجوم تيليجرام أو الدفع المباشر. |
| `KeyManager.tsx` | **SaaS License Key Manager** | إدارة وترخيص وبيع مفاتيح الوصول الرقمية وتتبع فترات الصلاحية وتفعيلها. |
| `QueryLogsTable.tsx` | **API Query Auditor** | مراقبة حية لكافة الطلبات الواردة إلى خادم الباكيند لكشف محاولات الهجوم أو المسح العشوائي. |
| `TelegramWebhooksPortal.tsx` | **Telegram Webhook Portal** | واجهة إدارة وتحديث مسارات الـ Webhooks لتيليجرام لضمان استقرار الاتصال اللحظي. |
| `PayoutPanel.tsx` | **Financial Payouts Panel** | منصة تسوية الحسابات المالية، تتبع الأرباح، والتحويلات الداخلية للشبكة المفتوحة. |
| `SulionCupModal.tsx` | **VIP Elite Tournament Suite** | لوحة المسابقات الحصرية والبطولات الرقمية المخصصة لتنشيط وتفاعل مجتمع التداول. |
| `VipForexSignalModal.tsx` & `Notification.tsx` | **Signal HUD & Popups** | نوافذ التنبيهات الفورية وبطاقات الإشارات التفاعلية المنبثقة داخل التطبيق حياً. |
| `MetricsGrid.tsx` & `Header.tsx` | **Dashboard Framework** | الهيكل الحاكم للوحة التحليلات الرئيسية، العدادات الرقمية، والتبديل بين غرف العمليات. |
| `DefjayRadio.tsx` | **Elite Ambient Synth** | راديو الأجواء المحيطية ومولد النبضات السمعية لمساعدة المتداولين على التركيز وتخفيف التوتر. |

---

## 🧬 DETAILED MATHEMATICAL & AI ENGINES / الخوارزميات والمعادلات الرياضية الأساسية

### 1️⃣ Quantum Monte Carlo Path Engine (محاكاة مونت كارلو بـ 15 مساراً)
يتم حساب احتمالية اتجاه السعر المستقبلي من خلال محاكاة 15 مساراً حركياً بالتوازي بناءً على معدل التقلب اللحظي وزخم الماكد:
```typescript
// Core logic executed for every candle calculation
const simulatedPaths = 15;
let bullishPaths = 0;
const volatilityRatio = currentVolatility / (spotPrice || 1);
const seed = Math.cos(Date.now() / 1000);

for (let i = 0; i < simulatedPaths; i++) {
  // Monte Carlo standard dynamic motion formula
  const movement = seed * 0.04 + (macdHistogram * 60) + (Math.sin(i * 1.3) * volatilityRatio);
  if (movement > 0) bullishPaths++;
}
const isConvergedBullish = bullishPaths >= 9; // Majority consensus
```

### 2️⃣ Kelly Criterion Allocation (معادلة حجم الصفقة وإدارة المخاطر)
تجنب الخسائر الكارثية عبر تحديد النسبة المئوية الدقيقة والمضمونة للدخول من حجم المحفظة:
$$f^* = \frac{p \cdot (b + 1) - 1}{b}$$
حيث أن:
* $p$: احتمالية دقة الإشارة من محرك الـ Confluence (مثال: 0.95).
* $b$: نسبة ربح البروكر للصفقة (مثال: 0.85).
* $f^*$: النسبة المقترحة لتخصيص رأس المال.

---

## 🗄️ PERSISTENT DATABASE SCHEMAS / هياكل البيانات السحابية (Firestore Blueprint)
يتصل المحرك وكافة مكونات واجهة المستخدم بقاعدة بيانات **Firestore** مركزية وموحدة لضمان حفظ واستمرار البيانات دون فقدان:

```json
{
  "saasKeys": {
    "id": "string (مفتاح الترخيص)",
    "allowedChatId": "number (رقم الشات المرتبط)",
    "expiresAt": "timestamp",
    "isVip": "boolean"
  },
  "saasUsers": {
    "chatId": "number (المعرف الرقمي)",
    "username": "string",
    "signalCount": "number",
    "isBlocked": "boolean"
  },
  "governorLogs": {
    "id": "string",
    "timestamp": "timestamp",
    "actionType": "string (نوع قرار الحوكمة التلقائي)",
    "reason": "string",
    "successRate": "number"
  },
  "queryLogs": {
    "id": "string",
    "timestamp": "timestamp",
    "ip": "string",
    "path": "string (المسار المطلوب)"
  },
  "systemSettings": {
    "doc('payout')": { "minPayout": "number", "enabled": "boolean" },
    "doc('appAnalytics')": { "totalRequests": "number", "serverUptime": "number" }
  }
}
```

---

## ⚡ SECURITY & ANTI-LEAK MECHANISMS / التحصينات ومقاومة الاختراق والتسريب

1. **التبخر الذاتي (Auto-Erasure):** 
   - محرك البحث الذكي `cleanupExpiredSentSignals` يمسح كافة الصور وملحقات الإشارات المرسلة من خوادم وقنوات المشتركين بمجرد تجاوز عمرها **24 ساعة** لتطهير البيئة وحفظ السرية التامة.
2. **الدرع المانع للنسخ (Anti-Forward Protection):**
   - ترسل كافة إشارات ومستندات وصور الـ **GRS** التفاعلية مفعلة بخيار `protect_content: true` لحظر تفعيل خيارات النسخ، التوجيه، أو لقطات الشاشة.
3. **مفتاح القفل الذكي (OSINT News Kill-Switch):**
   - بمجرد تحسس أي خبر اقتصادي فائق الخطورة، يتم إيقاف الإشارات أوتوماتيكياً وتحصين محافظ الأعضاء من الإبادة السعرية.

---

## 🛠️ HOW TO DEPLOY / طريقة النقل وإعادة التشغيل الفوري
لترحيل هذه المنظومة بالكامل، تحتاج فقط إلى نسخ المجلدات التالية إلى خادمك الجديد:
- المجلد الرئيسي `/src` (يحتوي على كافة الـ Components والـ Services).
- الملف الرئيسي `/server.ts` (الباكيند والـ API الرئيسي والمحاكاة).
- ملفات الإعدادات: `package.json` و `.env.example`.

قم بتهيئة المتغيرات البيئية ثم أطلق الأمر الموحد للتشغيل:
```bash
npm install
npm run build
npm run dev
```

**نحو الأفضل والأضمن بكل إنضباط - دائماً وأبداً لسيادة التداول الكمي العبقري.**
