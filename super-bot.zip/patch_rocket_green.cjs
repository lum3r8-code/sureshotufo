const fs = require('fs');

const appFile = fs.readFileSync('src/App.tsx', 'utf8');

// 1. Update QuantumGlisteningEmblem Props
let updatedFile = appFile.replace(
`export const QuantumGlisteningEmblem = React.memo(function QuantumGlisteningEmblem({
  size = "md",
  className = ""
}: {
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}) {`,
`export const QuantumGlisteningEmblem = React.memo(function QuantumGlisteningEmblem({
  size = "md",
  className = "",
  isSafeMarket = false
}: {
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
  isSafeMarket?: boolean;
}) {`
);

// 2. Update Sparkles
updatedFile = updatedFile.replace(
`<span className="ruby-sparkle-1 text-rose-200 absolute -top-3 -right-3 text-sm pointer-events-none z-20">`,
`<span className={\`ruby-sparkle-1 \${isSafeMarket ? 'text-emerald-200' : 'text-rose-200'} absolute -top-3 -right-3 text-sm pointer-events-none z-20\`}>`
);
updatedFile = updatedFile.replace(
`<span className="ruby-sparkle-3 text-rose-300 absolute top-0 -left-3 text-[10px] pointer-events-none z-20">`,
`<span className={\`ruby-sparkle-3 \${isSafeMarket ? 'text-emerald-300' : 'text-rose-300'} absolute top-0 -left-3 text-[10px] pointer-events-none z-20\`}>`
);

// 3. Update SVG drop-shadow
updatedFile = updatedFile.replace(
`className={\`\${dim} relative z-10 overflow-visible drop-shadow-[0_4px_16px_rgba(225,29,72,0.45)]\`}`,
`className={\`\${dim} relative z-10 overflow-visible \${isSafeMarket ? 'drop-shadow-[0_4px_16px_rgba(16,185,129,0.45)]' : 'drop-shadow-[0_4px_16px_rgba(225,29,72,0.45)]'}\`}`
);

// 4. Update SVG gradient colors
updatedFile = updatedFile.replace(
`<radialGradient id="rubyTargetRed" cx="38%" cy="32%" r="68%">
            <stop offset="0%" stopColor="#ff4d79" />
            <stop offset="35%" stopColor="#f43f5e" />
            <stop offset="70%" stopColor="#be123c" />
            <stop offset="100%" stopColor="#880825" />
          </radialGradient>`,
`<radialGradient id="rubyTargetRed" cx="38%" cy="32%" r="68%">
            <stop offset="0%" stopColor={isSafeMarket ? "#34d399" : "#ff4d79"} />
            <stop offset="35%" stopColor={isSafeMarket ? "#10b981" : "#f43f5e"} />
            <stop offset="70%" stopColor={isSafeMarket ? "#059669" : "#be123c"} />
            <stop offset="100%" stopColor={isSafeMarket ? "#064e3b" : "#880825"} />
          </radialGradient>`
);

// 5. Inject isSelectedPairSafe in App
const safeMarketLogic = `
  const isSelectedPairSafe = useMemo(() => {
    if (!selectedPair) return false;
    if (isSelectedPairMarketClosed) return false;
    const hasNews = !!(selectedPair.realIndicators?.hasHighImpactNews || (selectedPair as any).osintData?.hasHighImpactNews);
    const isStag = !!(selectedPair.realIndicators?.isStagnantLiquidity || (selectedPair as any).osintData?.isStagnantLiquidity);
    const isVolatile = !!(
      selectedPair.realIndicators?.isAtypicalVolatility ||
      selectedPair.realIndicators?.isHighlyVolatile ||
      (selectedPair as any).vulnerabilityData?.isAtypicalVolatility ||
      (selectedPair as any).vulnerabilityData?.isHighlyVolatile ||
      (selectedPair as any).osintData?.isAtypicalVolatility
    );
    const conf = selectedPair.confidence || 0;
    return !hasNews && !isStag && !isVolatile && conf >= 85.0;
  }, [selectedPair, isSelectedPairMarketClosed]);
`;

updatedFile = updatedFile.replace(
  `  const bestRecommendedPair = useMemo(() => {`,
  safeMarketLogic + `\n  const bestRecommendedPair = useMemo(() => {`
);

// 6. Update the usage in the Dashboard header
updatedFile = updatedFile.replace(
`              title="انقر لعرض البدائل الاحترافية لشارات TradingView في حالة الطوارئ 📊"
            >
              <QuantumGlisteningEmblem size="md" />
            </button>`,
`              title="انقر لعرض البدائل الاحترافية لشارات TradingView في حالة الطوارئ 📊"
            >
              <QuantumGlisteningEmblem size="md" isSafeMarket={isSelectedPairSafe} />
            </button>`
);


fs.writeFileSync('src/App.tsx', updatedFile, 'utf8');
console.log('App.tsx patched for Safe Market Green Rocket!');
