const fs = require('fs');

let server = fs.readFileSync('server.ts', 'utf8');

server = server.replace(/import \{ getApps, initializeApp \} from 'firebase-admin\/app';/, "import { getApps, initializeApp } from 'firebase/app';");
server = server.replace(/import \{ getFirestore, Firestore \} from 'firebase-admin\/firestore';/, "import { getFirestore, Firestore, collection, doc, setDoc, getDoc, getDocs, deleteDoc, query, orderBy, limit } from 'firebase/firestore';");

// Replace simple get: await db.collection('xyz').get()
server = server.replace(/await db\.collection\('([^']+)'\)\.get\(\)/g, "await getDocs(collection(db, '$1'))");

// Replace ordered get: await db.collection('xyz').orderBy('time', 'desc').get()
server = server.replace(/await db\.collection\('([^']+)'\)\.orderBy\('([^']+)',\s*'([^']+)'\)\.get\(\)/g, "await getDocs(query(collection(db, '$1'), orderBy('$2', '$3')))");

// Replace ordered limit get: await db.collection('xyz').orderBy('time', 'desc').limit(50).get()
server = server.replace(/await db\.collection\('([^']+)'\)\.orderBy\('([^']+)',\s*'([^']+)'\)\.limit\((\d+)\)\.get\(\)/g, "await getDocs(query(collection(db, '$1'), orderBy('$2', '$3'), limit($4)))");

// Replace set: await db.collection('xyz').doc(a).set(b)
server = server.replace(/await db\.collection\('([^']+)'\)\.doc\(([^)]+)\)\.set\(([\s\S]*?)\);/g, (match, col, docId, payload) => {
    // If payload has unclosed parens or something it might fail, but let's try a simpler regex
    return `await setDoc(doc(db, '${col}', ${docId}), ${payload});`;
});

// Replace get doc: await db.collection('xyz').doc(a).get()
server = server.replace(/await db\.collection\('([^']+)'\)\.doc\(([^)]+)\)\.get\(\)/g, "await getDoc(doc(db, '$1', $2))");

// Replace delete: await db.collection('xyz').doc(a).delete()
server = server.replace(/await db\.collection\('([^']+)'\)\.doc\(([^)]+)\)\.delete\(\)/g, "await deleteDoc(doc(db, '$1', $2))");

fs.writeFileSync('server.ts', server);

let tg = fs.readFileSync('src/services/telegramBot.ts', 'utf8');

tg = tg.replace(/await firestoreDb\.collection\('([^']+)'\)\.get\(\)/g, "await require('firebase/firestore').getDocs(require('firebase/firestore').collection(firestoreDb, '$1'))");

tg = tg.replace(/await firestoreDb\.collection\('([^']+)'\)\.doc\(([^)]+)\)\.set\(([^)]+)\);/g, "await require('firebase/firestore').setDoc(require('firebase/firestore').doc(firestoreDb, '$1', $2), $3);");

fs.writeFileSync('src/services/telegramBot.ts', tg);

console.log('Fixed');
