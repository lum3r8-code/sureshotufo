const fs = require('fs');

const file = 'src/App.tsx';
let appFile = fs.readFileSync(file, 'utf8');

appFile = appFile.replace(
  /إشارة مشكوك فيها • احتمال خسارة عالية/g,
  'إشارة غير صالحة ❌ SURESHOT ROCKET'
);

appFile = appFile.replace(
  /انقر لفتح تفاصيل الإشارة وسببها وتوقيت الدخول/g,
  'انقر لفتح تفاصيل إشارة SURESHOT ROCKET'
);

appFile = appFile.replace(
  /تحذير: تذبذب سعري غير نمطي \/ إشارة غير مؤكدة/g,
  'تحذير: إشارة SURESHOT ROCKET غير مؤكدة'
);

appFile = appFile.replace(
  /تسجيل إشارة صحيحة ناجحة وتأكيد ثبات المعاملات/g,
  'تسجيل إشارة SURESHOT ROCKET ناجحة'
);

appFile = appFile.replace(
  /تسجيل إشارة خاطئة لتشريح الثغرة وتوليد نافذة الحل العبقري المنبثقة فوراً/g,
  'تسجيل إشارة خاطئة لتشريح ثغرة SURESHOT ROCKET'
);

appFile = appFile.replace(
  /تم فحص 100 إشارة مطابقة سابقة/g,
  'تم فحص 100 إشارة SURESHOT ROCKET مطابقة سابقة'
);

appFile = appFile.replace(
  /رصد ثغرة في إشارة خاسرة \(Losing Signal Exploit\)/g,
  'رصد ثغرة في إشارة SURESHOT ROCKET خاسرة'
);


fs.writeFileSync(file, appFile, 'utf8');
console.log('patched app ui');
