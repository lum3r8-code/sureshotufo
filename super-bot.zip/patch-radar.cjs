const fs = require('fs');
let code = fs.readFileSync('src/components/LiveInnovationRadar.tsx', 'utf8');

// We want to insert the timestamp display right under the source.
// Find:
/*
                    <span className="text-[10px] text-slate-500 font-mono truncate max-w-[120px]" title={item.source}>
                      {item.source}
                    </span>
                  </div>
                  <span className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-500/30 font-bold whitespace-nowrap">
*/

const searchStr = `<span className="text-[10px] text-slate-500 font-mono truncate max-w-[120px]" title={item.source}>
                      {item.source}
                    </span>
                  </div>`;

const replaceStr = `<span className="text-[10px] text-slate-500 font-mono truncate max-w-[120px]" title={item.source}>
                      {item.source}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 w-full mt-1.5 mb-1 bg-slate-900/60 p-1.5 rounded border border-slate-800">
                    <span className="text-cyan-400 text-[10px] font-bold">⏱️ توقيت الرصد (مباشر):</span>
                    <span className="text-slate-300 text-[10px] font-mono tracking-tighter" style={{ direction: 'ltr', display: 'inline-block' }}>
                      {item.timestamp || 'جاري المزامنة...'}
                    </span>
                  </div>`;

if(code.includes(searchStr)) {
    code = code.replace(searchStr, replaceStr);
    fs.writeFileSync('src/components/LiveInnovationRadar.tsx', code);
    console.log("Patched successfully");
} else {
    console.log("Could not find search string");
}
