const fs = require('fs');
let code = fs.readFileSync('src/components/LiveInnovationRadar.tsx', 'utf8');

const s1 = `<div className="flex items-center justify-between gap-2 border-b border-slate-850 pb-2.5">
                  <div className="flex items-center gap-1.5 flex-wrap">`;
const r1 = `<div className="flex flex-col gap-2 border-b border-slate-850 pb-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 flex-wrap">`;
code = code.replace(s1, r1);

const s2 = `                  <div className="flex items-center gap-1.5 w-full mt-1.5 mb-1 bg-slate-900/60 p-1.5 rounded border border-slate-800">
                    <span className="text-cyan-400 text-[10px] font-bold">⏱️ توقيت الرصد (مباشر):</span>
                    <span className="text-slate-300 text-[10px] font-mono tracking-tighter" style={{ direction: 'ltr', display: 'inline-block' }}>
                      {item.timestamp || 'جاري المزامنة...'}
                    </span>
                  </div>
                  <span className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-500/30 font-bold whitespace-nowrap">
                    <CheckCircle className="w-3 h-3 text-emerald-400" />
                    <span>مدمج بالمحرك: {item.verifiedWinRate}</span>
                  </span>
                </div>`;
const r2 = `                  <span className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-500/30 font-bold whitespace-nowrap">
                      <CheckCircle className="w-3 h-3 text-emerald-400" />
                      <span>مدمج: {item.verifiedWinRate}</span>
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-slate-900/60 p-1.5 rounded border border-slate-800 w-fit">
                    <span className="text-cyan-400 text-[10px] font-bold">⏱️ توقيت الرصد (مباشر):</span>
                    <span className="text-slate-300 text-[10.5px] font-mono tracking-tighter" style={{ direction: 'ltr', display: 'inline-block' }}>
                      {item.timestamp || 'جاري المزامنة...'}
                    </span>
                  </div>
                </div>`;
code = code.replace(s2, r2);

fs.writeFileSync('src/components/LiveInnovationRadar.tsx', code);
console.log('patched');
