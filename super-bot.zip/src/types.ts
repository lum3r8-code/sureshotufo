export type PlanType = 'Trial' | 'Basic' | 'Premium' | 'Unlimited';

export interface RealTechnicalIndicators {
  isStagnantLiquidity?: boolean;
  isHighlyVolatile?: boolean;
  isAtypicalVolatility?: boolean;
  isLiquidityUp?: boolean;
  rsiValue: number;
  rsiPeriod?: number;
  rsiFast8?: number;
  rsiPulse2?: number;
  rsiSignal: 'OVERSOLD_CALL' | 'OVERBOUGHT_PUT' | 'BULLISH_TREND' | 'BEARISH_TREND';
  ema9: number;
  ema21: number;
  emaCross: 'GOLDEN_CROSS_BULLISH' | 'DEATH_CROSS_BEARISH';
  ema10?: number;
  ema1Cross10?: 'BULLISH' | 'BEARISH';
  macdHistogram: number;
  macdSignal: 'BULLISH_EXPANSION' | 'BEARISH_EXPANSION';
  bollingerPosition: 'LOWER_BAND_BOUNCE' | 'UPPER_BAND_REJECTION' | 'MID_EXPANSION';
  stochK: number;
  orderBookRatio: number;
  confluenceScore: number;
  confluenceMax: number;
  isRealSureshot: boolean;
  technicalSummary: string;
  osintNewsKillSwitch?: boolean;
  osintOrderBookWall?: string;
  osintSpreadAnomaly?: string;
  fxStreetSupportLevel?: string;
  phantomShieldActive?: boolean;
  phantomActionType?: string;
  reversalShieldActive?: boolean;
  reversalActionType?: string;
  tacticalEntrySec?: string;
  vipSniperActive?: boolean;
  vipSniperTriggered?: boolean;
  vipSniperRule?: string;
  activeAssimilatedInnovations?: Array<{ id: string; title: string; ruleFired: string; winRate: string }>;
  novelCovertAnomalyDetected?: boolean;
  novelCovertAnomalyAction?: string;
  novelCovertSignature?: string;
}

export interface HighImpactNewsAlert {
  hasHighImpactNews: boolean;
  event: string;
  currency: string;
  impactLevel: 'HIGH' | 'CRITICAL';
  timeDescription: string;
  reason: string;
  advice: string;
  sentiment: string;
  protectionActive: string;
  volatilitySurgePct: number;
}

export interface BinaryPairVulnerability {
  id: string;
  pair: string; // e.g. "EUR/USD"
  category: string;
  currentPrice?: string;
  price?: number;
  vulnerabilityScore: number; // e.g. 96.4%
  anomalyType: string; // e.g. "Order Flow Imbalance & Quote Stuffing Lag"
  nextCandleDirection: 'CALL' | 'PUT';
  confidence: number; // e.g. 98.2%
  optimalTimeframe: string; // e.g. "01:00 دقيقة - نافذة صيد قوية"
  volatilityIndex: number; // e.g. 89.1
  tickLagMs: number; // e.g. 14ms
  winRateLast100: number; // e.g. 94.5%
  synthesizedTool?: string;
  newsSentimentImpact?: string;
  highImpactNews?: HighImpactNewsAlert;
  status: 'Active Exploit Window' | 'Monitoring' | 'Cooling Down' | 'Market Closed';
  isMarketOpen?: boolean;
  marketStatusMessage?: string;
  isSureshot?: boolean;
  noRepaint?: boolean;
  noMtg?: boolean;
  candlePeriod?: number;
  candleOpenPrice?: number;
  realIndicators?: RealTechnicalIndicators;
  economicScientistData?: {
    yieldSpreadTrend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
    interestRateParityDrift: number;
    macroCalendarRiskFactor: number;
    inflationDifferential: number;
    economicSentimentScore: number;
    scientificTechniqueLabels: string[];
    summaryText: string;
  };
  vulnerabilityData?: {
    primaryExploit?: string;
    exploitName?: string;
    brokerServerLagMs?: number;
    fastFeedSource?: string;
    interbankFeedStatus?: string;
    otcDecryptionStatus?: string;
    quoteDiscrepancyPip?: number;
    activeExploitsCount?: number;
    osintNewsKillSwitch?: boolean;
    osintOrderBookWall?: string;
    osintSpreadAnomaly?: string;
    phantomShieldActive?: boolean;
    phantomActionType?: string;
    reversalShieldActive?: boolean;
    reversalActionType?: string;
    tacticalEntrySec?: string;
    isHighlyVolatile?: boolean;
    isAtypicalVolatility?: boolean;
    activeAssimilatedInnovations?: Array<{ id: string; title: string; ruleFired: string; winRate: string }>;
  };
  osintData?: {
    isStagnantLiquidity?: boolean;
    isHighlyVolatile?: boolean;
    isAtypicalVolatility?: boolean;
    spoofingDetected?: boolean;
    wallSize?: string;
    newsSafe?: boolean;
    brokerShieldActive?: boolean;
    brokerActionType?: string;
    reversalShieldActive?: boolean;
    reversalActionType?: string;
    phantomShieldActive?: boolean;
    phantomActionType?: string;
    tacticalEntrySec?: string;
    vipSniperActive?: boolean;
    vipSniperTriggered?: boolean;
    vipSniperRule?: string;
    activeAssimilatedInnovations?: Array<{ id: string; title: string; ruleFired: string; winRate: string }>;
    novelCovertAnomaly?: {
      detected: boolean;
      action: string;
      signature: string;
      gain: string;
    };
  };
  algoMetrics?: {
    orderFlowDelta?: number;
    smcLiquidityScore?: number;
    neuralBias?: 'BULLISH' | 'BEARISH';
    multiTimeframeConfluence?: number;
    fvgDetected?: boolean;
    rsi?: number;
    rsiPeriod?: number;
    analyticalCandles?: number;
    macd?: string;
    whaleWallUsdM?: number;
    whaleWallAction?: string;
    exploitExplanationText?: string;
  };
}

export interface BinaryExploitLog {
  id: string;
  timestamp: string;
  pair: string;
  action: string;
  direction: 'CALL' | 'PUT';
  confidence: number;
  anomalyDetected: string;
  profitRatio: string;
  synthesizedToolUsed?: string;
}

export interface SaaSAPIKey {
  id: string;
  label: string;
  key: string;
  plan: PlanType;
  status: 'Active' | 'Inactive';
  requestsCount: number;
  maxLimit: number | 'Unlimited';
  createdAt: string;
}

export interface APILog {
  id: string;
  timestamp: string;
  keyLabel: string;
  apiKey: string;
  endpoint: string;
  ip: string;
  status: number; // e.g. 200, 403, 429
  message?: string;
}

export interface GovernorLog {
  id: string;
  timestamp: string;
  type: 'tuning' | 'security' | 'simulator' | 'healing';
  message: string;
}

export interface GovernorState {
  enabled: boolean;
  autoTuning: boolean;
  securityGuardian: boolean;
  simulatedTraffic: boolean;
  latencyMs: number;
  safetyScore: number;
  cpuLoad: number;
  arbitrageThreshold: number; // e.g. 1.2%
}

export interface CryptoSpread {
  asset: string; // BTC, ETH, SOL, XRP
  directPrice: number; // Price on main exchange (e.g. Binance)
  crossPrice: number;  // Price on secondary exchange (e.g. Coinbase via intermediate cross pair)
  spreadAmount: number;
  spreadPercent: number;
  volatility: number;
  optimalDirection: string; // e.g. "شراء من Binance -> بيع في Coinbase"
  latencyAgeMs: number;
}

export interface ArbitrageOpportunity {
  id: string;
  asset: string;
  direction: string;
  spreadPercent: number;
  estimatedProfitUsd: number;
  riskScore: 'Low' | 'Medium' | 'High';
  recommendedGasFeeUsd: number;
  timestamp: string;
  status: 'Active' | 'Executed' | 'Expired';
}

export interface PayoutHistoryItem {
  id: string;
  timestamp: string;
  amountUsd: number;
  method: string;
  address: string;
  status: 'Completed' | 'Pending' | 'Processing';
  txHash: string;
  feeUsd: number;
  direction?: string;
}

export interface PayoutConfig {
  method: string;
  address: string;
  autoWithdraw: 'Manual' | 'Instant' | 'Daily' | 'Threshold';
  lastUpdated: string;
  availableBalanceUsd: number;
  totalWithdrawnUsd: number;
  totalRevenueUsd?: number;
  onChainBalance?: {
    trx: number;
    usdtTrc20: number;
    lastChecked: string;
    isLiveSynced: boolean;
    rawStatus: string;
    totalInUsdt?: number;
    totalOutUsdt?: number;
    totalTransactions?: number;
  };
  onChainTransfers?: PayoutHistoryItem[];
  history: PayoutHistoryItem[];
}

export interface DashboardData {
  keys: SaaSAPIKey[];
  logs: APILog[];
  governorState: GovernorState;
  governorLogs: GovernorLog[];
  payoutConfig?: PayoutConfig;
  mrr: number;
  activeSubscribers: number;
  totalQueries: number;
  uptime: string;
  liveSpreads?: CryptoSpread[];
  liveOpportunities?: ArbitrageOpportunity[];
  whaleTransactions?: WhaleTransaction[];
  flashLoans?: FlashLoanOpportunity[];
  telegramConfig?: TelegramConfig;
}

export interface WhaleTransaction {
  id: string;
  asset: string;
  amount: number;
  valueUsd: number;
  fromAddress: string;
  toAddress: string;
  type: 'deposit' | 'withdraw' | 'transfer';
  exchange?: string;
  txHash: string;
  timestamp: string;
}

export interface FlashLoanOpportunity {
  id: string;
  asset: string;
  borrowAmount: number;
  path: string; // e.g. "Aave -> Uniswap -> Sushiswap"
  gasFeeUsd: number;
  grossProfitUsd: number;
  netProfitUsd: number;
  protocol: string;
  timestamp: string;
  status: 'Simulated' | 'Executing' | 'Success' | 'Failed';
}

export interface TelegramConfig {
  botToken: string;
  chatId: string;
  enabled: boolean;
  alertOnWhales: boolean;
  alertOnHighSpreads: boolean;
}

export interface RedeemedTransaction {
  id: string;
  txHash: string;
  amountUsd: number;
  plan: PlanType;
  keyId: string;
  timestamp: string;
}

export interface TronVerificationResult {
  success: boolean;
  message: string;
  key?: SaaSAPIKey;
  transaction?: {
    txHash: string;
    amountUsd: number;
    plan: PlanType;
    senderAddress?: string;
    recipientAddress: string;
    timestamp: string;
    explorerUrl: string;
    confirmed: boolean;
  };
  error?: string;
}

export interface SynthesizedExploitVector {
  id: string;
  name: string;
  category: 'LATENCY_ARBITRAGE' | 'LIQUIDITY_VACUUM' | 'QUANTUM_HARMONIC' | 'ENTROPY_INVERSION' | 'KINETIC_MOMENTUM';
  winMultiplier: number;
  detectionSignature: string;
  mutationGeneration: number;
  lastMutated: string;
  successStreak: number;
  active: boolean;
  status?: string;
  efficiencyScore?: string;
}

export interface TacticalStrikeEvent {
  id: string;
  timestamp: string;
  pair: string;
  vectorName: string;
  direction: 'CALL' | 'PUT';
  confidence: number;
  payoutProfit: string;
  executionDelayMs: number;
  status: 'EXECUTED_SEIZED' | 'STRIKE_CONFIRMED' | 'PROFIT_SECURED';
}

export interface AutonomousVulnerabilityEvent {
  id: string;
  timestamp: number;
  pairId: string;
  pairSymbol: string;
  timeframe: string;
  vulnerabilityType: string;
  vector: 'WICK_TRAP' | 'FRACTAL_DIVERGENCE' | 'LATENCY_DRIFT' | 'STAGNANT_SQUEEZE' | 'SPOOFING_IMBALANCE' | 'INDICATOR_DRIFT' | 'CONFLUENCE_BREACH' | 'INFRA_CIRCUIT_BREAKER' | 'MEMORY_HEAP_OPTIMIZATION' | 'TRINITY_PILLAR_1_SMC' | 'TRINITY_PILLAR_2_BROKER' | 'TRINITY_PILLAR_3_SHADOW_HACKER' | 'NOVEL_ZERO_DAY_ANOMALY' | 'COVERT_MANIPULATION_DETECTED';
  severity: 'CRITICAL_RESOLVED' | 'HIGH_PREVENTED' | 'SYSTEM_FORTIFIED';
  rootCause: string;
  algorithmicFix: string;
  appliedParameter: string;
  immunityGain: string;
  resolvedInMs: number;
  isNovelCovertThreat?: boolean;
  threatSignature?: string;
  autoCorrectedSignal?: 'CALL' | 'PUT' | 'ABORT_DEADLOCK' | 'MARGIN_DELAY_ENFORCED';
}

export interface SelfHealingDaemonState {
  isActive: boolean;
  startedAt: number;
  totalScans: number;
  vulnerabilitiesDetected: number;
  vulnerabilitiesPatched: number;
  systemImmunityLevel: number;
  activeShields: string[];
  recentAuditLogs: AutonomousVulnerabilityEvent[];
  lastScanTimestamp: number;
  scanIntervalMs: number;
}
