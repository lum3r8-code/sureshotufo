import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { LanguageProvider } from './LanguageContext.tsx';
import { DeviceAuthorizationGate } from './components/DeviceAuthorizationGate.tsx';
import './index.css';

import { ErrorBoundary } from './components/ErrorBoundary.tsx';

// 🚀 Instant Zero-Delay Startup: Synchronize build version in background without page reload interruptions
if (typeof window !== 'undefined') {
  // Clean up any old query parameters cleanly
  if (window.location.search.includes('_v=')) {
    try {
      window.history.replaceState(null, '', window.location.pathname);
    } catch {}
  }

  // Silent background version synchronization (never blocks or delays initial paint)
  const syncVersion = () => {
    fetch('/api/version', { cache: 'no-store' })
      .then(r => r.json())
      .then(data => {
        if (data && data.buildVersion) {
          localStorage.setItem('sureshot_build_version', String(data.buildVersion));
        }
      })
      .catch(() => {});
  };

  // Run in background after initial paint completes
  setTimeout(syncVersion, 1000);
  setInterval(syncVersion, 60000);
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <LanguageProvider>
        <DeviceAuthorizationGate>
          <App />
        </DeviceAuthorizationGate>
      </LanguageProvider>
    </ErrorBoundary>
  </StrictMode>,
);
