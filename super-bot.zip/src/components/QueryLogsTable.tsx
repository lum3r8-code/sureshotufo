import { Activity, ShieldAlert, CheckCircle2, XCircle } from 'lucide-react';
import { APILog } from '../types';

interface QueryLogsTableProps {
  logs: APILog[];
}

export default function QueryLogsTable({ logs }: QueryLogsTableProps) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 mb-6">
      {/* Header */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-4 mb-4">
        <Activity className="w-5 h-5 text-emerald-400" />
        <h2 className="font-extrabold text-white text-base">سجل الطلبات الحية (Live Request Logs)</h2>
      </div>

      <p className="text-xs text-slate-400 mb-4">
        مراقبة فورية لآخر الطلبات البرمجية الواردة إلى بوابة تداول العملات الرقمية من العملاء النشطين ومحاكي الزيارات الذكي:
      </p>

      {/* Table container with responsive overflow */}
      <div className="overflow-x-auto max-h-[420px] overflow-y-auto scrollbar-thin scrollbar-thumb-slate-850">
        <table className="w-full text-right border-collapse">
          <thead className="bg-slate-950/60 sticky top-0 z-10">
            <tr className="border-b border-slate-800 text-slate-400 text-[10px] font-bold uppercase tracking-wider">
              <th className="py-3 px-4">التوقيت</th>
              <th className="py-3 px-4">العميل / المفتاح</th>
              <th className="py-3 px-4 font-mono text-left">المسار (Endpoint)</th>
              <th className="py-3 px-4 font-mono text-left">عنوان IP</th>
              <th className="py-3 px-4 text-center">كود الحالة</th>
              <th className="py-3 px-4 text-left">التفاصيل</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-xs">
            {logs.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-500 italic">
                  لا توجد أي طلبات مسجلة في الذاكرة حالياً...
                </td>
              </tr>
            ) : (
              logs.map((log) => {
                const isSuccess = log.status === 200;
                let statusBadge = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
                let StatusIcon = CheckCircle2;

                if (log.status === 401 || log.status === 403) {
                  statusBadge = 'bg-amber-500/10 text-amber-400 border-amber-500/20';
                  StatusIcon = ShieldAlert;
                } else if (log.status >= 429) {
                  statusBadge = 'bg-red-500/10 text-red-400 border-red-500/20';
                  StatusIcon = XCircle;
                }

                return (
                  <tr key={log.id} className="hover:bg-slate-850/30 transition duration-100">
                    {/* Timestamp */}
                    <td className="py-2.5 px-4 text-slate-400 whitespace-nowrap font-mono">
                      {new Date(log.timestamp).toLocaleTimeString('ar-EG-u-nu-latn', {
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                        numberingSystem: 'latn'
                      }).replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))}
                    </td>

                    {/* Client/Key label */}
                    <td className="py-2.5 px-4 font-semibold text-slate-200">
                      <div className="flex flex-col">
                        <span>{log.keyLabel}</span>
                        <span className="text-[9px] text-slate-500 font-mono">{log.apiKey}</span>
                      </div>
                    </td>

                    {/* Endpoint targeted */}
                    <td className="py-2.5 px-4 text-left font-mono text-[10px] text-sky-400">
                      {log.endpoint}
                    </td>

                    {/* Client IP */}
                    <td className="py-2.5 px-4 text-left font-mono text-slate-400">
                      {log.ip}
                    </td>

                    {/* Response status code */}
                    <td className="py-2.5 px-4 text-center">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded border text-[10px] font-bold ${statusBadge}`}>
                        <StatusIcon className="w-3 h-3" />
                        <span>{log.status}</span>
                      </span>
                    </td>

                    {/* Details / Message */}
                    <td className="py-2.5 px-4 text-left text-[10px] text-slate-400 max-w-[150px] truncate">
                      {log.message || <span className="text-slate-600">طلب ناجح</span>}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
