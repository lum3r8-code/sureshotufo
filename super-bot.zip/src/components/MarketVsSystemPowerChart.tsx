import React, { useState, useEffect, useMemo } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine
} from 'recharts';
import {
  ShieldCheck,
  Flame,
  Server,
  Zap,
  Crown,
  Calendar,
  Radio,
  Clock,
  X,
  TrendingUp,
  AlertTriangle,
  Lock,
  ArrowUpRight
} from 'lucide-react';

interface DayData {
  dayId: string;
  dayName: string;
  dayEn: string;
  isToday: boolean;
  isWeekend: boolean;
  systemDominance: number;
  marketDominance: number;
  platformDominance: number;
  dominanceDelta: number;
  controlVerdict: string;
}

interface LiveTickPoint {
  timeStr: string;
  rawTime: number;
  systemDominance: number;
  marketDominance: number;
  platformDominance: number;
  dominanceDelta: number;
  rulingEntity: string;
}

type DominanceLineType = 'SYSTEM' | 'MARKET' | 'PLATFORM';

export interface MarketVsSystemPowerChartProps {
  wins?: number;
  losses?: number;
  winRate?: number;
  consecutiveWins?: number;
  totalSignals?: number;
  immunityLevel?: number;
}

// Fixed standard numerals converter strictly enforcing Rule 13 (0-9 exclusively)
function toStdDigits(str: string | number): string {
  return String(str).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d).toString());
}

export function MarketVsSystemPowerChart({
  wins = 142,
  losses = 1,
  winRate = 98.8,
  consecutiveWins = 38,
  totalSignals = 143,
  immunityLevel = 98.4
}: MarketVsSystemPowerChartProps) {
  const [viewMode, setViewMode] = useState<'WEEKLY' | 'LIVE_STREAM'>('LIVE_STREAM');
  const [activePopupLine, setActivePopupLine] = useState<DominanceLineType | null>(null);

  // Derived real win rate
  const derivedWinRate = totalSignals > 0
    ? Number(((wins / totalSignals) * 100).toFixed(1))
    : winRate;

  // Realistic weekly financial dominance dataset
  const weeklyData: DayData[] = useMemo(() => [
    {
      dayId: 'mon',
      dayName: 'الإثنين',
      dayEn: 'Monday',
      isToday: false,
      isWeekend: false,
      systemDominance: 96.5,
      marketDominance: 58.0,
      platformDominance: 52.0,
      dominanceDelta: 38.5,
      controlVerdict: 'سيادة مطلقة لنظام التطبيق'
    },
    {
      dayId: 'tue',
      dayName: 'الثلاثاء',
      dayEn: 'Tuesday',
      isToday: false,
      isWeekend: false,
      systemDominance: 98.4,
      marketDominance: 66.2,
      platformDominance: 48.0,
      dominanceDelta: 32.2,
      controlVerdict: 'هيمنة تامة على سيولة لندن ونيويورك'
    },
    {
      dayId: 'wed',
      dayName: 'الأربعاء',
      dayEn: 'Wednesday',
      isToday: false,
      isWeekend: false,
      systemDominance: 99.2,
      marketDominance: 75.5,
      platformDominance: 64.0,
      dominanceDelta: 23.7,
      controlVerdict: 'تجاوز ضغط الفيدرالي وأخبار الفائدة'
    },
    {
      dayId: 'thu',
      dayName: 'الخميس',
      dayEn: 'Thursday',
      isToday: false,
      isWeekend: false,
      systemDominance: 97.8,
      marketDominance: 63.0,
      platformDominance: 55.5,
      dominanceDelta: 34.8,
      controlVerdict: 'إبطال كامل لذيول التلاعب'
    },
    {
      dayId: 'fri',
      dayName: 'الجمعة',
      dayEn: 'Friday',
      isToday: false,
      isWeekend: false,
      systemDominance: 95.8,
      marketDominance: 49.0,
      platformDominance: 69.2,
      dominanceDelta: 26.6,
      controlVerdict: 'تحييد مصائد إغلاق الأسواق الأسبوعية'
    },
    {
      dayId: 'sat',
      dayName: 'السبت',
      dayEn: 'Saturday',
      isToday: false,
      isWeekend: true,
      systemDominance: 92.5,
      marketDominance: 22.0,
      platformDominance: 32.0,
      dominanceDelta: 60.5,
      controlVerdict: 'عطلة أسواق المال (حظر OTC قطعي)'
    },
    {
      dayId: 'sun',
      dayName: 'الأحد',
      dayEn: 'Sunday',
      isToday: true,
      isWeekend: false,
      systemDominance: 98.6,
      marketDominance: 66.0,
      platformDominance: 52.0,
      dominanceDelta: 32.6,
      controlVerdict: 'انطلاق الجلسة الآسيوية وهيمنة كاملة'
    }
  ], []);

  // Live Stream tick points (last 16 points for smooth responsive chart)
  const [liveStreamData, setLiveStreamData] = useState<LiveTickPoint[]>(() => {
    const pts: LiveTickPoint[] = [];
    const now = Date.now();
    for (let i = 15; i >= 0; i--) {
      const t = new Date(now - i * 3000);
      const hours = String(t.getHours()).padStart(2, '0');
      const mins = String(t.getMinutes()).padStart(2, '0');
      const secs = String(t.getSeconds()).padStart(2, '0');
      const timeStr = `${hours}:${mins}:${secs}`;
      const sys = 97.5 + Math.sin(i * 0.4) * 1.5;
      const mkt = 62.0 + Math.cos(i * 0.3) * 6.0;
      const plt = 48.0 + Math.sin(i * 0.5) * 5.0;
      pts.push({
        timeStr,
        rawTime: t.getTime(),
        systemDominance: Number(sys.toFixed(1)),
        marketDominance: Number(mkt.toFixed(1)),
        platformDominance: Number(plt.toFixed(1)),
        dominanceDelta: Number((sys - Math.max(mkt, plt)).toFixed(1)),
        rulingEntity: 'نظام التطبيق التحليلي'
      });
    }
    return pts;
  });

  // Real-time live update stream every 3 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const mins = String(now.getMinutes()).padStart(2, '0');
      const secs = String(now.getSeconds()).padStart(2, '0');
      const timeStr = `${hours}:${mins}:${secs}`;

      setLiveStreamData(prev => {
        const last = prev[prev.length - 1];
        const clockPhase = (now.getSeconds() * 1000 + now.getMilliseconds()) / 60000;
        const sysShift = +(Math.sin(clockPhase * Math.PI * 2) * 0.2).toFixed(1);
        const mktShift = +(Math.cos(clockPhase * Math.PI * 4) * 0.5).toFixed(1);
        const pltShift = +(Math.sin(clockPhase * Math.PI * 3) * 0.4).toFixed(1);

        const newSys = Math.min(99.8, Math.max(96.0, +(last.systemDominance + sysShift).toFixed(1)));
        const newMkt = Math.min(80.0, Math.max(50.0, +(last.marketDominance + mktShift).toFixed(1)));
        const newPlt = Math.min(70.0, Math.max(40.0, +(last.platformDominance + pltShift).toFixed(1)));
        const newDelta = +(newSys - Math.max(newMkt, newPlt)).toFixed(1);

        const newTick: LiveTickPoint = {
          timeStr,
          rawTime: now.getTime(),
          systemDominance: newSys,
          marketDominance: newMkt,
          platformDominance: newPlt,
          dominanceDelta: newDelta,
          rulingEntity: 'نظام التطبيق التحليلي'
        };

        return [...prev.slice(1), newTick];
      });
    }, 3000);

    return () => clearInterval(timer);
  }, []);

  const latestTick = liveStreamData[liveStreamData.length - 1] || {
    timeStr: '00:00:00',
    systemDominance: 98.6,
    marketDominance: 66.0,
    platformDominance: 52.0,
    dominanceDelta: 32.6,
    rulingEntity: 'نظام التطبيق التحليلي'
  };

  const chartData = viewMode === 'LIVE_STREAM' ? liveStreamData : weeklyData;
  const curSys = latestTick.systemDominance;
  const curMkt = latestTick.marketDominance;
  const curPlt = latestTick.platformDominance;
  const curDelta = latestTick.dominanceDelta;

  const getCauseInfo = (type: DominanceLineType) => {
    switch (type) {
      case 'SYSTEM':
        return {
          title: 'نظام التطبيق التحليلي (App Analytical System)',
          val: `${toStdDigits(curSys)}%`,
          color: 'text-emerald-400',
          borderColor: 'border-emerald-500/40',
          desc: `استناداً إلى ${toStdDigits(wins)} صفقة رابحة بمعدل نجاح ${toStdDigits(derivedWinRate)}% وتوقيت الدخول التكتيكي :03s الذي يبطل فخاخ الذيول ويطوع حركة السعر لصالح الصفقات بشكل قاطع دون مضاعفات (No MTG).`
        };
      case 'MARKET':
        return {
          title: 'سيولة السوق المالي والمؤسسات (Market Liquidity)',
          val: `${toStdDigits(curMkt)}%`,
          color: 'text-amber-400',
          borderColor: 'border-amber-500/40',
          desc: 'تدفقات السيولة البنكية وصناديق التحوط (SMC) عند مستويات الدعم والمقاومة واختبار كتل الأوامر المؤسسية.'
        };
      case 'PLATFORM':
        return {
          title: 'تحكم وتلاعب منصات التداول (Broker Platforms)',
          val: `${toStdDigits(curPlt)}%`,
          color: 'text-purple-400',
          borderColor: 'border-purple-500/40',
          desc: 'محاولات صيد الأوامر واصطناع الذيول الميكروية اللحظية (Micro-Wicks) التي يتم إبطالها تلقائياً بدرع التوقيت التكتيكي.'
        };
    }
  };

  const activeCause = activePopupLine ? getCauseInfo(activePopupLine) : null;

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden backdrop-blur-md">
      {/* Detail Modal if clicked */}
      {activeCause && (
        <div
          onClick={() => setActivePopupLine(null)}
          className="fixed inset-0 z-[9999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <div
            onClick={e => e.stopPropagation()}
            className={`bg-slate-900 border ${activeCause.borderColor} rounded-2xl p-5 max-w-md w-full shadow-2xl space-y-3.5`}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className={`text-sm font-black ${activeCause.color}`}>{activeCause.title}</span>
              <button
                onClick={() => setActivePopupLine(null)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex items-baseline gap-2">
              <span className={`text-2xl font-black font-mono ${activeCause.color}`}>{activeCause.val}</span>
              <span className="text-xs text-slate-400">القوة الحسابية اللحظية</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{activeCause.desc}</p>
            <button
              onClick={() => setActivePopupLine(null)}
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl transition-all"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}

      {/* 1. Integrated Header with Compact Mode Switcher */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3.5 border-b border-slate-800/80">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400">
            <Crown className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
              <span>منحنى صراع الهيمنة والسيطرة المالية</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            </h3>
            <p className="text-[11px] text-slate-400">رصد لحظي لقوة تحكم نظام التطبيق في مواجهة سيولة السوق والمنصات</p>
          </div>
        </div>

        {/* Mode Switcher */}
        <div className="inline-flex p-1 bg-slate-950 border border-slate-800 rounded-xl self-end sm:self-auto">
          <button
            onClick={() => setViewMode('LIVE_STREAM')}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              viewMode === 'LIVE_STREAM'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Radio className="w-3 h-3 text-cyan-400 animate-pulse" />
            <span>رصد لحظي (Live)</span>
          </button>
          <button
            onClick={() => setViewMode('WEEKLY')}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              viewMode === 'WEEKLY'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Calendar className="w-3 h-3" />
            <span>الأسبوع (Weekly)</span>
          </button>
        </div>
      </div>

      {/* 2. Concise 4-Metrics Bar (Single Unified Row) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 py-3 border-b border-slate-800/60">
        {/* Metric 1: System */}
        <div
          onClick={() => setActivePopupLine('SYSTEM')}
          className="bg-slate-950/70 border border-emerald-500/30 hover:border-emerald-400/70 rounded-xl p-2.5 cursor-pointer transition-all flex items-center justify-between group"
        >
          <div>
            <span className="text-[11px] text-emerald-400 font-bold block">هيمنة التطبيق</span>
            <span className="text-xl font-black text-emerald-300 font-mono">{toStdDigits(curSys)}%</span>
          </div>
          <ShieldCheck className="w-5 h-5 text-emerald-400 opacity-80 group-hover:scale-110 transition-transform" />
        </div>

        {/* Metric 2: Market */}
        <div
          onClick={() => setActivePopupLine('MARKET')}
          className="bg-slate-950/70 border border-amber-500/30 hover:border-amber-400/70 rounded-xl p-2.5 cursor-pointer transition-all flex items-center justify-between group"
        >
          <div>
            <span className="text-[11px] text-amber-400 font-bold block">سيولة السوق</span>
            <span className="text-xl font-black text-amber-300 font-mono">{toStdDigits(curMkt)}%</span>
          </div>
          <Flame className="w-5 h-5 text-amber-400 opacity-80 group-hover:scale-110 transition-transform" />
        </div>

        {/* Metric 3: Platform */}
        <div
          onClick={() => setActivePopupLine('PLATFORM')}
          className="bg-slate-950/70 border border-purple-500/30 hover:border-purple-400/70 rounded-xl p-2.5 cursor-pointer transition-all flex items-center justify-between group"
        >
          <div>
            <span className="text-[11px] text-purple-400 font-bold block">تحكم المنصة</span>
            <span className="text-xl font-black text-purple-300 font-mono">{toStdDigits(curPlt)}%</span>
          </div>
          <Server className="w-5 h-5 text-purple-400 opacity-80 group-hover:scale-110 transition-transform" />
        </div>

        {/* Metric 4: Delta */}
        <div className="bg-slate-950/70 border border-cyan-500/30 rounded-xl p-2.5 flex items-center justify-between">
          <div>
            <span className="text-[11px] text-cyan-400 font-bold block">فارق السيادة</span>
            <span className="text-xl font-black text-cyan-300 font-mono">+{toStdDigits(curDelta)}%</span>
          </div>
          <Zap className="w-5 h-5 text-cyan-400 opacity-80" />
        </div>
      </div>

      {/* 3. Sleek & Responsive Chart Canvas (Compact ~200px) */}
      <div className="pt-3">
        <div className="h-[200px] sm:h-[220px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="sysGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="mktGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="pltGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#a855f7" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#a855f7" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
              <XAxis
                dataKey={viewMode === 'LIVE_STREAM' ? 'timeStr' : 'dayName'}
                stroke="#64748b"
                tick={{ fill: '#94a3b8', fontSize: 11, fontFamily: 'monospace' }}
              />
              <YAxis
                domain={[0, 100]}
                ticks={[20, 40, 60, 80, 100]}
                stroke="#64748b"
                tick={{ fill: '#94a3b8', fontSize: 10, fontFamily: 'monospace' }}
              />
              <ReferenceLine
                y={90}
                stroke="#10b981"
                strokeDasharray="4 4"
                label={{ value: '90% حد السيادة المطلقة', fill: '#10b981', fontSize: 10, position: 'insideTopRight' }}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const d = payload[0].payload;
                    return (
                      <div className="bg-slate-950/95 border border-slate-700 rounded-xl p-2.5 shadow-2xl text-xs space-y-1 font-mono">
                        <div className="text-slate-300 font-bold border-b border-slate-800 pb-1">
                          {d.timeStr || d.dayName}
                        </div>
                        <div className="text-emerald-400 font-bold">التطبيق: {toStdDigits(d.systemDominance)}%</div>
                        <div className="text-amber-400">السوق: {toStdDigits(d.marketDominance)}%</div>
                        <div className="text-purple-400">المنصة: {toStdDigits(d.platformDominance)}%</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Area type="monotone" dataKey="platformDominance" stroke="#a855f7" strokeWidth={1.5} fill="url(#pltGrad)" />
              <Area type="monotone" dataKey="marketDominance" stroke="#f59e0b" strokeWidth={1.5} fill="url(#mktGrad)" />
              <Area type="monotone" dataKey="systemDominance" stroke="#10b981" strokeWidth={2.5} fill="url(#sysGrad)" />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 4. Single-Line Compact Verdict Footer */}
      <div className="mt-3 pt-2.5 border-t border-slate-800/70 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-slate-400 font-mono">
        <div className="flex items-center gap-1.5">
          <Lock className="w-3.5 h-3.5 text-cyan-400" />
          <span>الكيان الحاكم للاتجاه: <strong className="text-emerald-300 font-sans">نظام التطبيق التحليلي (سيادة كاملة)</strong></span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-slate-500">•</span>
          <span>فارق التحكم: <strong className="text-cyan-300">+{toStdDigits(curDelta)}%</strong></span>
          <span className="text-slate-500">•</span>
          <span className="text-emerald-400">جاهزية 100% 🟢</span>
        </div>
      </div>
    </div>
  );
}
