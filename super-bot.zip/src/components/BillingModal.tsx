import React, { useState } from 'react';
import { 
  X, 
  Wallet, 
  Copy, 
  Check, 
  ShieldCheck, 
  RefreshCw, 
  Sparkles, 
  HelpCircle, 
  AlertCircle, 
  ExternalLink, 
  Search, 
  CheckCircle2, 
  Terminal,
  Cpu
} from 'lucide-react';
import { PlanType, SaaSAPIKey } from '../types';

interface BillingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (plan: PlanType, method: 'USDT', amount: number) => void;
}

export default function BillingModal({ isOpen, onClose, onSuccess }: BillingModalProps) {
  const [selectedPlan, setSelectedPlan] = useState<PlanType>('Premium');
  
  // USDT TRC-20 Payment State
  const [txHash, setTxHash] = useState('');
  const [copiedAddress, setCopiedAddress] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);
  
  // Auto-Detect Inbound Transfers State
  const [isScanningInbound, setIsScanningInbound] = useState(false);
  const [scanNotice, setScanNotice] = useState<{ type: 'success' | 'info'; text: string } | null>(null);

  // Verification & Engine States
  const [isProcessing, setIsProcessing] = useState(false);
  const [verificationStage, setVerificationStage] = useState<number>(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  // Issued Key Result State
  const [issuedKey, setIssuedKey] = useState<SaaSAPIKey | null>(null);
  const [txDetails, setTxDetails] = useState<{
    txHash: string;
    amountUsd: number;
    plan: PlanType;
    explorerUrl: string;
  } | null>(null);

  if (!isOpen) return null;

  const plansInfo = {
    Basic: { name: 'الأساسية (Basic)', price: 29, limit: '5,000 استعلام/شهري' },
    Premium: { name: 'الممتازة (Premium)', price: 99, limit: '50,000 استعلام/شهري' },
    Unlimited: { name: 'غير المحدودة (Unlimited)', price: 249, limit: 'استعلام بلا حدود' },
  };

  // Genuine Owner TRC-20 Wallet Address (Hardcoded & Locked)
  const trc20WalletAddress = 'THHqj5655PPJqVvAP8hpB5oH2oTdhtdN46';
  const currentPrice = plansInfo[selectedPlan].price;

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(trc20WalletAddress);
    setCopiedAddress(true);
    setTimeout(() => setCopiedAddress(false), 2000);
  };

  const handleCopyKey = () => {
    if (!issuedKey) return;
    navigator.clipboard.writeText(issuedKey.key);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  // Auto-detect recent inbound transfers to this wallet
  const handleAutoDetectInbound = async () => {
    setScanNotice(null);
    setErrorMessage(null);
    setIsScanningInbound(true);

    try {
      const res = await fetch('/api/saas/billing/latest-inbound');
      const data = await res.json();

      if (data.unclaimedTransfers && data.unclaimedTransfers.length > 0) {
        const topTransfer = data.unclaimedTransfers[0];
        setTxHash(topTransfer.txHash);
        setScanNotice({
          type: 'success',
          text: `تم رصد تحويل وارد بمبلغ $${topTransfer.amountUsd.toFixed(2)} USDT! تم إدراج رمز المعاملة (TXID) تلقائياً، يمكنك الآن الضغط على زر التفعيل الفوري.`
        });
      } else {
        setScanNotice({
          type: 'info',
          text: 'لم يتم العثور على تحويلات واردة جديدة غير مفعلة في آخر العمليات. إذا قمت بالتحويل للتو، يرجى نسخ ولصق رمز المعاملة (TXID) يدوياً.'
        });
      }
    } catch (err: any) {
      setScanNotice({
        type: 'info',
        text: 'تعذر الاتصال بماسح المعاملات حالياً، يرجى لصق رمز المعاملة يدوياً.'
      });
    } finally {
      setIsScanningInbound(false);
    }
  };

  // Submit and verify on blockchain
  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setScanNotice(null);
    setIsProcessing(true);
    setVerificationStage(1);

    try {
      const cleanTxHash = txHash.trim();
      if (!cleanTxHash) {
        throw new Error('الرجاء إدخال رمز المعاملة (TXID / Transaction Hash) لتأكيد الإيداع على شبكة ترون (TRC-20).');
      }

      // Stage 2: Contacting TRON Network
      setVerificationStage(2);
      await new Promise(r => setTimeout(r, 700));

      // Stage 3: Verifying recipient wallet and amount on chain
      setVerificationStage(3);

      const res = await fetch('/api/saas/billing/verify-tron', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          txHash: cleanTxHash,
          plan: selectedPlan
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'تعذر التحقق من المعاملة على شبكة البلوكشين.');
      }

      // Stage 4: Issuing & Licensing Key
      setVerificationStage(4);
      await new Promise(r => setTimeout(r, 600));

      setIssuedKey(data.key);
      setTxDetails(data.transaction);
      onSuccess(data.transaction?.plan || selectedPlan, 'USDT', data.transaction?.amountUsd || currentPrice);

    } catch (err: any) {
      setErrorMessage(err.message || 'فشلت عملية التحقق من المعاملة على البلوكشين.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleResetForm = () => {
    setIssuedKey(null);
    setTxDetails(null);
    setTxHash('');
    setErrorMessage(null);
    setScanNotice(null);
    setVerificationStage(0);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md" dir="rtl">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 p-5 bg-slate-950/40">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-400 border border-emerald-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-white text-base">محرك تفعيل الاشتراكات الآلي</h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30 font-bold">
                  فوري 24/7
                </span>
              </div>
              <p className="text-xs text-slate-400">تحقق فوري من البلوكشين وإصدار المفاتيح البرمجية فور إيداع USDT (TRC-20)</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800/50 hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-semibold flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span className="leading-relaxed">{errorMessage}</span>
            </div>
          )}

          {scanNotice && (
            <div className={`p-3.5 rounded-xl text-xs font-semibold flex items-start gap-2.5 border ${
              scanNotice.type === 'success'
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                : 'bg-blue-500/10 border-blue-500/30 text-blue-300'
            }`}>
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span className="leading-relaxed">{scanNotice.text}</span>
            </div>
          )}

          {/* SUCCESS VIEW: KEY ISSUED CELEBRATION */}
          {issuedKey && txDetails ? (
            <div className="space-y-5 py-2">
              <div className="p-5 rounded-2xl bg-emerald-950/20 border border-emerald-500/40 text-center space-y-3 relative overflow-hidden">
                <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-base font-extrabold text-white">تم التحقق من المعاملة على شبكة ترون بنجاح! ⚡</h4>
                  <p className="text-xs text-slate-300 mt-1">
                    تم تأكيد استلام <span className="font-mono font-bold text-emerald-400">${txDetails.amountUsd.toFixed(2)} USDT</span> وإصدار وترخيص مفتاح الـ API فوراً.
                  </p>
                </div>

                {/* API Key Box */}
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-right space-y-2 mt-4 shadow-inner">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span className="font-bold flex items-center gap-1.5 text-white">
                      <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                      مفتاح الوصول البرمجي الخاص بك (API Key):
                    </span>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-bold">
                      نشط وجاهز للاستخدام
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-slate-900 border border-slate-750 px-3 py-2.5 rounded-lg text-left text-emerald-300 font-mono text-xs select-all overflow-x-auto whitespace-nowrap">
                      {issuedKey.key}
                    </div>
                    <button
                      type="button"
                      onClick={handleCopyKey}
                      className="px-3.5 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-450 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shrink-0 shadow-md"
                    >
                      {copiedKey ? (
                        <>
                          <Check className="w-4 h-4" />
                          <span>تم النسخ!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" />
                          <span>نسخ المفتاح</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Transaction Metadata Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 text-right text-xs pt-2">
                  <div className="p-2.5 bg-slate-900/90 border border-slate-800 rounded-lg">
                    <span className="block text-[10px] text-slate-400">الخطة المفعلة</span>
                    <span className="font-bold text-white mt-0.5 block">{issuedKey.plan}</span>
                  </div>
                  <div className="p-2.5 bg-slate-900/90 border border-slate-800 rounded-lg">
                    <span className="block text-[10px] text-slate-400">حصة الاستعلامات</span>
                    <span className="font-bold text-emerald-400 mt-0.5 block">
                      {issuedKey.maxLimit === 'Unlimited' ? 'غير محدود' : `${issuedKey.maxLimit.toLocaleString()} استعلام`}
                    </span>
                  </div>
                  <div className="p-2.5 bg-slate-900/90 border border-slate-800 rounded-lg">
                    <span className="block text-[10px] text-slate-400">المستكشف (TronScan)</span>
                    <a
                      href={txDetails.explorerUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-400 hover:text-blue-300 mt-0.5 flex items-center gap-1 font-mono text-[11px] underline"
                    >
                      <span>عرض المعاملة</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              </div>

              {/* Quick Integration Example */}
              <div className="bg-slate-950/60 border border-slate-850 rounded-xl p-3.5 space-y-2 text-right">
                <span className="text-[11px] font-bold text-slate-300 block">طريقة تضمين المفتاح في استدعاءات API أو بوتك:</span>
                <div className="bg-slate-900 px-3 py-2 rounded font-mono text-[11px] text-slate-300 text-left overflow-x-auto select-all border border-slate-800">
                  curl -H &quot;x-api-key: {issuedKey.key}&quot; https://your-domain/api/v1/arbitrage/opportunities
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-450 text-slate-950 font-bold text-xs transition cursor-pointer text-center"
                >
                  تم، متابعة العمل مع المنصة
                </button>
                <button
                  type="button"
                  onClick={handleResetForm}
                  className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition cursor-pointer"
                >
                  تفعيل مفتاح آخر
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handlePaymentSubmit} className="space-y-5">
              
              {/* 1. Plans Grid */}
              <div className="space-y-2.5">
                <label className="text-xs font-bold text-slate-300">1. اختر خطة الاشتراك المناسبة:</label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {(['Basic', 'Premium', 'Unlimited'] as PlanType[]).map((p) => {
                    const active = selectedPlan === p;
                    return (
                      <button
                        key={p}
                        type="button"
                        onClick={() => setSelectedPlan(p)}
                        className={`p-3.5 rounded-xl text-right border transition-all cursor-pointer relative overflow-hidden ${
                          active 
                            ? 'bg-emerald-950/25 border-emerald-500 text-white shadow-lg' 
                            : 'bg-slate-950/40 border-slate-800/80 text-slate-400 hover:border-slate-750'
                        }`}
                      >
                        {active && (
                          <div className="absolute top-0 left-0 bg-emerald-500 text-[9px] font-bold text-slate-950 px-2 py-0.5 rounded-br">
                            محدد
                          </div>
                        )}
                        <span className="block text-xs font-bold">{plansInfo[p].name}</span>
                        <div className="mt-2 flex items-baseline gap-1">
                          <span className="text-xl font-black text-white font-mono">${plansInfo[p].price}</span>
                          <span className="text-[10px] text-slate-500">/شهري</span>
                        </div>
                        <span className="block text-[10px] text-slate-400 mt-2">{plansInfo[p].limit}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 2. Payment Method Badge (Sole Active Method) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300">2. وسيلة الدفع الحصرية والمباشرة:</label>
                  <span className="text-[10px] bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 px-2.5 py-0.5 rounded-full font-bold">
                    شبكة TRON الرسمية
                  </span>
                </div>
                
                <div className="p-3 rounded-xl border bg-amber-950/15 border-amber-500/40 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                      <Wallet className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-extrabold text-white">الدولار الرقمي (USDT)</span>
                        <span className="text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30">
                          TRON (TRC-20)
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-0.5">إيداع فوري موثق على البلوكشين ومربوط بمحرك التحقق التلقائي</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* 3. Fields Area: Wallet & QR */}
              <div className="bg-slate-950/50 border border-slate-850 rounded-xl p-4 md:p-5">
                <div className="space-y-4">
                  <div className="flex flex-col md:flex-row items-center gap-4">
                    {/* Generative QR Code */}
                    <div className="bg-white p-2.5 rounded-xl shrink-0 border border-slate-200 shadow-md">
                      <svg className="w-24 h-24 text-slate-950" viewBox="0 0 100 100">
                        <path d="M5,5 h30 v30 h-30 z M15,15 h10 v10 h-10 z" fill="currentColor" />
                        <path d="M65,5 h30 v30 h-30 z M75,15 h10 v10 h-10 z" fill="currentColor" />
                        <path d="M5,65 h30 v30 h-30 z M15,15 h10 v10 h-10 z" fill="currentColor" />
                        <rect x="42" y="5" width="6" height="6" fill="currentColor" />
                        <rect x="52" y="12" width="6" height="12" fill="currentColor" />
                        <rect x="42" y="25" width="12" height="6" fill="currentColor" />
                        <rect x="5" y="42" width="12" height="6" fill="currentColor" />
                        <rect x="25" y="42" width="6" height="6" fill="currentColor" />
                        <rect x="36" y="42" width="18" height="6" fill="currentColor" />
                        <rect x="60" y="42" width="6" height="18" fill="currentColor" />
                        <rect x="72" y="42" width="12" height="6" fill="currentColor" />
                        <rect x="42" y="52" width="6" height="12" fill="currentColor" />
                        <rect x="15" y="52" width="12" height="6" fill="currentColor" />
                        <rect x="25" y="62" width="6" height="18" fill="currentColor" />
                        <rect x="42" y="72" width="18" height="6" fill="currentColor" />
                        <rect x="65" y="65" width="30" height="30" fill="none" stroke="currentColor" strokeWidth="3" />
                        <rect x="75" y="75" width="10" height="10" fill="currentColor" />
                      </svg>
                    </div>

                    <div className="flex-1 space-y-3 w-full">
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-slate-400 font-bold">عنوان محفظة الاستلام الرسمية (TRC-20):</span>
                          <span className="text-[9px] text-emerald-400 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded">مؤكدة ومقفلة</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <div className="flex-1 bg-slate-900 border border-slate-800 px-3 py-2 rounded-lg text-left text-slate-200 font-mono text-[11px] select-all overflow-x-auto whitespace-nowrap">
                            {trc20WalletAddress}
                          </div>
                          <button
                            type="button"
                            onClick={handleCopyAddress}
                            className="p-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer shrink-0"
                            title="نسخ عنوان المحفظة"
                          >
                            {copiedAddress ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      <div className="bg-amber-500/10 border border-amber-500/20 p-2.5 rounded-lg text-[10px] text-amber-300 flex gap-2 items-center">
                        <HelpCircle className="w-4 h-4 shrink-0" />
                        <p>يرجى إرسال مبلغ <span className="font-bold font-mono text-white">${currentPrice} USDT</span> عبر شبكة Tron (TRC-20) للمحفظة أعلاه.</p>
                      </div>
                    </div>
                  </div>

                  {/* TXID Input Field + Auto-Detect Button */}
                  <div className="space-y-2 border-t border-slate-850 pt-3.5">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-bold text-slate-300">
                        3. رمز المعاملة (TXID / Transaction Hash):
                      </label>
                      <button
                        type="button"
                        onClick={handleAutoDetectInbound}
                        disabled={isScanningInbound}
                        className="text-[10px] text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 px-2.5 py-1 rounded-md transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        {isScanningInbound ? (
                          <RefreshCw className="w-3 h-3 animate-spin" />
                        ) : (
                          <Search className="w-3 h-3" />
                        )}
                        <span>فحص أحدث إيداع تلقائياً</span>
                      </button>
                    </div>

                    <input
                      type="text"
                      required
                      value={txHash}
                      onChange={(e) => setTxHash(e.target.value)}
                      placeholder="الصق رمز الـ TXID الناتج عن عملية التحويل هنا..."
                      className="w-full bg-slate-900 border border-slate-800 focus:border-emerald-500 rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Progress verification stages animation */}
              {isProcessing && (
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-emerald-400 font-semibold">
                    <Cpu className="w-4 h-4 animate-spin" />
                    <span>محرك التحقق الآلي قيد الفحص المباشر:</span>
                  </div>
                  <div className="space-y-1.5 text-[11px] pr-2">
                    <div className={`flex items-center gap-2 ${verificationStage >= 1 ? 'text-emerald-400 font-bold' : 'text-slate-500'}`}>
                      <span className="w-1.5 h-1.5 rounded-full bg-current" />
                      <span>الاتصال بنقاط شبكة TRON ومطابقة الهاش...</span>
                    </div>
                    <div className={`flex items-center gap-2 ${verificationStage >= 2 ? 'text-emerald-400 font-bold' : 'text-slate-500'}`}>
                      <span className="w-1.5 h-1.5 rounded-full bg-current" />
                      <span>التحقق من استلام USDT في المحفظة المعتمدة...</span>
                    </div>
                    <div className={`flex items-center gap-2 ${verificationStage >= 3 ? 'text-emerald-400 font-bold' : 'text-slate-500'}`}>
                      <span className="w-1.5 h-1.5 rounded-full bg-current" />
                      <span>فحص أمان المعاملة ومنع التكرار (Anti-Replay Shield)...</span>
                    </div>
                    <div className={`flex items-center gap-2 ${verificationStage >= 4 ? 'text-emerald-400 font-bold' : 'text-slate-500'}`}>
                      <span className="w-1.5 h-1.5 rounded-full bg-current" />
                      <span>توليد وترخيص مفتاح الـ API فوراً وحفظه بالسجل السحابي...</span>
                    </div>
                  </div>
                </div>
              )}

              {/* 4. Action Pay Button */}
              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-3.5 px-4 rounded-xl font-bold text-sm text-slate-950 transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer bg-gradient-to-r from-emerald-400 to-amber-400 hover:from-emerald-350 hover:to-amber-350 disabled:from-slate-800 disabled:to-slate-800 disabled:text-slate-500"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                    <span>جاري التحقق عبر البلوكشين وإصدار المفتاح...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4 text-slate-950" />
                    <span>التحقق الفوري عبر البلوكشين وإصدار المفتاح الآن</span>
                  </>
                )}
              </button>

            </form>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 p-3.5 bg-slate-950/60 text-[10px] text-slate-500 text-center flex items-center justify-between px-6">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>المحفظة الرسمية المشفرة: {trc20WalletAddress.slice(0, 10)}...</span>
          </div>
          <span>محرك الحوكمة والتحقق TRC-20 نشط ومؤمن</span>
        </div>

      </div>
    </div>
  );
}
