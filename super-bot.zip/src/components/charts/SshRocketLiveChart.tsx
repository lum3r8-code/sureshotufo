import React, { useEffect, useMemo, useRef, useState, useCallback } from 'react';
import { 
  RefreshCw, 
  TrendingUp, 
  ShieldCheck, 
  Cpu, 
  Zap, 
  Activity,
  Maximize2,
  Lock,
  Unlock
} from 'lucide-react';
import { 
  createChart, 
  ColorType, 
  CandlestickSeries, 
  CrosshairMode,
  IChartApi,
  ISeriesApi,
  CandlestickData,
  Time
} from 'lightweight-charts';

interface SshRocketLiveChartProps {
  symbol: string;
  timeframe: string;
  onTimeframeChange?: (tf: string) => void;
  onGrsClick?: () => void;
  isGrsSending?: boolean;
  isGrs247Active?: boolean;
}

export const SshRocketLiveChart: React.FC<SshRocketLiveChartProps> = ({
  symbol,
  timeframe,
}) => {
  const displaySymbol = useMemo(() => {
    return (symbol || 'EURUSD')
      .replace(/^(FX_IDC:|OANDA:|BINANCE:|FOREXCOM:|CAPITALCOM:|FX:)/, '')
      .replace('/', '')
      .toUpperCase();
  }, [symbol]);

  const [lastPrice, setLastPrice] = useState<number | null>(null);
  const [priceChange, setPriceChange] = useState<number>(0);
  const [percentChange, setPercentChange] = useState<number>(0);
  const [latencyMs, setLatencyMs] = useState<number>(12);
  const [isLiveActive, setIsLiveActive] = useState<boolean>(true);
  const [dataFeedSource, setDataFeedSource] = useState<string>('Live Primary Stream');
  const [isLocked, setIsLocked] = useState<boolean>(true);

  const chartContainerRef = useRef<HTMLDivElement | null>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const lastFetchedTimeRef = useRef<number>(0);
  const isFetchingRef = useRef<boolean>(false);
  const retryTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Format currency/digits with optimal precision
  const formatPrice = useCallback((p: number) => {
    if (!p) return '0.00';
    const isCrypto = displaySymbol.includes('BTC') || displaySymbol.includes('ETH') || displaySymbol.includes('SOL');
    const isJpy = displaySymbol.includes('JPY');
    const digits = isCrypto ? 2 : isJpy ? 3 : 5;
    return p.toFixed(digits);
  }, [displaySymbol]);

  // Reset View to Latest Candle
  const handleResetView = useCallback(() => {
    if (chartRef.current) {
      chartRef.current.timeScale().scrollToRealTime();
      chartRef.current.timeScale().fitContent();
    }
  }, []);

  // Initialize Ultra-Smooth High-FPS Pure Candlestick Canvas Engine (100% Self-Hosted)
  useEffect(() => {
    if (!chartContainerRef.current) return;

    const container = chartContainerRef.current;
    container.innerHTML = '';

    const chart = createChart(container, {
      layout: {
        background: { type: ColorType.Solid, color: '#060911' },
        textColor: '#94a3b8',
        fontSize: 11,
        fontFamily: 'Cairo, system-ui, -apple-system, sans-serif'
      },
      grid: {
        vertLines: { color: 'rgba(30, 41, 59, 0.35)', style: 1 },
        horzLines: { color: 'rgba(30, 41, 59, 0.35)', style: 1 }
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          color: '#38bdf8',
          width: 1,
          style: 2,
          labelBackgroundColor: '#0284c7'
        },
        horzLine: {
          color: '#38bdf8',
          width: 1,
          style: 2,
          labelBackgroundColor: '#0284c7'
        }
      },
      rightPriceScale: {
        borderColor: '#1e293b',
        autoScale: true,
        scaleMargins: {
          top: 0.06,
          bottom: 0.06
        }
      },
      timeScale: {
        borderColor: '#1e293b',
        timeVisible: true,
        secondsVisible: false,
        shiftVisibleRangeOnNewBar: true,
        fixLeftEdge: true,
        fixRightEdge: false,
        rightOffset: 6,
        barSpacing: 8,
        minBarSpacing: 3
      },
      handleScroll: false,
      handleScale: false
    });

    const isCrypto = displaySymbol.includes('BTC') || displaySymbol.includes('ETH') || displaySymbol.includes('SOL');
    const isJpy = displaySymbol.includes('JPY');
    const precision = isCrypto ? 2 : isJpy ? 3 : 5;
    const minMove = isCrypto ? 0.01 : isJpy ? 0.001 : 0.00001;

    // Pure Candlestick Series configured for maximum crispness and zero flicker
    const candleSeries = chart.addSeries(CandlestickSeries, {
      upColor: '#10b981',
      downColor: '#f43f5e',
      borderVisible: true,
      borderUpColor: '#10b981',
      borderDownColor: '#f43f5e',
      wickUpColor: '#10b981',
      wickDownColor: '#f43f5e',
      priceFormat: {
        type: 'price',
        precision: precision,
        minMove: minMove
      }
    });

    chartRef.current = chart;
    candleSeriesRef.current = candleSeries;

    // High performance resize handling using requestAnimationFrame
    let animationFrameId: number | null = null;
    const handleResize = () => {
      if (animationFrameId) cancelAnimationFrame(animationFrameId);
      animationFrameId = requestAnimationFrame(() => {
        if (container && chart) {
          chart.applyOptions({
            width: container.clientWidth,
            height: container.clientHeight
          });
        }
      });
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    return () => {
      if (animationFrameId) cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      chart.remove();
      chartRef.current = null;
      candleSeriesRef.current = null;
    };
  }, []);

  // Keep chart interaction locked/unlocked dynamically
  useEffect(() => {
    if (chartRef.current) {
      chartRef.current.applyOptions({
        handleScroll: !isLocked ? {
          mouseWheel: true,
          pressedMouseMove: true,
          horzTouchDrag: true,
          vertTouchDrag: true
        } : false,
        handleScale: !isLocked ? {
          axisPressedMouseMove: true,
          mouseWheel: true,
          pinch: true
        } : false
      });
    }
  }, [isLocked]);

  // Fetch independent real-time market data with progressive incremental updates
  useEffect(() => {
    let isMounted = true;
    lastFetchedTimeRef.current = 0;

    const fetchIndependentData = async (isInitial = false) => {
      if (isFetchingRef.current && !isInitial) return;
      isFetchingRef.current = true;

      const startTime = performance.now();
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 2800);

        const res = await fetch(
          `/api/klines?symbol=${encodeURIComponent(displaySymbol)}&timeframe=${encodeURIComponent(timeframe)}&limit=100`,
          { signal: controller.signal, cache: 'no-store' }
        );
        clearTimeout(timeoutId);
        const elapsed = Math.round(performance.now() - startTime);

        if (res.ok) {
          const data = await res.json();
          if (data.success && Array.isArray(data.candles) && data.candles.length > 0 && isMounted) {
            const rawCandles = data.candles;
            if (data.source) setDataFeedSource(data.source);
            
            // Format candles for lightweight-charts with guaranteed strictly increasing timestamps
            const formattedCandles: CandlestickData<Time>[] = [];
            let lastSec = 0;

            for (let i = 0; i < rawCandles.length; i++) {
              const c = rawCandles[i];
              let timeSec = Math.floor(c.timestamp / 1000);
              
              if (timeSec <= lastSec) {
                timeSec = lastSec + 60; // Ensure strictly increasing monotonic step
              }
              lastSec = timeSec;

              formattedCandles.push({
                time: timeSec as Time,
                open: c.open,
                high: c.high,
                low: c.low,
                close: c.close
              });
            }

            if (candleSeriesRef.current && formattedCandles.length > 0) {
              const latestCandle = formattedCandles[formattedCandles.length - 1];

              // If initial load or candles length changed significantly, use setData
              if (lastFetchedTimeRef.current === 0 || isInitial) {
                candleSeriesRef.current.setData(formattedCandles);
                lastFetchedTimeRef.current = latestCandle.time as number;
                if (chartRef.current) {
                  chartRef.current.timeScale().fitContent();
                }
              } else {
                try {
                  candleSeriesRef.current.setData(formattedCandles);
                  lastFetchedTimeRef.current = latestCandle.time as number;
                } catch {
                  candleSeriesRef.current.setData(formattedCandles);
                }
              }
            }

            const latest = rawCandles[rawCandles.length - 1];
            const first = rawCandles[0];
            setLastPrice(latest.close);
            const diff = latest.close - first.open;
            setPriceChange(diff);
            setPercentChange(first.open > 0 ? (diff / first.open) * 100 : 0);
            setLatencyMs(elapsed);
            setIsLiveActive(true);
          }
        }
      } catch {
        if (isMounted) setIsLiveActive(false);
      } finally {
        isFetchingRef.current = false;
      }
    };

    // Immediate initial fetch
    fetchIndependentData(true);

    // Dynamic high-speed update cycle (every 1000ms for real-time responsiveness)
    const interval = setInterval(() => {
      fetchIndependentData(false);
    }, 1000);

    return () => {
      isMounted = false;
      clearInterval(interval);
      if (retryTimeoutRef.current) clearTimeout(retryTimeoutRef.current);
    };
  }, [displaySymbol, timeframe]);

  return (
    <div className="w-full bg-[#060911] border border-slate-800/90 rounded-2xl overflow-hidden shadow-2xl relative font-sans flex flex-col select-none gpu-layer">
      {/* Top Header Bar */}
      <div className="bg-[#0a0f1d] px-3.5 py-2.5 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-2.5">
        {/* Symbol and Live Price Info */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-white text-base tracking-wide font-mono">
                  {displaySymbol}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-slate-800 text-slate-300 border border-slate-700">
                  {timeframe}M
                </span>
              </div>
            </div>
          </div>

          {lastPrice !== null && (
            <div className="flex items-baseline gap-2 font-mono">
              <span className="text-base font-bold text-white tracking-tight">
                {formatPrice(lastPrice)}
              </span>
              <span className={`text-xs font-semibold flex items-center gap-0.5 ${priceChange >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {priceChange >= 0 ? '+' : ''}{formatPrice(priceChange)} ({priceChange >= 0 ? '+' : ''}{percentChange.toFixed(2)}%)
              </span>
            </div>
          )}
        </div>

        {/* Status Badge & Interactive Controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 px-2.5 py-1 rounded-xl text-xs font-bold font-mono">
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            <span>شارت مباشر مستقل 100% (تغذية البنوك)</span>
          </div>

          <button
            type="button"
            onClick={() => setIsLocked(prev => !prev)}
            className={`p-1.5 rounded-lg border transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold ${
              isLocked
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'bg-slate-900/90 hover:bg-slate-800 text-slate-400 hover:text-white border-slate-800'
            }`}
            title={isLocked ? 'الأبعاد مثبتة ومحمية من اللمس (انقر لفك القفل)' : 'انقر لتثبيت الأبعاد ومنع تغييرها باللمس'}
          >
            {isLocked ? (
              <>
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-[10px] hidden sm:inline">أبعاد ثابتة 🔒</span>
              </>
            ) : (
              <>
                <Unlock className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-[10px] hidden sm:inline">حر 🔓</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleResetView}
            className="p-1.5 bg-slate-900/90 hover:bg-slate-800 text-slate-400 hover:text-cyan-400 rounded-lg border border-slate-800 transition-colors cursor-pointer"
            title="إعادة ضبط الرؤية لآخر شمعة"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={() => {
              if (chartRef.current) {
                chartRef.current.timeScale().scrollToRealTime();
              }
            }}
            className="p-1.5 bg-slate-900/90 hover:bg-slate-800 text-slate-400 hover:text-cyan-400 rounded-lg border border-slate-800 transition-colors cursor-pointer"
            title="تحديث الشارت الفوري"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Chart Canvas Area - Pure High-FPS Candlesticks */}
      <div className="w-full h-[480px] bg-[#060911] relative overflow-hidden">
        <div className="w-full h-full relative">
          {/* Anti-Accidental Touch/Scroll Lock Overlay */}
          {isLocked && (
            <div 
              className="absolute inset-0 z-20 select-none bg-transparent cursor-default pointer-events-auto"
              title="أبعاد الشارت والشموع مثبتة ومحمية من اللمس بالخطأ 🔒"
            />
          )}
          <div ref={chartContainerRef} className={`w-full h-full ${isLocked ? 'pointer-events-none' : 'pointer-events-auto'}`} />
          
          {/* Subtle Watermark */}
          <div className="absolute top-4 left-4 pointer-events-none z-10 opacity-15 flex flex-col">
            <span className="text-3xl font-black font-mono text-white tracking-widest">
              {displaySymbol}
            </span>
            <span className="text-xs font-mono text-cyan-400 font-bold">
              GOLDEN ROCKET • PURE CANDLESTICKS ENGINE
            </span>
          </div>
        </div>
      </div>

      {/* Footer System Status Bar with Live Telemetry */}
      <div className="bg-[#0a0f1d] px-3.5 py-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-[11px] font-mono text-slate-400 gap-2">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-emerald-400 font-bold">
            <span className={`w-2 h-2 rounded-full ${isLiveActive ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
            <span>سيرفرات الإنتربانك والبورصات الحية (Zero-Downtime Safe)</span>
          </span>
          <span className="text-slate-600">•</span>
          <span className="flex items-center gap-1 text-cyan-400 font-semibold">
            <Zap className="w-3 h-3 text-cyan-400" />
            <span>الاستجابة: {latencyMs}ms</span>
          </span>
          <span className="text-slate-600">•</span>
          <span className="flex items-center gap-1 text-indigo-400 font-semibold">
            <Activity className="w-3 h-3 text-indigo-400" />
            <span>{dataFeedSource}</span>
          </span>
        </div>

        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 text-emerald-400 font-bold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>0% OTC • 0% خارجي • 100% مستقل</span>
          </span>
        </div>
      </div>
    </div>
  );
};
