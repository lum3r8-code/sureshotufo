import React, { useEffect, useRef, useState } from 'react';
import { Terminal, Clock, Zap, ArrowUp, ArrowDown } from 'lucide-react';

interface BrokerTerminalChartProps {
  symbol: string;
  timeframe: string;
}

interface Candle {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
}

export const BrokerTerminalChart: React.FC<BrokerTerminalChartProps> = ({ symbol, timeframe }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const cleanPair = symbol.replace(/^(FX_IDC:|OANDA:|BINANCE:|FOREXCOM:|CAPITALCOM:|FX:)/, '').replace('/', '').toUpperCase();
  const isCrypto = cleanPair.includes('BTC') || cleanPair.includes('ETH');
  const isJpy = cleanPair.includes('JPY');

  const decimals = isCrypto ? 2 : isJpy ? 3 : 5;
  const basePrice = isCrypto ? 68450 : isJpy ? 152.40 : 1.08540;

  const [candles, setCandles] = useState<Candle[]>([]);
  const [currentPrice, setCurrentPrice] = useState<number>(basePrice);
  const [strikePrice, setStrikePrice] = useState<number>(basePrice);
  const [timerSec, setTimerSec] = useState<number>(58);
  const [isWinning, setIsWinning] = useState<boolean>(true);

  // Fetch and poll 100% real market candles from /api/klines (14 candles)
  useEffect(() => {
    let isMounted = true;

    const loadRealCandles = async () => {
      try {
        const res = await fetch(`/api/klines?symbol=${encodeURIComponent(cleanPair)}&timeframe=${encodeURIComponent(timeframe)}&limit=14`);
        if (res.ok) {
          const data = await res.json();
          if (data.success && Array.isArray(data.candles) && data.candles.length > 0 && isMounted) {
            setCandles(data.candles);
            const lastClose = data.candles[data.candles.length - 1].close;
            setCurrentPrice(lastClose);
            const firstCandleOpen = data.candles[0].open;
            setStrikePrice(prev => (prev === basePrice ? firstCandleOpen : prev));
            setIsWinning(lastClose >= firstCandleOpen);
          }
        }
      } catch (err) {
        // network issue, keep current real state
      }
    };

    loadRealCandles();
    const interval = setInterval(loadRealCandles, 1500);

    return () => { 
      isMounted = false; 
      clearInterval(interval);
    };
  }, [cleanPair, timeframe, basePrice]);

  // Wall-clock second sync for candle expiration
  useEffect(() => {
    const interval = setInterval(() => {
      const currentSec = new Date().getSeconds();
      setTimerSec(60 - currentSec);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Draw Candlesticks on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || candles.length === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    // Broker Terminal Theme Background
    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, width, height);

    const paddingRight = 60;
    const paddingBottom = 20;
    const chartWidth = width - paddingRight;
    const chartHeight = height - paddingBottom;

    const allHighs = candles.map(c => c.high);
    const allLows = candles.map(c => c.low);
    const minPrice = Math.min(...allLows);
    const maxPrice = Math.max(...allHighs);
    const priceRange = maxPrice - minPrice || 0.0001;

    // Grid Lines
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 0.5;
    ctx.setLineDash([3, 3]);

    for (let r = 0; r <= 5; r++) {
      const y = (chartHeight / 5) * r;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(chartWidth, y);
      ctx.stroke();

      const priceVal = maxPrice - (priceRange / 5) * r;
      ctx.fillStyle = '#64748b';
      ctx.font = '10px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(priceVal.toFixed(decimals), chartWidth + 5, y + 3);
    }
    ctx.setLineDash([]);

    // Draw Candlesticks
    const candleCount = candles.length;
    const candleWidth = (chartWidth / candleCount) * 0.72;
    const candleGap = (chartWidth / candleCount) * 0.28;

    candles.forEach((c, i) => {
      const x = i * (candleWidth + candleGap) + candleGap / 2;

      const yOpen = chartHeight - ((c.open - minPrice) / priceRange) * (chartHeight - 20) - 10;
      const yClose = chartHeight - ((c.close - minPrice) / priceRange) * (chartHeight - 20) - 10;
      const yHigh = chartHeight - ((c.high - minPrice) / priceRange) * (chartHeight - 20) - 10;
      const yLow = chartHeight - ((c.low - minPrice) / priceRange) * (chartHeight - 20) - 10;

      const isBullish = c.close >= c.open;
      const candleColor = isBullish ? '#10b981' : '#f43f5e';

      // Wicks
      ctx.strokeStyle = candleColor;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(x + candleWidth / 2, yHigh);
      ctx.lineTo(x + candleWidth / 2, yLow);
      ctx.stroke();

      // Body
      const bodyTop = Math.min(yOpen, yClose);
      const bodyHeight = Math.max(Math.abs(yOpen - yClose), 2);

      ctx.fillStyle = candleColor;
      ctx.fillRect(x, bodyTop, candleWidth, bodyHeight);
    });

    // Draw Strike Price Line (Yellow Horizontal)
    const strikeY = chartHeight - ((strikePrice - minPrice) / priceRange) * (chartHeight - 20) - 10;
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(0, strikeY);
    ctx.lineTo(chartWidth, strikeY);
    ctx.stroke();
    ctx.setLineDash([]);

    // Live Price Line & Badge
    const lastCandle = candles[candles.length - 1];
    const liveY = chartHeight - ((lastCandle.close - minPrice) / priceRange) * (chartHeight - 20) - 10;
    const liveColor = lastCandle.close >= strikePrice ? '#10b981' : '#f43f5e';

    ctx.strokeStyle = liveColor;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, liveY);
    ctx.lineTo(chartWidth, liveY);
    ctx.stroke();

    ctx.fillStyle = liveColor;
    ctx.fillRect(chartWidth, liveY - 10, paddingRight, 20);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(lastCandle.close.toFixed(decimals), chartWidth + paddingRight / 2, liveY + 3);

  }, [candles, decimals, strikePrice]);

  return (
    <div className="w-full h-[430px] bg-slate-950 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between relative overflow-hidden font-sans">
      {/* Top Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-2 z-10">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400">
            <Terminal className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-white font-mono">{cleanPair}</span>
              <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded font-mono font-bold">
                Broker Execution Candlesticks (Deriv & Dukascopy SWFX Bridge) ⚡
              </span>
            </div>
            <span className="text-[11px] text-slate-400">شارت الشموع التنفيذي المباشر (عرض الـ 14 شمعة الأخيرة 🕯️)</span>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-amber-950/40 border border-amber-500/40 px-3 py-1 rounded-lg text-amber-400 font-mono font-bold text-xs">
          <Clock className="w-4 h-4 animate-spin" />
          <span>إغلاق الشمعة: 00:{timerSec < 10 ? `0${timerSec}` : timerSec}s</span>
        </div>
      </div>

      {/* Canvas Candlestick Chart */}
      <div className="relative flex-1 my-1 w-full h-full">
        <canvas ref={canvasRef} className="w-full h-full block" />
      </div>

      {/* Footer Execution Bar */}
      <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-mono">سعر Strike:</span>
          <span className="font-mono font-bold text-amber-400 bg-amber-950/40 px-2 py-0.5 rounded border border-amber-500/30">
            {strikePrice.toFixed(decimals)}
          </span>
        </div>

        <div className={`font-mono font-bold px-3 py-1 rounded-full text-xs ${
          isWinning 
            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50' 
            : 'bg-rose-500/20 text-rose-300 border border-rose-500/50'
        }`}>
          {isWinning ? 'منطقة أرباح الشمعة (In The Money 🟢)' : 'خارج منطقة الأرباح 🔴'}
        </div>

        <div className="flex items-center gap-1.5 text-emerald-400 font-mono font-bold text-xs">
          <Zap className="w-3.5 h-3.5" />
          <span>عائد: 94%</span>
        </div>
      </div>
    </div>
  );
};
