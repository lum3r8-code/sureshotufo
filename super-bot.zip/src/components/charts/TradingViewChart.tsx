import React, { useState, useMemo, useCallback, useRef } from 'react';
import { 
  RefreshCw, 
  Maximize2, 
  Minimize2, 
  ShieldCheck, 
  Zap, 
  Activity, 
  CheckCircle2,
  Lock,
  Unlock
} from 'lucide-react';

interface TradingViewChartProps {
  symbol: string;
  timeframe: string;
  onTimeframeChange?: (tf: string) => void;
  onGrsClick?: () => void;
  isGrsSending?: boolean;
  isGrs247Active?: boolean;
}

export const TradingViewChart: React.FC<TradingViewChartProps> = ({
  symbol,
  timeframe,
  onTimeframeChange,
  onGrsClick,
  isGrsSending,
  isGrs247Active
}) => {
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [refreshKey, setRefreshKey] = useState<number>(0);
  const [isLocked, setIsLocked] = useState<boolean>(true);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Normalize symbol to exact TradingView ticker syntax
  const tvSymbol = useMemo(() => {
    const s = (symbol || 'FX_IDC:EURUSD').trim();
    if (s.includes(':')) return s;
    
    const upper = s.toUpperCase().replace('/', '');
    if (upper.includes('BTC') || upper.includes('ETH') || upper.includes('SOL')) {
      return `BINANCE:${upper.endsWith('USDT') ? upper : upper + 'USDT'}`;
    }
    if (upper.includes('XAU') || upper.includes('GOLD')) {
      return 'OANDA:XAUUSD';
    }
    return `FX_IDC:${upper}`;
  }, [symbol]);

  // Map timeframe to standard TradingView interval
  const tvInterval = useMemo(() => {
    const raw = String(timeframe || '1').replace(/\D/g, '');
    if (['1', '3', '5', '15', '30', '45', '60', '120', '240'].includes(raw)) {
      return raw;
    }
    return '1';
  }, [timeframe]);

  // Construct official TradingView Advanced Real-Time Chart embed URL without toolbars
  const widgetUrl = useMemo(() => {
    const params = new URLSearchParams({
      symbol: tvSymbol,
      interval: tvInterval,
      theme: 'dark',
      style: '1', // Style 1 = Exact Japanese Candlesticks (الشموع اليابانية الأصلية)
      timezone: 'Africa/Tunis',
      locale: 'ar_AE',
      toolbarbg: '060911',
      hide_top_toolbar: '1', // إخفاء شريط الأدوات العلوي بالكامل
      hide_side_toolbar: '1', // إخفاء شريط أدوات الرسم الجانبي بالكامل
      hide_legend: '0',
      hide_volume: '1', // إخفاء مؤشر الفوليوم Vol نهائياً
      hidevolume: '1',
      showVolume: 'false',
      allow_symbol_change: '0',
      saveimage: '0',
      withdateranges: '0',
      details: '0',
      hotlist: '0',
      calendar: '0',
      studies: '[]'
    });
    return `https://s.tradingview.com/widgetembed/?${params.toString()}`;
  }, [tvSymbol, tvInterval]);

  const handleRefresh = useCallback(() => {
    setRefreshKey(prev => prev + 1);
  }, []);

  const toggleFullscreen = useCallback(() => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen?.().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.().catch(() => {});
      setIsFullscreen(false);
    }
  }, []);

  return (
    <div 
      ref={containerRef}
      className={`w-full bg-[#060911] border border-slate-800/80 flex flex-col relative transition-all ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none h-screen' : 'rounded-none sm:rounded-xl overflow-hidden shadow-2xl'
      }`}
    >
      {/* Floating Controls: Fullscreen & Lock Chart Dimensions */}
      <div className="absolute top-2.5 left-2.5 z-30 flex items-center gap-1.5">
        <button
          id="tradingview-chart-fullscreen-btn"
          onClick={toggleFullscreen}
          className="p-1.5 bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg border border-slate-700/60 shadow-lg backdrop-blur-sm transition-all cursor-pointer"
          title={isFullscreen ? 'تصغير الشاشة' : 'تكبير الشاشة'}
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>

        <button
          id="tradingview-chart-lock-btn"
          onClick={() => setIsLocked(prev => !prev)}
          className={`p-1.5 rounded-lg border shadow-lg backdrop-blur-sm transition-all cursor-pointer flex items-center gap-1 text-xs font-bold ${
            isLocked 
              ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border-amber-500/50 shadow-amber-500/20' 
              : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white border-slate-700/60'
          }`}
          title={isLocked ? 'الشارت مثبت ومقفل لحمايته من أي لمس بالخطأ (انقر لإلغاء القفل)' : 'انقر لتثبيت وقفل أبعاد الشارت والشموع'}
        >
          {isLocked ? (
            <>
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-[10px] hidden sm:inline">أبعاد ثابتة 🔒</span>
            </>
          ) : (
            <>
              <Unlock className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[10px] hidden sm:inline">حر 🔓</span>
            </>
          )}
        </button>
      </div>

      {/* Official Embedded Chart Iframe */}
      <div className="relative w-full flex-1 min-h-[500px] sm:min-h-[550px] md:min-h-[600px] bg-[#060911]">
        {/* Anti-Accidental Touch/Scroll Lock Overlay */}
        {isLocked && (
          <div 
            className="absolute inset-0 z-10 select-none bg-transparent cursor-default"
            title="أبعاد الشارت والشموع مثبتة ومحمية من اللمس بالخطأ 🔒"
          />
        )}
        <iframe
          key={`${tvSymbol}_${tvInterval}_${refreshKey}`}
          title={`TradingView Advanced Chart - ${tvSymbol}`}
          src={widgetUrl}
          className={`w-full h-full min-h-[500px] sm:min-h-[550px] md:min-h-[600px] border-0 ${
            isLocked ? 'pointer-events-none' : 'pointer-events-auto'
          }`}
          loading="eager"
          allow="fullscreen"
        />
      </div>
    </div>
  );
};
