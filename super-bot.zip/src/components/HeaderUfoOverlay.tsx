import React, { useEffect, useRef } from 'react';

interface UFO {
  active: boolean;
  x: number;
  y: number;
  vx: number;
  direction: number; // 1: Left -> Right, -1: Right -> Left
  type: number; // 0 to 23 (24 distinct craft models)
  scale: number;
}

export const HeaderUfoOverlay: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || window.innerWidth);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 64);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };
    window.addEventListener('resize', handleResize);

    let ufoModelIndex = 0;
    let lastAutoLaunch = Date.now();
    const ufoInterval = 8 * 60 * 1000; // 8 minutes

    // 🌟 Ultra Pro High-Refresh Gaming Rate: 144 FPS (6.944ms per frame)
    const TARGET_FPS = 144;
    const FRAME_INTERVAL_MS = 1000 / TARGET_FPS; // 6.944 ms per frame
    let lastRenderTimestamp = performance.now();

    const ufo: UFO = {
      active: false,
      x: -220,
      y: height / 2,
      vx: 2.2,
      direction: 1,
      type: 0,
      scale: 1.1
    };

    const launchUfo = () => {
      ufo.active = true;
      ufo.type = ufoModelIndex % 24; // Cycles guaranteed through 24 distinct craft models!
      ufoModelIndex++;

      ufo.direction = Math.random() > 0.5 ? 1 : -1;
      ufo.x = ufo.direction === 1 ? -220 : width + 220;
      ufo.y = height * 0.5; // Centered flyby directly behind title and icons
      ufo.vx = (2.0 + Math.random() * 0.8) * ufo.direction;
      ufo.scale = 1.0 + Math.random() * 0.25;

      lastAutoLaunch = Date.now();
    };

    // Trigger initial showcase UFO launch 1 second after load
    const initTimer = setTimeout(() => {
      launchUfo();
    }, 1000);

    // Event listener for title click
    const handleTrigger = () => {
      launchUfo();
    };
    window.addEventListener('trigger-ufo-launch', handleTrigger);

    const render = (currentTimestamp: number) => {
      animationFrameId = requestAnimationFrame(render);

      const elapsed = currentTimestamp - lastRenderTimestamp;
      if (elapsed < FRAME_INTERVAL_MS - 0.3) {
        return; // Lock to 144 FPS Pro Refresh Rate
      }

      lastRenderTimestamp = currentTimestamp - (elapsed % FRAME_INTERVAL_MS);

      ctx.clearRect(0, 0, width, height);

      const now = Date.now();

      // Auto trigger every 8 minutes
      if (!ufo.active && now - lastAutoLaunch >= ufoInterval) {
        launchUfo();
      }

      if (ufo.active) {
        ctx.save();

        // 144 FPS Ultra-Smooth Organic Gliding Wave Motion
        const hoverY = ufo.y + Math.sin(now / 260) * 6;
        const tiltAngle = Math.cos(now / 200) * 0.05 * ufo.direction;

        ctx.translate(ufo.x, hoverY);
        ctx.scale(ufo.scale, ufo.scale);
        ctx.rotate(tiltAngle);

        const time = now / 1000;

        // 🌟 24 DISTINCT REALISTIC CRAFT MODELS RENDERER MATRIX
        switch (ufo.type) {
          case 0: {
            // MODEL 0: Cyberpunk Flying Saucer
            const beamGrad = ctx.createLinearGradient(0, 0, 0, 50);
            beamGrad.addColorStop(0, 'rgba(56, 189, 248, 0.65)');
            beamGrad.addColorStop(1, 'rgba(56, 189, 248, 0.0)');
            ctx.fillStyle = beamGrad;
            ctx.beginPath();
            ctx.moveTo(-14, 4); ctx.lineTo(14, 4); ctx.lineTo(40, 50); ctx.lineTo(-40, 50);
            ctx.closePath(); ctx.fill();

            ctx.shadowBlur = 18; ctx.shadowColor = '#38bdf8';
            const domeGrad = ctx.createRadialGradient(0, -6, 2, 0, -6, 14);
            domeGrad.addColorStop(0, '#f43f5e'); domeGrad.addColorStop(0.6, '#a855f7'); domeGrad.addColorStop(1, '#38bdf8');
            ctx.fillStyle = domeGrad; ctx.beginPath(); ctx.arc(0, -4, 14, Math.PI, 0, false); ctx.fill();

            const hullGrad = ctx.createLinearGradient(-48, 0, 48, 0);
            hullGrad.addColorStop(0, '#0284c7'); hullGrad.addColorStop(0.5, '#e879f9'); hullGrad.addColorStop(1, '#1e1b4b');
            ctx.fillStyle = hullGrad; ctx.beginPath(); ctx.ellipse(0, 2, 48, 12, 0, 0, Math.PI * 2); ctx.fill();

            for (let i = 0; i < 6; i++) {
              const angle = time * 4.5 + (i * Math.PI / 3);
              const lx = Math.cos(angle) * 38; const ly = Math.sin(angle) * 6 + 2;
              ctx.fillStyle = (i % 2 === 0) ? '#fde047' : '#38bdf8';
              ctx.shadowBlur = 10; ctx.shadowColor = ctx.fillStyle;
              ctx.beginPath(); ctx.arc(lx, ly, 3, 0, Math.PI * 2); ctx.fill();
            }
            break;
          }

          case 1: {
            // MODEL 1: Triangular Stealth Mothership
            ctx.shadowBlur = 20; ctx.shadowColor = '#a855f7';
            ctx.fillStyle = 'rgba(168, 85, 247, 0.75)';
            ctx.beginPath(); ctx.moveTo(-ufo.direction * 35, -3); ctx.lineTo(-ufo.direction * 80, -9); ctx.lineTo(-ufo.direction * 80, 9); ctx.closePath(); ctx.fill();

            const hullGrad = ctx.createLinearGradient(-40, -14, 40, 14);
            hullGrad.addColorStop(0, '#0f172a'); hullGrad.addColorStop(0.5, '#7e22ce'); hullGrad.addColorStop(1, '#3b0764');
            ctx.fillStyle = hullGrad; ctx.strokeStyle = '#e879f9'; ctx.lineWidth = 1.8;
            ctx.beginPath(); ctx.moveTo(ufo.direction * 46, 0); ctx.lineTo(-ufo.direction * 32, -18); ctx.lineTo(-ufo.direction * 20, 0); ctx.lineTo(-ufo.direction * 32, 18); ctx.closePath(); ctx.fill(); ctx.stroke();

            ctx.fillStyle = '#f43f5e'; ctx.shadowBlur = 14; ctx.shadowColor = '#f43f5e';
            ctx.beginPath(); ctx.arc(0, 0, 6, 0, Math.PI * 2); ctx.fill();
            break;
          }

          case 2: {
            // MODEL 2: Quantum Energy Orb
            ctx.shadowBlur = 25; ctx.shadowColor = '#38bdf8';
            ctx.strokeStyle = '#38bdf8'; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.ellipse(0, 0, 30, 9, time * 3, 0, Math.PI * 2); ctx.stroke();
            ctx.strokeStyle = '#f43f5e';
            ctx.beginPath(); ctx.ellipse(0, 0, 30, 9, -time * 3.5, 0, Math.PI * 2); ctx.stroke();

            const coreGrad = ctx.createRadialGradient(0, 0, 2, 0, 0, 15);
            coreGrad.addColorStop(0, '#ffffff'); coreGrad.addColorStop(0.5, '#38bdf8'); coreGrad.addColorStop(1, '#0369a1');
            ctx.fillStyle = coreGrad; ctx.beginPath(); ctx.arc(0, 0, 15, 0, Math.PI * 2); ctx.fill();
            break;
          }

          case 3: {
            // MODEL 3: Emerald Diamond Interceptor
            ctx.shadowBlur = 20; ctx.shadowColor = '#10b981';
            const diamondGrad = ctx.createLinearGradient(-35, 0, 35, 0);
            diamondGrad.addColorStop(0, '#064e3b'); diamondGrad.addColorStop(0.5, '#34d399'); diamondGrad.addColorStop(1, '#022c22');
            ctx.fillStyle = diamondGrad;
            ctx.beginPath(); ctx.moveTo(0, -16); ctx.lineTo(44, 0); ctx.lineTo(0, 16); ctx.lineTo(-44, 0); ctx.closePath(); ctx.fill();

            ctx.fillStyle = '#a7f3d0'; ctx.beginPath(); ctx.ellipse(0, -1, 16, 6, 0, 0, Math.PI * 2); ctx.fill();
            break;
          }

          case 4: {
            // MODEL 4: Solar Gold Mothership
            ctx.shadowBlur = 22; ctx.shadowColor = '#f59e0b';
            const goldGrad = ctx.createLinearGradient(-45, 0, 45, 0);
            goldGrad.addColorStop(0, '#78350f'); goldGrad.addColorStop(0.5, '#fbbf24'); goldGrad.addColorStop(1, '#d97706');
            ctx.fillStyle = goldGrad;
            // Hexagonal chassis
            ctx.beginPath();
            for (let i = 0; i < 6; i++) {
              const a = (i * Math.PI) / 3;
              const x = Math.cos(a) * 42; const y = Math.sin(a) * 12;
              if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
            }
            ctx.closePath(); ctx.fill();
            // Golden Dome
            ctx.fillStyle = '#fef08a'; ctx.beginPath(); ctx.arc(0, -5, 12, Math.PI, 0, false); ctx.fill();
            break;
          }

          case 5: {
            // MODEL 5: Plasma Twin-Fuselage Corvette
            ctx.shadowBlur = 18; ctx.shadowColor = '#06b6d4';
            ctx.fillStyle = '#0f172a'; ctx.strokeStyle = '#22d3ee'; ctx.lineWidth = 1.5;
            // Left pod
            ctx.beginPath(); ctx.ellipse(-18, 0, 24, 7, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
            // Right pod
            ctx.beginPath(); ctx.ellipse(18, 0, 24, 7, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
            // Connecting bridge
            ctx.fillStyle = '#0284c7'; ctx.fillRect(-12, -3, 24, 6);
            break;
          }

          case 6: {
            // MODEL 6: Hyperion Ring Cruiser
            ctx.shadowBlur = 24; ctx.shadowColor = '#ec4899';
            ctx.strokeStyle = '#f43f5e'; ctx.lineWidth = 5;
            ctx.beginPath(); ctx.ellipse(0, 0, 40, 11, 0, 0, Math.PI * 2); ctx.stroke();
            // Glowing core sphere floating in center
            ctx.fillStyle = '#f472b6'; ctx.beginPath(); ctx.arc(0, 0, 8, 0, Math.PI * 2); ctx.fill();
            break;
          }

          case 7: {
            // MODEL 7: Void Phantom Boomerang Fighter
            ctx.shadowBlur = 18; ctx.shadowColor = '#8b5cf6';
            ctx.fillStyle = '#1e1b4b'; ctx.strokeStyle = '#a855f7'; ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(ufo.direction * 45, 0);
            ctx.lineTo(-ufo.direction * 35, -20);
            ctx.lineTo(-ufo.direction * 15, 0);
            ctx.lineTo(-ufo.direction * 35, 20);
            ctx.closePath(); ctx.fill(); ctx.stroke();
            break;
          }

          case 8: {
            // MODEL 8: Galactic Saucer Dreadnought (Heavy Saucer Battleship)
            ctx.shadowBlur = 22; ctx.shadowColor = '#38bdf8';
            const hullGrad = ctx.createLinearGradient(-48, 0, 48, 0);
            hullGrad.addColorStop(0, '#1e293b'); hullGrad.addColorStop(0.5, '#64748b'); hullGrad.addColorStop(1, '#0f172a');
            ctx.fillStyle = hullGrad; ctx.strokeStyle = '#38bdf8'; ctx.lineWidth = 1.8;
            ctx.beginPath(); ctx.ellipse(0, 3, 48, 13, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();

            // Heavy Side Plasma Cannons
            ctx.fillStyle = '#f43f5e';
            ctx.fillRect(-42, -8, 7, 16); ctx.fillRect(35, -8, 7, 16);

            // Main Glass Bridge Tower
            ctx.fillStyle = '#38bdf8'; ctx.beginPath(); ctx.arc(0, -5, 11, Math.PI, 0, false); ctx.fill();
            break;
          }

          case 9: {
            // MODEL 9: Crimson Leviathan Dreadnought
            ctx.shadowBlur = 25; ctx.shadowColor = '#dc2626';
            const crimsonGrad = ctx.createLinearGradient(-50, 0, 50, 0);
            crimsonGrad.addColorStop(0, '#450a0a'); crimsonGrad.addColorStop(0.5, '#ef4444'); crimsonGrad.addColorStop(1, '#7f1d1d');
            ctx.fillStyle = crimsonGrad;
            ctx.beginPath(); ctx.ellipse(0, 0, 50, 14, 0, 0, Math.PI * 2); ctx.fill();
            // Dual side weapons
            ctx.fillStyle = '#fca5a5';
            ctx.fillRect(-35, -12, 6, 24); ctx.fillRect(29, -12, 6, 24);
            break;
          }

          case 10: {
            // MODEL 10: Neon Cyber-Arrow
            ctx.shadowBlur = 20; ctx.shadowColor = '#0284c7';
            ctx.fillStyle = '#0f172a'; ctx.strokeStyle = '#38bdf8'; ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(ufo.direction * 52, 0);
            ctx.lineTo(-ufo.direction * 20, -14);
            ctx.lineTo(-ufo.direction * 30, -6);
            ctx.lineTo(-ufo.direction * 30, 6);
            ctx.lineTo(-ufo.direction * 20, 14);
            ctx.closePath(); ctx.fill(); ctx.stroke();
            break;
          }

          case 11: {
            // MODEL 11: Bio-Luminescent Alien Manta Ray
            ctx.shadowBlur = 22; ctx.shadowColor = '#d946ef';
            const bioGrad = ctx.createLinearGradient(-40, 0, 40, 0);
            bioGrad.addColorStop(0, '#701a75'); bioGrad.addColorStop(0.5, '#f0abfc'); bioGrad.addColorStop(1, '#4a044e');
            ctx.fillStyle = bioGrad;
            ctx.beginPath();
            ctx.moveTo(ufo.direction * 40, 0);
            ctx.quadraticCurveTo(0, -22, -ufo.direction * 35, 0);
            ctx.quadraticCurveTo(0, 22, ufo.direction * 40, 0);
            ctx.fill();
            // Bioluminescent spots
            ctx.fillStyle = '#38bdf8';
            ctx.beginPath(); ctx.arc(-10, -5, 2.5, 0, Math.PI * 2); ctx.arc(-10, 5, 2.5, 0, Math.PI * 2); ctx.fill();
            break;
          }

          case 12: {
            // MODEL 12: Supernova Multi-Dome Cruiser
            ctx.shadowBlur = 20; ctx.shadowColor = '#eab308';
            ctx.fillStyle = '#334155'; ctx.beginPath(); ctx.ellipse(0, 3, 46, 10, 0, 0, Math.PI * 2); ctx.fill();
            // Triple domes
            ctx.fillStyle = '#fde047';
            ctx.beginPath(); ctx.arc(-18, -2, 7, Math.PI, 0, false); ctx.arc(0, -4, 10, Math.PI, 0, false); ctx.arc(18, -2, 7, Math.PI, 0, false); ctx.fill();
            break;
          }

          case 13: {
            // MODEL 13: Titan Quad-Engine Fighter
            ctx.shadowBlur = 20; ctx.shadowColor = '#f97316';
            ctx.fillStyle = '#1e293b'; ctx.beginPath(); ctx.ellipse(0, 0, 36, 12, 0, 0, Math.PI * 2); ctx.fill();
            // 4 Exhaust flames
            ctx.fillStyle = '#ffedd5'; ctx.shadowColor = '#f97316';
            [-22, -10, 10, 22].forEach(pos => {
              ctx.beginPath(); ctx.arc(-ufo.direction * 25, pos / 2, 3, 0, Math.PI * 2); ctx.fill();
            });
            break;
          }

          case 14: {
            // MODEL 14: Vortex Gravity Spinning Disk
            ctx.shadowBlur = 26; ctx.shadowColor = '#8b5cf6';
            ctx.save(); ctx.rotate(time * 5);
            ctx.fillStyle = '#581c87'; ctx.beginPath(); ctx.ellipse(0, 0, 38, 38, 0, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#c084fc'; ctx.lineWidth = 2;
            for (let i = 0; i < 8; i++) {
              const a = (i * Math.PI) / 4;
              ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a) * 38, Math.sin(a) * 38); ctx.stroke();
            }
            ctx.restore();
            break;
          }

          case 15: {
            // MODEL 15: Celestial Crystal Needle
            ctx.shadowBlur = 22; ctx.shadowColor = '#67e8f9';
            const crystalGrad = ctx.createLinearGradient(-55, 0, 55, 0);
            crystalGrad.addColorStop(0, '#155e75'); crystalGrad.addColorStop(0.5, '#a5f3fc'); crystalGrad.addColorStop(1, '#0e7490');
            ctx.fillStyle = crystalGrad;
            ctx.beginPath();
            ctx.moveTo(ufo.direction * 55, 0);
            ctx.lineTo(-ufo.direction * 40, -6);
            ctx.lineTo(-ufo.direction * 40, 6);
            ctx.closePath(); ctx.fill();
            break;
          }

          case 16: {
            // MODEL 16: Obsidian Hammerhead Stealth
            ctx.shadowBlur = 18; ctx.shadowColor = '#ef4444';
            ctx.fillStyle = '#020617'; ctx.strokeStyle = '#f87171'; ctx.lineWidth = 1.8;
            // T-bar Hammerhead
            ctx.beginPath();
            ctx.moveTo(ufo.direction * 35, -16); ctx.lineTo(ufo.direction * 35, 16);
            ctx.lineTo(ufo.direction * 25, 16); ctx.lineTo(-ufo.direction * 30, 5);
            ctx.lineTo(-ufo.direction * 30, -5); ctx.lineTo(ufo.direction * 25, -16);
            ctx.closePath(); ctx.fill(); ctx.stroke();
            break;
          }

          case 17: {
            // MODEL 17: Pulsar Double-Helix Interceptor
            ctx.shadowBlur = 24; ctx.shadowColor = '#ec4899';
            ctx.strokeStyle = '#f472b6'; ctx.lineWidth = 3;
            ctx.beginPath();
            for (let x = -35; x <= 35; x += 2) {
              const y = Math.sin((x / 10) + time * 6) * 8;
              if (x === -35) ctx.moveTo(x, y); else ctx.lineTo(x, y);
            }
            ctx.stroke();
            ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(0, 0, 7, 0, Math.PI * 2); ctx.fill();
            break;
          }

          case 18: {
            // MODEL 18: Aegis Hex Shield Drone
            ctx.shadowBlur = 22; ctx.shadowColor = '#3b82f6';
            ctx.strokeStyle = '#60a5fa'; ctx.lineWidth = 2;
            ctx.beginPath();
            for (let i = 0; i < 6; i++) {
              const a = (i * Math.PI) / 3;
              const x = Math.cos(a) * 30; const y = Math.sin(a) * 16;
              if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
            }
            ctx.closePath(); ctx.stroke();
            ctx.fillStyle = '#93c5fd'; ctx.beginPath(); ctx.arc(0, 0, 10, 0, Math.PI * 2); ctx.fill();
            break;
          }

          case 19: {
            // MODEL 19: Apex Viper Forward-Swept Wing
            ctx.shadowBlur = 20; ctx.shadowColor = '#84cc16';
            ctx.fillStyle = '#14532d'; ctx.strokeStyle = '#a3e635'; ctx.lineWidth = 1.8;
            ctx.beginPath();
            ctx.moveTo(ufo.direction * 40, 0);
            ctx.lineTo(ufo.direction * 10, -22);
            ctx.lineTo(-ufo.direction * 30, 0);
            ctx.lineTo(ufo.direction * 10, 22);
            ctx.closePath(); ctx.fill(); ctx.stroke();
            break;
          }

          case 20: {
            // MODEL 20: Omega Star-Destroyer Saucer
            ctx.shadowBlur = 25; ctx.shadowColor = '#a855f7';
            ctx.fillStyle = '#312e81'; ctx.beginPath(); ctx.ellipse(0, 4, 52, 11, 0, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#c084fc'; ctx.beginPath(); ctx.ellipse(0, -3, 28, 8, 0, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(0, -7, 4, 0, Math.PI * 2); ctx.fill();
            break;
          }

          case 21: {
            // MODEL 21: Cosmic Prism Pyramidal Scout
            ctx.shadowBlur = 22; ctx.shadowColor = '#f43f5e';
            const prismGrad = ctx.createLinearGradient(-25, -20, 25, 20);
            prismGrad.addColorStop(0, '#f43f5e'); prismGrad.addColorStop(0.5, '#fbbf24'); prismGrad.addColorStop(1, '#38bdf8');
            ctx.fillStyle = prismGrad;
            ctx.beginPath(); ctx.moveTo(0, -20); ctx.lineTo(32, 14); ctx.lineTo(-32, 14); ctx.closePath(); ctx.fill();
            break;
          }

          case 22: {
            // MODEL 22: Starlight Comet Teardrop Cruiser
            ctx.shadowBlur = 22; ctx.shadowColor = '#e0f2fe';
            // Stardust Tail
            const tailGrad = ctx.createLinearGradient(0, 0, -ufo.direction * 80, 0);
            tailGrad.addColorStop(0, 'rgba(224, 242, 254, 0.8)'); tailGrad.addColorStop(1, 'rgba(224, 242, 254, 0)');
            ctx.fillStyle = tailGrad; ctx.fillRect(-ufo.direction * 80, -4, 80, 8);
            // Teardrop Head
            ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(ufo.direction * 15, 0, 10, 0, Math.PI * 2); ctx.fill();
            break;
          }

          default: {
            // MODEL 23: Sovereign Crown Flagship
            ctx.shadowBlur = 28; ctx.shadowColor = '#fbbf24';
            ctx.fillStyle = '#78350f'; ctx.strokeStyle = '#fde047'; ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(-35, 10); ctx.lineTo(-35, -5); ctx.lineTo(-18, 5);
            ctx.lineTo(0, -15); ctx.lineTo(18, 5); ctx.lineTo(35, -5); ctx.lineTo(35, 10);
            ctx.closePath(); ctx.fill(); ctx.stroke();
            // Multi-color Crown Jewels
            ctx.fillStyle = '#f43f5e'; ctx.beginPath(); ctx.arc(-35, -5, 3, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#38bdf8'; ctx.beginPath(); ctx.arc(0, -15, 4, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#f43f5e'; ctx.beginPath(); ctx.arc(35, -5, 3, 0, Math.PI * 2); ctx.fill();
            break;
          }
        }

        ctx.restore();

        ufo.x += ufo.vx;

        if ((ufo.direction === 1 && ufo.x > width + 240) || (ufo.direction === -1 && ufo.x < -240)) {
          ufo.active = false;
        }
      }
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      clearTimeout(initTimer);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('trigger-ufo-launch', handleTrigger);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
      <canvas 
        ref={canvasRef} 
        className="w-full h-full pointer-events-none" 
      />
    </div>
  );
};
