import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  Sparkles, 
  X, 
  Maximize2, 
  Minimize2, 
  Radio, 
  Globe, 
  Wifi, 
  ShieldCheck,
  Flame,
  Volume2
} from 'lucide-react';
import { UndercoverAgentLab } from './UndercoverAgentLab';
import { DefjayRadio } from './DefjayRadio';

interface SulionCupModalProps {
  isOpen: boolean;
  onClose: () => void;
  userChatId?: string;
}

const LiveClock: React.FC = () => {
  const [time, setTime] = useState(() => new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex items-center gap-1.5 text-[10px] sm:text-xs font-mono font-black text-emerald-400 drop-shadow-md tracking-wider px-1">
      <span className="hidden sm:inline">{time.toLocaleDateString('en-GB')}</span>
      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.8)] shrink-0"></span>
      <span>{time.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
    </div>
  );
};

export const SulionCupModal: React.FC<SulionCupModalProps> = ({ isOpen, onClose }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isRadioOpen, setIsRadioOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [onlineCount, setOnlineCount] = useState<number>(3);

  // Fetch or poll active user count
  useEffect(() => {
    if (!isOpen) return;
    const fetchStats = async () => {
      try {
        const res = await fetch('/api/app/stats');
        const data = await res.json();
        if (data && typeof data.activeUsers === 'number') {
          setOnlineCount(Math.max(1, data.activeUsers));
        }
      } catch {
        // Fallback smooth number
      }
    };
    fetchStats();
    const interval = setInterval(fetchStats, 8000);
    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className={`fixed inset-0 z-[100] flex items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-xl animate-fade-in transition-all duration-300 ${isFullscreen ? 'p-0' : ''}`}>
      <div 
        className={`relative bg-gradient-to-b from-slate-900 via-slate-950 to-amber-950/30 border border-amber-500/40 rounded-2xl shadow-2xl shadow-amber-500/20 text-slate-100 overflow-hidden flex flex-col transition-all duration-300 ${
          isFullscreen ? 'w-full h-full rounded-none border-0' : 'w-[98vw] max-w-7xl h-[92vh]'
        }`}
        onClick={e => e.stopPropagation()}
      >
        {/* Top Gold Glowing Bar */}
        <div className="h-1.5 bg-gradient-to-r from-amber-500 via-yellow-300 to-amber-600 w-full shrink-0" />

        {/* Modal Top Control Header */}
        <header className="px-4 py-3 border-b border-amber-500/20 bg-slate-900/95 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 p-[1.5px] shadow-lg shadow-amber-500/25 shrink-0 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center text-amber-400">
                <Trophy className="w-5 h-5 text-amber-300 animate-pulse" />
              </div>
            </div>
            
            <div className="flex flex-col">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-base sm:text-lg font-black tracking-wider text-amber-300 flex items-center gap-1.5 select-none">
                  <span>Sulion Cup</span>
                  <Sparkles className="w-4 h-4 text-amber-400 inline" />
                </h1>
                <span className="px-2 py-0.5 rounded-md text-[10px] sm:text-[11px] font-black tracking-widest bg-gradient-to-r from-emerald-600/30 via-teal-600/40 to-cyan-600/30 text-emerald-300 border border-emerald-400/50 shadow-xs font-mono select-none">
                  LIVE MATCH ANALYSIS
                </span>

                {/* Real-time Clock */}
                <LiveClock />
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-300 font-medium tracking-wide hidden sm:block mt-0.5">
                منصة تحليل وتوقع نتائج البطولات العالمية بنظام SULION CUP الذكي — حصر المقابلات القادمة غير المبتدئة فقط
              </p>
            </div>
          </div>

          {/* Action Tools */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Our Main Application Button (replaces old external link) */}
            <a
              href={typeof window !== 'undefined' ? window.location.origin : '/'}
              onClick={(e) => {
                if (typeof window !== 'undefined' && window.location.pathname === '/') {
                  e.preventDefault();
                  onClose();
                }
              }}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs shadow-md shadow-emerald-950/40 border border-emerald-400/50 transition-all cursor-pointer group shrink-0"
              title="العودة لتطبيقنا الأساسي (منصة التداول SURESHOT UFO VIP)"
            >
              <Globe className="w-3.5 h-3.5 group-hover:rotate-12 transition-transform shrink-0" />
              <span>تطبيقنا الأساسي</span>
              <span className="hidden md:inline text-[10px] font-mono text-emerald-200">SURESHOT</span>
            </a>

            {/* Live Radio Player Button */}
            <button
              onClick={() => setIsRadioOpen(true)}
              className="flex items-center justify-center gap-1 p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-amber-400 hover:text-amber-300 border border-amber-500/30 hover:border-amber-500/60 shadow-sm transition-all cursor-pointer group shrink-0"
              title="مشغل الراديو والموسيقى"
            >
              <Radio className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform shrink-0" />
              <Volume2 className="hidden sm:block w-3.5 h-3.5 text-slate-400 group-hover:text-white shrink-0" />
            </button>

            {/* Fullscreen Button */}
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-all border border-slate-700/60 cursor-pointer shrink-0"
              title={isFullscreen ? "تصغير الحجم" : "تكبير للشاشة الكاملة"}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            {/* Close Modal Button */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 hover:text-white transition-all border border-rose-800/50 cursor-pointer shrink-0"
              title="إغلاق النافذة"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Native Main Content Area */}
        <div className="flex-1 w-full overflow-y-auto p-3 sm:p-5 bg-slate-950">
          <UndercoverAgentLab forcedModule="FOOTBALL_PREDICTIONS" hideModuleSwitcher={true} />
        </div>

        {/* Modal Status Footer */}
        <footer className="px-4 py-2.5 bg-slate-900/95 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400 font-mono shrink-0">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <div className="flex items-center gap-1.5 text-slate-300">
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span className="font-bold">عناوين IP المتصلة المباشرة:</span>
            </div>
            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 font-mono font-black shadow-xs">
              <span className="text-emerald-400 text-xs">{onlineCount}</span>
              <span className="text-[10px] text-emerald-400/80 font-normal">IP متصل</span>
            </span>
          </div>

          <div className="flex items-center gap-3 text-slate-500 font-sans font-medium text-[11px]">
            <span className="inline-flex items-center gap-1 text-slate-400 font-mono">
              <Wifi className="w-3 h-3 text-emerald-400" />
              <span>بث مباشر 24/7</span>
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-amber-400 font-bold font-mono">
              SULION CUP LIVE
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-slate-400 font-mono">2026</span>
          </div>
        </footer>

        {/* Embedded Radio Modal */}
        <DefjayRadio
          isOpen={isRadioOpen}
          onClose={() => setIsRadioOpen(false)}
          soundEnabled={soundEnabled}
          onToggleSound={() => setSoundEnabled(!soundEnabled)}
        />
      </div>
    </div>
  );
};

export default SulionCupModal;
