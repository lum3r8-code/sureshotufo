import { useState } from 'react';
import { BookOpen, Copy, Check, Code, FileCode2 } from 'lucide-react';

export default function DocsPanel() {
  const [activeTab, setActiveTab] = useState<'curl' | 'python' | 'node'>('curl');
  const [copied, setCopied] = useState(false);

  // Snippets
  const curlCode = `curl -X GET "https://api.superbot.io/api/v1/arbitrage/opportunities" \\
  -H "Accept: application/json" \\
  -H "x-api-key: SAAS-KEY-XXXXXX"`;

  const pythonCode = `import requests

url = "https://api.superbot.io/api/v1/arbitrage/opportunities"
headers = {
    "Accept": "application/json",
    "x-api-key": "SAAS-KEY-XXXXXX"
}

try:
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        data = response.json()
        print(f"تم العثور على {data['opportunities_found']} فرصة تحكيم نشطة.")
        for opp in data['data']:
            print(f"[{opp['asset']}] ربح متوقع: \${opp['estimatedProfitUsd']} - عتبة: {opp['spreadPercent']:.2f}%")
    else:
        print(f"خطأ في الاتصال: {response.status_code}")
except Exception as e:
    print(f"فشل الطلب: {e}")`;

  const nodeCode = `const apiKey = 'SAAS-KEY-XXXXXX';
const url = 'https://api.superbot.io/api/v1/arbitrage/opportunities';

async function fetchArbitrage() {
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'x-api-key': apiKey
      }
    });
    
    if (!response.ok) {
      throw new Error(\`HTTP error! status: \${response.status}\`);
    }
    
    const result = await response.json();
    console.log('فرص التحكيم الحالية:', result.data);
  } catch (error) {
    console.error('خطأ أثناء جلب الصفقات:', error);
  }
}

fetchArbitrage();`;

  const currentCode = activeTab === 'curl' ? curlCode : activeTab === 'python' ? pythonCode : nodeCode;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(currentCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      // Fallback
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-emerald-400" />
          <h2 className="font-extrabold text-white text-base">دليل المطورين والربط الخارجي (SaaS API Docs)</h2>
        </div>
        <span className="text-[10px] bg-slate-800 text-slate-400 border border-slate-700 px-2 py-0.5 rounded">
          REST API v1.0
        </span>
      </div>

      <p className="text-xs text-slate-400 mb-4 leading-relaxed">
        يمكن للمطورين والعملاء ربط روبوتاتهم الخارجية (Trading Bots) وبرمجياتهم الكمية مباشرة بخدمة التحكيم الفوري لدينا عن طريق تمرير المفتاح الخاص في ترويسة الطلب باسم <code className="text-emerald-400 font-mono font-bold bg-slate-950 px-1 py-0.5 rounded">x-api-key</code>:
      </p>

      {/* Tabs list */}
      <div className="flex items-center justify-between bg-slate-950 p-1.5 rounded-lg border border-slate-850 mb-3">
        <div className="flex items-center gap-1">
          {/* cURL tab */}
          <button
            onClick={() => setActiveTab('curl')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold rounded-md transition duration-150 ${
              activeTab === 'curl'
                ? 'bg-emerald-600/10 text-emerald-400 border border-emerald-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>cURL Command</span>
          </button>

          {/* Python tab */}
          <button
            onClick={() => setActiveTab('python')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold rounded-md transition duration-150 ${
              activeTab === 'python'
                ? 'bg-emerald-600/10 text-emerald-400 border border-emerald-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileCode2 className="w-3.5 h-3.5" />
            <span>Python Script</span>
          </button>

          {/* Node.js tab */}
          <button
            onClick={() => setActiveTab('node')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold rounded-md transition duration-150 ${
              activeTab === 'node'
                ? 'bg-emerald-600/10 text-emerald-400 border border-emerald-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>Node.js Fetch</span>
          </button>
        </div>

        {/* Copy button */}
        <button
          onClick={handleCopy}
          className="flex items-center gap-1 px-2.5 py-1 text-[10px] rounded hover:bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition duration-150 focus:outline-none"
        >
          {copied ? (
            <>
              <Check className="w-3 h-3 text-emerald-400" />
              <span className="text-emerald-400">تم النسخ!</span>
            </>
          ) : (
            <>
              <Copy className="w-3 h-3" />
              <span>نسخ الكود</span>
            </>
          )}
        </button>
      </div>

      {/* Code viewport */}
      <div className="bg-black/95 border border-slate-900 rounded-lg p-3 font-mono text-[10.5px] leading-relaxed overflow-x-auto text-left text-slate-300">
        <pre>{currentCode}</pre>
      </div>

      {/* Info warning */}
      <div className="mt-4 flex items-start gap-2 bg-amber-500/5 border border-amber-500/10 p-3 rounded-lg">
        <span className="text-amber-500 text-xs font-bold mt-0.5">⚠️ تنويه:</span>
        <p className="text-[10px] text-amber-500/90 leading-relaxed">
          حافظ على سرية مفاتيح واجهة برمجة التطبيقات الخاصة بك. لا تقم أبداً بمشاركة المفتاح <code className="bg-black px-1 py-0.5 rounded text-[9px]">SAAS-KEY-XXXXXX</code> في الشيفرات البرمجية العميلة للواجهة الأمامية (Front-end)، بل يجب استخدامها دائماً من خوادمك الخلفية الآمنة لدرء مخاطر السرقة أو إساءة الاستخدام.
        </p>
      </div>
    </div>
  );
}
