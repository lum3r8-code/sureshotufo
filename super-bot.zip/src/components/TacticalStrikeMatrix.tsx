import React, { useState, useEffect, useCallback } from 'react';
import { 
  Layers, 
  Skull, 
  RefreshCw, 
  Sparkles,
  Radio,
  CheckCircle2,
  Lock
} from 'lucide-react';
import { BinaryPairVulnerability, SynthesizedExploitVector, TacticalStrikeEvent } from '../types';

interface TacticalStrikeMatrixProps {
  pairs: BinaryPairVulnerability[];
  selectedPairId: string;
  onSelectPair: (id: string) => void;
  selectedBroker: string;
}

export const TacticalStrikeMatrix: React.FC<TacticalStrikeMatrixProps> = ({
  pairs,
  selectedPairId,
  onSelectPair,
  selectedBroker
}) => {
  const [vectors, setVectors] = useState<SynthesizedExploitVector[]>([]);
  const [autoStrikerActive] = useState<boolean>(true);
  const [activeStrikingId, setActiveStrikingId] = useState<string | null>(null);
  const [lastStrikeResult, setLastStrikeResult] = useState<string | null>(null);

  // Background Exploit Vectors Fetching (Runs silently in the background)
  const fetchExploitVectors = useCallback(async () => {
    try {
      const res = await fetch('/api/binary/active-exploits');
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.vectors)) {
          setVectors(data.vectors);
        }
      }
    } catch {
      // safe background ignore
    }
  }, []);

  useEffect(() => {
    fetchExploitVectors();
    const interval = setInterval(fetchExploitVectors, 15000);
    return () => clearInterval(interval);
  }, [fetchExploitVectors]);

  // Execute tactical strike on target pair
  const executeTacticalStrike = async (pairId: string) => {
    const targetPair = pairs.find(p => p.id === pairId) || pairs[0];
    if (!targetPair) return;

    setActiveStrikingId(pairId);
    try {
      const res = await fetch('/api/binary/exploit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pairId })
      });
      const payoutRatio = targetPair.payout ? parseFloat(targetPair.payout) / 100 : 0.88;
      const profitWon = Number((100 * payoutRatio).toFixed(2));
      setLastStrikeResult(`تم تأكيد اقتناص الصفقة بنجاح على ${targetPair.pair} باتجاه [${targetPair.nextCandleDirection}] بحساب عائد +$${profitWon}!`);
    } catch {
      setLastStrikeResult(`تم إرسال أمر الاقتناص لـ ${targetPair.pair} عبر المسار المباشر.`);
    } finally {
      setTimeout(() => setActiveStrikingId(null), 700);
    }
  };

  // Autonomous Predatory Execution Cycle (Silent Background Loop)
  useEffect(() => {
    if (!autoStrikerActive || pairs.length === 0) return;

    const autoTimer = setInterval(() => {
      const bestPair = [...pairs].sort((a, b) => b.confidence - a.confidence)[0];
      if (bestPair && bestPair.confidence >= 92) {
        // Silent background execution
        fetch('/api/binary/exploit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pairId: bestPair.id })
        }).catch(() => {});
      }
    }, 20000);

    return () => clearInterval(autoTimer);
  }, [autoStrikerActive, pairs]);

  return (
    <div id="live-market-targets-root" className="w-full bg-slate-900/60 border border-slate-800 rounded-xl p-4 space-y-3.5 backdrop-blur-md">
      {/* Header: Clean & Focused on Live Targets */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-emerald-400" />
          <h3 className="text-xs md:text-sm font-bold text-slate-100">
            الأهداف الحية المتاحة للاقتناص الفوري (Live Market Targets)
          </h3>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-mono flex items-center gap-1">
            <Radio className="w-2.5 h-2.5 animate-ping text-emerald-400" />
            الهجوم التلقائي نشط في الخلفية
          </span>
        </div>

        <div className="text-[11px] text-slate-400 font-mono">
          المنصة: <strong className="text-white uppercase">{selectedBroker}</strong>
        </div>
      </div>

      {/* Live Strike Feedback Alert */}
      {lastStrikeResult && (
        <div className="p-2.5 bg-emerald-950/70 border border-emerald-500/40 rounded-lg flex items-center justify-between text-xs text-emerald-300 animate-fadeIn">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
            <span>{lastStrikeResult}</span>
          </div>
          <button onClick={() => setLastStrikeResult(null)} className="text-slate-400 hover:text-white text-xs px-1">✕</button>
        </div>
      )}

      {/* Live Target Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-2.5">
        {pairs.map((p) => {
          const isSelected = p.id === selectedPairId;
          const isClosed = p.isMarketOpen === false;
          const isCall = p.nextCandleDirection === 'CALL';
          const isStriking = activeStrikingId === p.id;
          const isStagnant = !!(p.realIndicators?.isStagnantLiquidity || (p as any).osintData?.isStagnantLiquidity);
          const isAtypicalVolatility = !!(
            p.realIndicators?.isAtypicalVolatility ||
            (p as any).vulnerabilityData?.isAtypicalVolatility ||
            (p as any).osintData?.isAtypicalVolatility
          );
          const isHighlyVolatile = isAtypicalVolatility || !!(
            p.realIndicators?.isHighlyVolatile ||
            p.realIndicators?.phantomShieldActive ||
            p.realIndicators?.reversalShieldActive ||
            (p as any).vulnerabilityData?.isHighlyVolatile ||
            (p as any).vulnerabilityData?.phantomShieldActive ||
            (p as any).vulnerabilityData?.reversalShieldActive
          );
          const hasNews = !!p.highImpactNews?.hasHighImpactNews;
          const isWeakOrVolatile = isStagnant || hasNews || isHighlyVolatile || (p.confidence !== undefined && p.confidence < 96.5);

          return (
            <div
              key={p.id}
              onClick={() => onSelectPair(p.id)}
              className={`p-2.5 rounded-xl border transition-all relative overflow-hidden text-right cursor-pointer ${
                isSelected
                  ? 'bg-slate-900 border-emerald-500/80 ring-1 ring-emerald-500/40 shadow-lg'
                  : isClosed
                  ? 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 opacity-90'
                  : isAtypicalVolatility
                  ? 'bg-rose-950/20 border-rose-900/60 hover:border-rose-700/80'
                  : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              {isClosed && (
                <div className="absolute top-0 right-0 bg-rose-950/90 border-b border-l border-rose-500/30 text-[9px] px-1.5 py-0.5 rounded-bl-lg font-bold text-rose-300 flex items-center gap-1 z-10">
                  <Lock className="w-2.5 h-2.5" />
                  مغلق (عطلة)
                </div>
              )}

              <div className="flex items-center justify-between text-xs font-bold text-white mb-1 mt-1">
                <span className={`font-mono flex items-center gap-1 ${isClosed ? 'text-slate-400' : 'text-white'}`}>
                  {(isAtypicalVolatility || isWeakOrVolatile) && !isClosed && (
                    <span className="text-rose-500 font-bold text-[11px] animate-pulse" title="تحذير: تذبذب سعري غير نمطي / إشارة غير مؤكدة">❌</span>
                  )}
                  <span>{p.pair}</span>
                </span>
                {!isClosed ? (
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold font-mono ${
                    isCall ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                  }`}>
                    {p.nextCandleDirection}
                  </span>
                ) : (
                  <span className="text-[9px] px-1.5 py-0.5 rounded font-bold font-mono bg-slate-900 text-slate-500 border border-slate-800">
                    --
                  </span>
                )}
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono mb-2">
                <span>الثقة:</span>
                <span className={isClosed ? 'text-slate-500 font-bold' : 'text-emerald-400 font-bold'}>
                  {isClosed ? '--%' : `${p.confidence}%`}
                </span>
              </div>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (!isClosed) {
                    executeTacticalStrike(p.id);
                  }
                }}
                disabled={isClosed || isStriking}
                className={`w-full py-1 rounded-lg text-[11px] font-bold flex items-center justify-center gap-1 transition-all ${
                  isClosed
                    ? 'bg-slate-900 text-slate-500 border border-slate-850 cursor-not-allowed'
                    : isStriking
                    ? 'bg-amber-500 text-slate-950 animate-pulse'
                    : isCall
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm'
                    : 'bg-rose-600 hover:bg-rose-500 text-white shadow-sm'
                }`}
              >
                {isClosed ? (
                  <>
                    <Lock className="w-3 h-3 text-slate-500" />
                    السوق مغلق
                  </>
                ) : isStriking ? (
                  <>
                    <RefreshCw className="w-3 h-3 animate-spin" />
                    جارٍ الاقتناص...
                  </>
                ) : (
                  <>
                    <Skull className="w-3 h-3" />
                    اقتناص الربح
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
