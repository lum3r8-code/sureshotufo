import { Cpu, RefreshCw, ExternalLink, ShieldCheck, Lock, CreditCard, Trophy } from 'lucide-react';

interface HeaderProps {
  isGovernorActive: boolean;
  onSync: () => void;
  isSyncing: boolean;
  onLogout?: () => void;
  onOpenBilling: () => void;
  onOpenSulionCup?: () => void;
}

export default function Header({ isGovernorActive, onSync, isSyncing, onLogout, onOpenBilling, onOpenSulionCup }: HeaderProps) {
  return (
    <header className="border-b border-slate-800 bg-slate-900/60 backdrop-blur-md sticky top-0 z-50 px-6 py-4">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Logo and App Title */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <Cpu className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-extrabold tracking-tight text-white bg-gradient-to-r from-emerald-400 to-amber-400 bg-clip-text text-transparent">
                Super bot
              </h1>
              <span className="text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                إصدار الحوكمة v2.4
              </span>
              <span className="text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full shadow-sm flex items-center gap-1">
                <span>🌟</span>
                <span>نحو الأفضل والأضمن بكل إنضباط</span>
              </span>
            </div>
            <p className="text-xs text-slate-400">
              بوابة سحابية لتوزيع واجهات برمجة التطبيقات (APIs) لأسعار العملات وحركات الحيتان — نموذج أعمال بدون رأس مال
            </p>
          </div>
        </div>

        {/* Connectivity Telemetry & Action Buttons */}
        <div className="flex flex-wrap items-center gap-3 md:gap-4">
          {/* Status Badge 1: Server Status */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-800/80 border border-slate-700 text-xs text-slate-300">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span>الخادم النشط: </span>
            <span className="font-semibold text-emerald-400">متصل (Port 3000)</span>
          </div>

          {/* Status Badge 2: Governor Status */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-800/80 border border-slate-700 text-xs text-slate-300">
            <ShieldCheck className={`w-3.5 h-3.5 ${isGovernorActive ? 'text-amber-400' : 'text-slate-500'}`} />
            <span>الحوكمة الذكية:</span>
            <span className={`font-semibold ${isGovernorActive ? 'text-amber-400' : 'text-slate-500'}`}>
              {isGovernorActive ? 'مفعّلة ونشطة' : 'متوقفة مؤقتاً'}
            </span>
          </div>

          {/* SULion Cup Popup Trigger Button */}
          {onOpenSulionCup && (
            <button
              onClick={onOpenSulionCup}
              className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white border border-rose-500/40 hover:border-rose-400 shadow-[0_0_10px_rgba(244,63,94,0.25)] transition duration-150 focus:outline-none cursor-pointer group"
              title="بطولة كأس سو لايون العالمية للتداول (SULION CUP)"
            >
              <Trophy className="w-3.5 h-3.5 text-rose-400 group-hover:scale-110 transition-transform" />
              <span>SULION CUP 🏆</span>
            </button>
          )}

          {/* Billing/Payment Button */}
          <button
            onClick={onOpenBilling}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold rounded-lg bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 shadow-md shadow-amber-950/20 transition-all focus:outline-none cursor-pointer"
          >
            <CreditCard className="w-3.5 h-3.5 text-slate-950" />
            <span>تفعيل الدفع (Visa / USDT)</span>
          </button>

          {/* Sync Button */}
          <button
            onClick={onSync}
            disabled={isSyncing}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 transition duration-150 focus:outline-none"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-emerald-400' : ''}`} />
            <span>تحديث فوري</span>
          </button>

          {/* Lock / Logout Button */}
          {onLogout && (
            <button
              onClick={onLogout}
              className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-rose-950/40 hover:bg-rose-900/40 text-rose-400 border border-rose-500/30 hover:border-rose-500/50 transition duration-150 focus:outline-none cursor-pointer"
              title="قفل لوحة التحكم فوراً من المتطفلين"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>قفل النظام</span>
            </button>
          )}

          {/* RapidAPI Link */}
          <a
            href="https://rapidapi.com"
            target="_blank"
            referrerPolicy="no-referrer"
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-500 hover:border-emerald-400 transition duration-150 shadow-md shadow-emerald-900/10"
          >
            <span>بوابة RapidAPI</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </header>
  );
}
