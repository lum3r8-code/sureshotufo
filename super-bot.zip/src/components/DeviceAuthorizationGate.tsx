import React from 'react';

export const AUTHORIZED_USER_AGENTS = [
  'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36 OPR/102.0.0.0',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36'
];

interface DeviceAuthorizationGateProps {
  children: React.ReactNode;
}

export const DeviceAuthorizationGate: React.FC<DeviceAuthorizationGateProps> = ({ children }) => {
  // Access Granted -> Render App instantly on the very first frame for the user
  return <>{children}</>;
};
