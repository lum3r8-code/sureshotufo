import React, { useState } from 'react';
import { 
  Key, 
  Copy, 
  Check, 
  Power, 
  Trash2, 
  Zap, 
  ShieldCheck, 
  Cpu, 
  Search, 
  CheckCircle2, 
  AlertCircle,
  ExternalLink,
  RefreshCw
} from 'lucide-react';
import { SaaSAPIKey, PlanType } from '../types';

interface KeyManagerProps {
  keys: SaaSAPIKey[];
  onCreateKey?: (label: string, plan: PlanType) => Promise<void>;
  onToggleKey: (id: string) => Promise<void>;
  onDeleteKey: (id: string) => Promise<void>;
}

export default function KeyManager({ keys, onToggleKey, onDeleteKey }: KeyManagerProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  
  // Manual TXID Verification Inspector State
  const [showInspector, setShowInspector] = useState(false);
  const [testTxHash, setTestTxHash] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifyResult, setVerifyResult] = useState<any>(null);
  const [verifyError, setVerifyError] = useState<string | null>(null);

  const officialWallet = 'THHqj5655PPJqVvAP8hpB5oH2oTdhtdN46';

  const handleCopy = async (keyString: string, id: string) => {
    try {
      await navigator.clipboard.writeText(keyString);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (err) {
      // Fallback
    }
  };

  const handleManualVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setVerifyResult(null);
    setVerifyError(null);
    setIsVerifying(true);

    try {
      if (!testTxHash.trim()) {
        throw new Error('يرجى إدخال رمز المعاملة (TXID) للفحص.');
      }

      const res = await fetch('/api/saas/billing/verify-tron', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ txHash: testTxHash.trim() }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'فشلت عملية التحقق على شبكة البلوكشين.');
      }

      setVerifyResult(data);
    } catch (err: any) {
      setVerifyError(err.message || 'خطأ أثناء فحص المعاملة.');
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="space-y-4 mb-6">
      {/* On-Chain Engine Status Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-white text-sm">محرك التحقق الآلي من معاملات البلوكشين (TRON Engine)</h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded border border-emerald-500/30">
                  متصل ومؤمن 24/7
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                محفظة الاستلام: <span className="font-mono text-slate-200 select-all">{officialWallet}</span> (USDT TRC-20)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => setShowInspector(!showInspector)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
            >
              <Search className="w-3.5 h-3.5 text-emerald-400" />
              <span>{showInspector ? 'إخفاء فاحص المعاملات' : 'فحص معاملة يدوياً'}</span>
            </button>
          </div>
        </div>

        {/* Manual TXID Inspector Sub-Panel */}
        {showInspector && (
          <div className="mt-4 pt-4 border-t border-slate-800 space-y-3">
            <form onSubmit={handleManualVerify} className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={testTxHash}
                onChange={(e) => setTestTxHash(e.target.value)}
                placeholder="أدخل رمز الـ TXID للتحقق منه وإصدار مفتاح فوري..."
                className="flex-1 bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-lg px-3.5 py-2 text-xs text-white placeholder-slate-600 focus:outline-none font-mono"
              />
              <button
                type="submit"
                disabled={isVerifying}
                className="px-4 py-2 bg-emerald-500 hover:bg-emerald-450 text-slate-950 font-bold text-xs rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer disabled:opacity-50"
              >
                {isVerifying ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>جاري الفحص...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>فحص وتفعيل فوري</span>
                  </>
                )}
              </button>
            </form>

            {verifyError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-lg text-rose-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{verifyError}</span>
              </div>
            )}

            {verifyResult && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-xs space-y-1.5">
                <div className="flex items-center gap-2 text-emerald-300 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{verifyResult.message}</span>
                </div>
                <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-300 font-mono">
                  <span>المفتاح: {verifyResult.key?.key}</span>
                  <span>المبلغ: ${verifyResult.transaction?.amountUsd} USDT</span>
                  <a 
                    href={verifyResult.transaction?.explorerUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-400 underline flex items-center gap-1"
                  >
                    <span>TronScan Explorer</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Main Keys List Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-2">
            <Key className="w-5 h-5 text-emerald-400" />
            <h2 className="font-extrabold text-white text-base">إدارة مفاتيح المشتركين والـ API</h2>
          </div>

          {/* Automated System Badge */}
          <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-lg text-xs font-semibold">
            <Zap className="w-3.5 h-3.5 text-emerald-400" />
            <span>توليد وتفعيل سحابي أوتوماتيكي (Auto-Provisioning 24/7)</span>
          </div>
        </div>

        {/* Info Notice Banner */}
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3 mb-5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-slate-300 text-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>يتم إنشاء وتجديد مفاتيح المشتركين فورياً بشكل آلي فور فحص الهاش على شبكة ترون وتأكيد الإيداع.</span>
          </div>
          <span className="text-[11px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800 shrink-0">
            إجمالي المفاتيح: {keys.length}
          </span>
        </div>

        {/* Keys List Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[10px] font-bold uppercase tracking-wider">
                <th className="py-3 px-4">اسم المفتاح / العميل</th>
                <th className="py-3 px-4">مفتاح الوصول (API Key)</th>
                <th className="py-3 px-4">خطة الاشتراك</th>
                <th className="py-3 px-4">معدل الاستهلاك / الكوتا</th>
                <th className="py-3 px-4 text-center">حالة المفتاح</th>
                <th className="py-3 px-4 text-left">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850 text-xs">
              {keys.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500 italic">
                    لا توجد أي مفاتيح نشطة حالياً في النظام.
                  </td>
                </tr>
              ) : (
                keys.map((k) => {
                  const isUnlimited = k.maxLimit === 'Unlimited';
                  const count = k.requestsCount;
                  const limit = typeof k.maxLimit === 'number' ? k.maxLimit : 1;
                  const usagePercent = isUnlimited ? 0 : Math.min(100, (count / limit) * 100);

                  let progressColor = 'bg-emerald-500';
                  if (usagePercent > 85) progressColor = 'bg-red-500';
                  else if (usagePercent > 60) progressColor = 'bg-amber-500';

                  let planBadgeStyle = 'bg-slate-800 text-slate-300 border-slate-700';
                  if (k.plan === 'Premium') planBadgeStyle = 'bg-blue-500/10 text-blue-400 border-blue-500/20';
                  else if (k.plan === 'Unlimited') planBadgeStyle = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';

                  return (
                    <tr key={k.id} className="hover:bg-slate-850/40 transition duration-100">
                      {/* Name/Label */}
                      <td className="py-3 px-4 font-semibold text-white max-w-[180px] truncate">
                        {k.label}
                      </td>

                      {/* API Key */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1 rounded font-mono text-[10px] w-fit border border-slate-800">
                          <span className="text-slate-400 select-all">{k.key}</span>
                          <button
                            onClick={() => handleCopy(k.key, k.id)}
                            className="text-slate-500 hover:text-white p-0.5 rounded focus:outline-none transition duration-100 cursor-pointer"
                            title="نسخ المفتاح"
                          >
                            {copiedId === k.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Plan Badge */}
                      <td className="py-3 px-4">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${planBadgeStyle}`}>
                          {k.plan === 'Basic' ? 'أساسي (Basic)' : k.plan === 'Premium' ? 'ممتاز (Premium)' : 'غير محدود (Unlimited)'}
                        </span>
                      </td>

                      {/* Quota Progress */}
                      <td className="py-3 px-4">
                        {isUnlimited ? (
                          <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                            <span>بلا حدود</span>
                            <span className="text-slate-500 font-normal">({count.toLocaleString()})</span>
                          </div>
                        ) : (
                          <div className="w-36 space-y-1">
                            <div className="flex items-center justify-between text-[10px] text-slate-400">
                              <span>{count.toLocaleString()}</span>
                              <span>/ {limit.toLocaleString()}</span>
                            </div>
                            <div className="w-full bg-slate-950 h-1 rounded-full overflow-hidden border border-slate-800">
                              <div 
                                className={`${progressColor} h-full transition-all duration-300`} 
                                style={{ width: `${usagePercent}%` }}
                              />
                            </div>
                          </div>
                        )}
                      </td>

                      {/* Status Toggle */}
                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => onToggleKey(k.id)}
                          className={`inline-flex items-center justify-center p-1.5 rounded-full border transition duration-150 cursor-pointer ${
                            k.status === 'Active'
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                              : 'bg-red-500/10 text-red-500 border-red-500/30 hover:bg-red-500/20'
                          }`}
                          title={k.status === 'Active' ? 'تعطيل المفتاح' : 'تفعيل المفتاح'}
                        >
                          <Power className="w-3.5 h-3.5" />
                          <span className="sr-only">{k.status}</span>
                        </button>
                      </td>

                      {/* Delete action */}
                      <td className="py-3 px-4 text-left">
                        <button
                          onClick={() => onDeleteKey(k.id)}
                          className="text-slate-500 hover:text-red-400 p-1.5 rounded-lg hover:bg-red-500/10 transition duration-150 focus:outline-none cursor-pointer"
                          title="حذف المفتاح نهائياً"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
