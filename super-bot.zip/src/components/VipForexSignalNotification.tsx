import React, { useEffect, useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bot, 
  TrendingUp, 
  TrendingDown, 
  CheckCircle2, 
  ExternalLink, 
  X, 
  Volume2, 
  VolumeX, 
  Zap, 
  ShieldCheck, 
  Sparkles,
  Radio
} from 'lucide-react';

export interface EaDispatchData {
  id: string;
  minute_id: number;
  symbol: string;
  action: 'BUY' | 'SELL';
  entry_price: number;
  entry_range: string;
  take_profit: number;
  take_profit_pips: number;
  stop_loss: number;
  stop_loss_pips: number;
  confidence: number;
  risk_reward: string;
  smc_analysis: string;
  timestamp: string;
  epoch: number;
  is_metatrader?: boolean;
}

interface VipForexSignalNotificationProps {
  onOpenSignalModal: () => void;
}

export const VipForexSignalNotification: React.FC<VipForexSignalNotificationProps> = ({
  onOpenSignalModal
}) => {
  const [activeDispatch, setActiveDispatch] = useState<EaDispatchData | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [totalDispatches, setTotalDispatches] = useState(0);
  const [lastDispatchedTime, setLastDispatchedTime] = useState<string>('');

  const lastNotifiedMinuteIdRef = useRef<number | null>(null);
  const isInitialLoadRef = useRef(true);
  const hideTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Discrete synthetic audio chime via Web Audio API (Zero external network dependency)
  const playChimeSound = useCallback(() => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      
      const now = ctx.currentTime;
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(587.33, now); // D5
      osc1.frequency.exponentialRampToValueAtTime(880, now + 0.12); // A5

      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(293.66, now); // D4
      osc2.frequency.exponentialRampToValueAtTime(440, now + 0.15); // A4

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.5);
      osc2.stop(now + 0.5);
    } catch {
      // Audio playback silently suppressed if user gesture not yet performed
    }
  }, [soundEnabled]);

  // Polling server for latest EA dispatches
  useEffect(() => {
    const checkEaDispatches = async () => {
      try {
        const res = await fetch('/api/forex/vip-signal/dispatches', {
          headers: { 'Accept': 'application/json' },
          cache: 'no-store'
        });

        if (!res.ok) return;
        const data = await res.json();
        
        if (data.success && data.latest_dispatch) {
          const dispatch = data.latest_dispatch as EaDispatchData;
          setTotalDispatches(data.total_ea_requests || 0);

          // On first run, record the initial minuteId without playing sound to prevent sudden alert on page open
          if (isInitialLoadRef.current) {
            isInitialLoadRef.current = false;
            lastNotifiedMinuteIdRef.current = dispatch.minute_id;
            setActiveDispatch(dispatch);
            // Formatted time with standard Western numerals
            setLastDispatchedTime(new Date(dispatch.epoch).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }));
            return;
          }

          // Trigger in-app notification when a new minute recommendation is dispatched
          if (lastNotifiedMinuteIdRef.current !== dispatch.minute_id) {
            lastNotifiedMinuteIdRef.current = dispatch.minute_id;
            setActiveDispatch(dispatch);
            setIsVisible(true);
            setLastDispatchedTime(new Date(dispatch.epoch).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }));
            playChimeSound();

            // Auto dismiss after 12 seconds
            if (hideTimeoutRef.current) clearTimeout(hideTimeoutRef.current);
            hideTimeoutRef.current = setTimeout(() => {
              setIsVisible(false);
            }, 12000);
          }
        }
      } catch {
        // Suppress network errors
      }
    };

    // Initial check and 3-second heartbeat
    checkEaDispatches();
    const interval = setInterval(checkEaDispatches, 3000);

    return () => {
      clearInterval(interval);
      if (hideTimeoutRef.current) clearTimeout(hideTimeoutRef.current);
    };
  }, [playChimeSound]);

  const handleDismiss = () => {
    setIsVisible(false);
    if (hideTimeoutRef.current) clearTimeout(hideTimeoutRef.current);
  };

  const handleOpenModal = () => {
    setIsVisible(false);
    onOpenSignalModal();
  };

  return (
    <>
      {/* Floating Real-Time EA Dispatch Toast */}
      <AnimatePresence>
        {isVisible && activeDispatch && (
          <motion.div
            initial={{ opacity: 0, y: -40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="fixed top-5 left-1/2 -translate-x-1/2 z-[9999] w-[95%] max-w-lg dir-rtl"
            role="alert"
            aria-live="assertive"
          >
            <div className="relative overflow-hidden bg-slate-950/95 border-2 border-amber-500/70 rounded-2xl shadow-[0_0_40px_rgba(245,158,11,0.35)] backdrop-blur-xl p-4 text-white">
              
              {/* Animated Glowing Accent Bar */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-emerald-400 to-indigo-500 animate-pulse" />

              {/* Header row */}
              <div className="flex items-center justify-between gap-3 mb-2.5">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 shadow-md">
                    <Bot className="w-5 h-5 animate-bounce" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-amber-400 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5" />
                        تم إرسال توصية جديدة لبوت خبير MT5!
                      </span>
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded-full font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        توصية 5M معتمدة (صفر انعكاس)
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      التوقيت: {lastDispatchedTime} • تم التسليم للبوت بنجاح
                    </p>
                  </div>
                </div>

                {/* Sound toggle & Close */}
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setSoundEnabled(!soundEnabled)}
                    className="p-1.5 rounded-lg bg-slate-900 text-slate-400 hover:text-white border border-slate-800 transition-colors"
                    title={soundEnabled ? 'كتم صوت الإشعارات' : 'تفعيل صوت الإشعارات'}
                  >
                    {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-amber-400" /> : <VolumeX className="w-3.5 h-3.5 text-slate-500" />}
                  </button>
                  <button
                    type="button"
                    onClick={handleDismiss}
                    className="p-1.5 rounded-lg bg-slate-900 text-slate-400 hover:text-white border border-slate-800 transition-colors"
                    title="إغلاق الإشعار"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Main Signal Card Details */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 mb-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-base font-black tracking-wider text-white bg-slate-800 px-2 py-0.5 rounded-lg border border-slate-700">
                      {activeDispatch.symbol}
                    </span>
                    <span className={`px-2 py-0.5 rounded-lg text-xs font-black flex items-center gap-1 shadow-sm ${
                      activeDispatch.action === 'BUY'
                        ? 'bg-emerald-500 text-slate-950 shadow-emerald-500/20'
                        : 'bg-rose-500 text-white shadow-rose-500/20'
                    }`}>
                      {activeDispatch.action === 'BUY' ? (
                        <>
                          <TrendingUp className="w-3.5 h-3.5" />
                          شراء (BUY)
                        </>
                      ) : (
                        <>
                          <TrendingDown className="w-3.5 h-3.5" />
                          بيع (SELL)
                        </>
                      )}
                    </span>
                  </div>

                  <div className="text-left dir-ltr">
                    <span className="text-xs text-slate-400">سعر الدخول: </span>
                    <span className="text-sm font-black text-amber-400 font-mono">
                      {activeDispatch.entry_price}
                    </span>
                  </div>
                </div>

                {/* TP & SL Stats */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-lg p-1.5 flex items-center justify-between">
                    <span className="text-emerald-300 font-bold flex items-center gap-1">
                      <Zap className="w-3 h-3 text-emerald-400" />
                      الهدف (TP):
                    </span>
                    <span className="font-black text-emerald-400 font-mono">
                      +{activeDispatch.take_profit_pips} نقطة ({activeDispatch.take_profit})
                    </span>
                  </div>

                  <div className="bg-rose-950/40 border border-rose-500/30 rounded-lg p-1.5 flex items-center justify-between">
                    <span className="text-rose-300 font-bold flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-rose-400" />
                      وقف الخسارة:
                    </span>
                    <span className="font-black text-rose-400 font-mono">
                      -{activeDispatch.stop_loss_pips} نقطة ({activeDispatch.stop_loss})
                    </span>
                  </div>
                </div>

                {/* SMC Analysis Reason */}
                <p className="mt-2 text-[11px] text-slate-300 bg-slate-950/60 p-1.5 rounded-lg border border-slate-800/80 leading-relaxed">
                  <span className="text-amber-400 font-bold">تحليل SMC المؤسسي: </span>
                  {activeDispatch.smc_analysis}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleOpenModal}
                  className="flex-1 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs py-2 px-3 rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>عرض تفاصيل التوصية وكود الخبير</span>
                </button>
                <button
                  type="button"
                  onClick={handleDismiss}
                  className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold transition-colors border border-slate-800 cursor-pointer"
                >
                  إخفاء
                </button>
              </div>

              {/* Auto-dismissing Progress Bar */}
              <div className="mt-2 h-1 bg-slate-800 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: '100%' }}
                  animate={{ width: '0%' }}
                  transition={{ duration: 12, ease: 'linear' }}
                  className="h-full bg-amber-500"
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Persistent Mini Status Badge in Bottom-Left corner */}
      {activeDispatch && !isVisible && (
        <div className="fixed bottom-4 left-4 z-40 dir-rtl">
          <button
            type="button"
            onClick={() => setIsVisible(true)}
            className="group flex items-center gap-2 bg-slate-950/90 hover:bg-slate-900 border border-amber-500/50 hover:border-amber-400 p-2 px-3 rounded-xl shadow-lg backdrop-blur-md transition-all cursor-pointer text-xs"
            title="انقر لعرض آخر إشعار أرسل لبوت MT5"
          >
            <div className="relative">
              <Bot className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-500 rounded-full" />
            </div>
            <div className="text-right">
              <div className="text-[10px] text-slate-400 flex items-center gap-1">
                <span>توصية بوت MT5 النشطة</span>
                <Radio className="w-2.5 h-2.5 text-emerald-400 animate-pulse" />
              </div>
              <div className="text-xs font-black text-white flex items-center gap-1">
                <span>{activeDispatch.symbol}</span>
                <span className={activeDispatch.action === 'BUY' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  [{activeDispatch.action}]
                </span>
                <span className="text-[10px] text-amber-300/80">+{activeDispatch.take_profit_pips}ن</span>
              </div>
            </div>
          </button>
        </div>
      )}
    </>
  );
};
