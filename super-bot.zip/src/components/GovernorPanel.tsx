import { useState } from 'react';
import { Cpu, Shield, HelpCircle, ToggleLeft, ToggleRight, Radio, RefreshCw, Zap } from 'lucide-react';
import { GovernorState, GovernorLog } from '../types';

interface GovernorPanelProps {
  state: GovernorState;
  logs: GovernorLog[];
  onToggleField: (field: keyof GovernorState, value: boolean) => void;
}

export default function GovernorPanel({ state, logs, onToggleField }: GovernorPanelProps) {
  const [filterType, setFilterType] = useState<string>('all');

  const filteredLogs = logs.filter(log => {
    if (filterType === 'all') return true;
    return log.type === filterType;
  });

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col h-full">
      {/* Panel Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
        <div className="flex items-center gap-2">
          <Cpu className="w-5 h-5 text-amber-500" />
          <h2 className="font-extrabold text-white text-base">محرك الحوكمة الذكي (AI Governor)</h2>
        </div>
        
        {/* Master Enabled Switch */}
        <button
          onClick={() => onToggleField('enabled', !state.enabled)}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition duration-150 ${
            state.enabled 
              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' 
              : 'bg-slate-800 text-slate-500 border border-slate-700'
          }`}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${state.enabled ? 'bg-amber-400' : 'bg-slate-600'}`} />
          <span>{state.enabled ? 'المحرك نشط' : 'المحرك معطل'}</span>
        </button>
      </div>

      {/* Telemetry Widgets Grid */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        {/* Metric A: Latency */}
        <div className="bg-slate-950/80 border border-slate-850 p-3 rounded-lg text-center">
          <p className="text-[10px] font-bold text-slate-400 mb-1">زمن الاستجابة</p>
          <p className="text-xl font-black text-emerald-400 tracking-tight">
            {state.latencyMs} <span className="text-[10px] font-normal text-slate-500">ms</span>
          </p>
          <div className="w-full bg-slate-800 h-1 rounded-full mt-2 overflow-hidden">
            <div 
              className="bg-emerald-400 h-full transition-all duration-500" 
              style={{ width: `${Math.min(100, (state.latencyMs / 60) * 100)}%` }}
            />
          </div>
        </div>

        {/* Metric B: Safety Score */}
        <div className="bg-slate-950/80 border border-slate-850 p-3 rounded-lg text-center">
          <p className="text-[10px] font-bold text-slate-400 mb-1">نقاط الحماية</p>
          <p className="text-xl font-black text-amber-400 tracking-tight">
            {state.safetyScore}%
          </p>
          <div className="w-full bg-slate-800 h-1 rounded-full mt-2 overflow-hidden">
            <div 
              className="bg-amber-400 h-full transition-all duration-500" 
              style={{ width: `${state.safetyScore}%` }}
            />
          </div>
        </div>

        {/* Metric C: CPU Load */}
        <div className="bg-slate-950/80 border border-slate-850 p-3 rounded-lg text-center">
          <p className="text-[10px] font-bold text-slate-400 mb-1">جهد المعالج</p>
          <p className="text-xl font-black text-sky-400 tracking-tight">
            {state.cpuLoad}%
          </p>
          <div className="w-full bg-slate-800 h-1 rounded-full mt-2 overflow-hidden">
            <div 
              className="bg-sky-400 h-full transition-all duration-500" 
              style={{ width: `${(state.cpuLoad / 30) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Subsystems Toggle Controls */}
      <div className="space-y-3 mb-5">
        <p className="text-xs font-bold text-slate-400">الأنظمة الفرعية المستقلة:</p>
        
        {/* Toggle 1: Auto Tuning */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/40 border border-slate-850 hover:border-slate-800 transition duration-150">
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-lg ${state.autoTuning ? 'bg-amber-500/10 text-amber-400' : 'bg-slate-800 text-slate-500'}`}>
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">الضبط التلقائي للعتبات</p>
              <p className="text-[10px] text-slate-400">تعديل حد الفروق ({state.arbitrageThreshold}%) تلقائياً</p>
            </div>
          </div>
          <button 
            disabled={!state.enabled}
            onClick={() => onToggleField('autoTuning', !state.autoTuning)}
            className={`transition duration-150 focus:outline-none ${!state.enabled ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer'}`}
          >
            {state.autoTuning ? (
              <ToggleRight className="w-10 h-10 text-emerald-500" />
            ) : (
              <ToggleLeft className="w-10 h-10 text-slate-600" />
            )}
          </button>
        </div>

        {/* Toggle 2: Security Guardian */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/40 border border-slate-850 hover:border-slate-800 transition duration-150">
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-lg ${state.securityGuardian ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">حارس الأمان النشط</p>
              <p className="text-[10px] text-slate-400">مراقبة التكرار وحماية المعاملات البرمجية</p>
            </div>
          </div>
          <button 
            disabled={!state.enabled}
            onClick={() => onToggleField('securityGuardian', !state.securityGuardian)}
            className={`transition duration-150 focus:outline-none ${!state.enabled ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer'}`}
          >
            {state.securityGuardian ? (
              <ToggleRight className="w-10 h-10 text-emerald-500" />
            ) : (
              <ToggleLeft className="w-10 h-10 text-slate-600" />
            )}
          </button>
        </div>

        {/* Toggle 3: Client Traffic Monitor */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/40 border border-slate-850 hover:border-slate-800 transition duration-150">
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-lg ${state.simulatedTraffic ? 'bg-sky-500/10 text-sky-400' : 'bg-slate-800 text-slate-500'}`}>
              <Radio className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">مراقب تدفق المعاملات الحية</p>
              <p className="text-[10px] text-slate-400">معالجة وتدقيق استعلامات الـ API الحقيقية للمتداولين والمستثمرين</p>
            </div>
          </div>
          <button 
            disabled={!state.enabled}
            onClick={() => onToggleField('simulatedTraffic', !state.simulatedTraffic)}
            className={`transition duration-150 focus:outline-none ${!state.enabled ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer'}`}
          >
            {state.simulatedTraffic ? (
              <ToggleRight className="w-10 h-10 text-emerald-500" />
            ) : (
              <ToggleLeft className="w-10 h-10 text-slate-600" />
            )}
          </button>
        </div>
      </div>

      {/* scrolling Terminal log */}
      <div className="flex-1 flex flex-col bg-black rounded-lg border border-slate-850 p-4 font-mono text-xs overflow-hidden">
        {/* Terminal Header */}
        <div className="flex items-center justify-between border-b border-slate-900 pb-2.5 mb-2.5">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
            <span className="w-2.5 h-2.5 rounded-full bg-green-500" />
            <span className="text-slate-400 text-[10px] mr-1">سجل نظام الحوكمة الآلي</span>
          </div>
          <div className="flex items-center gap-1">
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-slate-900 border border-slate-800 text-slate-400 text-[10px] px-2 py-0.5 rounded focus:outline-none focus:border-amber-500"
            >
              <option value="all">كل السجلات</option>
              <option value="tuning">الضبط والترقيات</option>
              <option value="security">الأمان والحماية</option>
              <option value="simulator">تدفق المعاملات</option>
              <option value="healing">التعافي والأداء</option>
            </select>
          </div>
        </div>

        {/* Terminal Body with scrolling list */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1.5 scrollbar-thin scrollbar-thumb-slate-800">
          {filteredLogs.length === 0 ? (
            <p className="text-slate-600 italic text-center py-4">لا توجد سجلات متاحة حالياً...</p>
          ) : (
            filteredLogs.map((log) => {
              let colorClass = 'text-slate-300';
              if (log.type === 'tuning') colorClass = 'text-amber-400';
              else if (log.type === 'security') colorClass = 'text-emerald-400';
              else if (log.type === 'simulator') colorClass = 'text-sky-400';
              else if (log.type === 'healing') colorClass = 'text-purple-400';

              return (
                <div key={log.id} className="border-b border-slate-950 pb-1.5 hover:bg-slate-950/50 p-1 rounded transition duration-100">
                  <span className="text-slate-500 text-[10px] ml-1.5 font-mono">
                    {new Date(log.timestamp).toLocaleTimeString('ar-EG-u-nu-latn', { numberingSystem: 'latn' }).replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))}
                  </span>
                  <span className={colorClass}>{log.message}</span>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
