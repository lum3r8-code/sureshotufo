import { DollarSign, Users, Activity, Percent } from 'lucide-react';

interface MetricsGridProps {
  mrr: number;
  activeSubscribers: number;
  totalQueries: number;
  uptime: string;
}

export default function MetricsGrid({ mrr, activeSubscribers, totalQueries, uptime }: MetricsGridProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {/* Metric 1: Monthly Recurring Revenue (MRR) */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl flex items-center justify-between">
        <div className="space-y-1.5">
          <p className="text-xs font-semibold text-slate-400">الإيرادات الشهرية المتكررة (MRR)</p>
          <p className="text-3xl font-black text-emerald-400 tracking-tight">
            ${mrr.toLocaleString()}
            <span className="text-xs font-normal text-slate-500 mr-1">/ شهرياً</span>
          </p>
          <div className="flex items-center gap-1 text-[10px] text-emerald-500/85">
            <span>مبني على المشتركين النشطين حالياً</span>
          </div>
        </div>
        <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
          <DollarSign className="w-6 h-6" />
        </div>
      </div>

      {/* Metric 2: Active Subscribers */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl flex items-center justify-between">
        <div className="space-y-1.5">
          <p className="text-xs font-semibold text-slate-400">المشتركون النشطون</p>
          <p className="text-3xl font-black text-white tracking-tight">
            {activeSubscribers}
            <span className="text-xs font-normal text-slate-500 mr-1">حسابات نشطة</span>
          </p>
          <div className="flex items-center gap-1 text-[10px] text-amber-500/85">
            <span>يتم مراقبتهم بواسطة نظام الحوكمة</span>
          </div>
        </div>
        <div className="p-3 bg-slate-800 text-slate-300 rounded-xl border border-slate-700">
          <Users className="w-6 h-6" />
        </div>
      </div>

      {/* Metric 3: Total API Queries */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl flex items-center justify-between">
        <div className="space-y-1.5">
          <p className="text-xs font-semibold text-slate-400">إجمالي الطلبات البرمجية (Queries)</p>
          <p className="text-3xl font-black text-white tracking-tight">
            {totalQueries.toLocaleString()}
            <span className="text-xs font-normal text-slate-500 mr-1">طلب</span>
          </p>
          <div className="flex items-center gap-1 text-[10px] text-emerald-500/85">
            <span>تحديث فوري لجميع المفاتيح</span>
          </div>
        </div>
        <div className="p-3 bg-slate-800 text-slate-300 rounded-xl border border-slate-700">
          <Activity className="w-6 h-6" />
        </div>
      </div>

      {/* Metric 4: Service Uptime */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl flex items-center justify-between">
        <div className="space-y-1.5">
          <p className="text-xs font-semibold text-slate-400">معدل جاهزية الخدمة (Uptime)</p>
          <p className="text-3xl font-black text-emerald-400 tracking-tight">
            {uptime}
          </p>
          <div className="flex items-center gap-1 text-[10px] text-emerald-500/85">
            <span>متوافق مع SLA للمؤسسات</span>
          </div>
        </div>
        <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
          <Percent className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
}
