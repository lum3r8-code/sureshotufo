import React from 'react';
import { ShieldAlert, TrendingDown, TrendingUp, Shuffle, Link2 } from 'lucide-react';
import { WhaleTransaction } from '../types';

interface WhaleTrackerPanelProps {
  transactions?: WhaleTransaction[];
}

export default function WhaleTrackerPanel({ transactions = [] }: WhaleTrackerPanelProps) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 mb-6" id="whale-tracker-panel">
      <div className="flex items-center gap-2.5 border-b border-slate-850 pb-4 mb-4">
        <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
          <ShieldAlert className="w-5 h-5" />
        </div>
        <div>
          <h2 className="font-extrabold text-white text-base">مرقب تحركات الحيتان الذكي (Whale Wallet Movements)</h2>
          <p className="text-[10px] text-slate-400 mt-0.5">رصد آلي لتحويلات المحافظ الكبرى ومستويات الدعم والمقاومة الناشئة لحظياً</p>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-right text-xs">
          <thead>
            <tr className="text-slate-500 border-b border-slate-850">
              <th className="pb-3 pt-1 pr-4">العملة والكمية</th>
              <th className="pb-3 pt-1">القيمة التقريبية ($)</th>
              <th className="pb-3 pt-1">نوع المعاملة</th>
              <th className="pb-3 pt-1">المصدر ⮕ الوجهة</th>
              <th className="pb-3 pt-1 pl-4 text-left">مستكشف البلوكشين</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850/60">
            {transactions.length === 0 ? (
              <tr>
                <td colSpan={5} className="text-center py-6 text-slate-500 text-[11px]">
                  في انتظار تدفق تحويلات البلوكشين النشطة...
                </td>
              </tr>
            ) : (
              transactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-slate-950/25 transition-colors">
                  <td className="py-3 pr-4 font-black text-white">
                    {tx.amount.toLocaleString()} {tx.asset}
                  </td>
                  <td className="py-3 font-semibold text-slate-300">
                    ${tx.valueUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </td>
                  <td className="py-3">
                    {tx.type === 'deposit' && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] bg-emerald-950/40 text-emerald-400 border border-emerald-900/40 font-bold">
                        <TrendingUp className="w-3 h-3" /> إيداع للمنصة ({tx.exchange})
                      </span>
                    )}
                    {tx.type === 'withdraw' && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] bg-rose-950/40 text-rose-400 border border-rose-900/40 font-bold">
                        <TrendingDown className="w-3 h-3" /> سحب خارجي ({tx.exchange})
                      </span>
                    )}
                    {tx.type === 'transfer' && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] bg-sky-950/40 text-sky-400 border border-sky-900/40 font-bold">
                        <Shuffle className="w-3 h-3" /> تحويل بين محافظ
                      </span>
                    )}
                  </td>
                  <td className="py-3 font-mono text-[10px] text-slate-400">
                    <span className="text-slate-300">{tx.fromAddress}</span>
                    <span className="mx-1.5 text-slate-500">⮕</span>
                    <span className="text-slate-300">{tx.toAddress}</span>
                  </td>
                  <td className="py-3 pl-4 text-left font-mono text-[10px] text-slate-500">
                    <a 
                      href={tx.txHash && tx.txHash.length >= 64 
                        ? `https://tronscan.org/#/transaction/${tx.txHash}`
                        : `https://www.binance.com/en/trade/${tx.asset}_USDT`} 
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-sky-400 hover:underline hover:text-sky-300 transition-colors"
                    >
                      <Link2 className="w-3 h-3" /> {tx.txHash}
                    </a>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
