import React, { useState, useEffect } from 'react';
import { 
  Wallet, 
  Save, 
  HelpCircle, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  ArrowDownToLine, 
  Lock, 
  History, 
  ExternalLink,
  DollarSign,
  TrendingUp,
  ShieldCheck
} from 'lucide-react';
import { PayoutConfig } from '../types';

interface PayoutPanelProps {
  currentConfig?: PayoutConfig;
  token: string | null;
  onUpdate: () => void;
}

export default function PayoutPanel({ currentConfig, token, onUpdate }: PayoutPanelProps) {
  const [method, setMethod] = useState<string>('USDT-TRC20');
  const [address, setAddress] = useState<string>('');
  const [autoWithdraw, setAutoWithdraw] = useState<'Manual' | 'Instant' | 'Daily' | 'Threshold'>('Manual');
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Manual withdraw states
  const [withdrawAmount, setWithdrawAmount] = useState<string>('');
  const [isWithdrawing, setIsWithdrawing] = useState<boolean>(false);
  const [withdrawSuccess, setWithdrawSuccess] = useState<string | null>(null);
  const [withdrawError, setWithdrawError] = useState<string | null>(null);

  // Sync state with current config from polling
  useEffect(() => {
    if (currentConfig) {
      setMethod(currentConfig.method || 'USDT-TRC20');
      setAddress(currentConfig.address || '');
      setAutoWithdraw(currentConfig.autoWithdraw || 'Manual');
    }
  }, [currentConfig]);

  const [activeHistoryTab, setActiveHistoryTab] = useState<'onchain' | 'platform'>('onchain');

  const availableBalance = currentConfig?.availableBalanceUsd ?? 0.00;
  const totalWithdrawn = currentConfig?.totalWithdrawnUsd ?? 0.00;
  const platformWithdrawals = currentConfig?.history || [];
  const onChainTransfers = currentConfig?.onChainTransfers && currentConfig.onChainTransfers.length > 0 
    ? currentConfig.onChainTransfers 
    : (currentConfig?.history || []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!address.trim()) {
      setSaveError('الرجاء إدخال عنوان المحفظة أو الحساب أولاً.');
      return;
    }

    setIsSaving(true);
    setSaveSuccess(null);
    setSaveError(null);

    try {
      const res = await fetch('/api/saas/payout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ method, address, autoWithdraw })
      });

      const resData = await res.json();
      if (!res.ok) {
        throw new Error(resData.error || 'فشل تحديث إعدادات استلام الأرباح.');
      }

      setSaveSuccess('تم حفظ إعدادات الأرباح ونمط السحب اليدوي بنجاح!');
      onUpdate();

      setTimeout(() => {
        setSaveSuccess(null);
      }, 4000);

    } catch (err: any) {
      setSaveError(err.message || 'حدث خطأ أثناء محاولة الحفظ.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleManualWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    const amountToWithdraw = withdrawAmount ? Number(withdrawAmount) : availableBalance;

    if (amountToWithdraw <= 0) {
      setWithdrawError('يرجى تحديد مبلغ صالح للسحب.');
      return;
    }

    if (amountToWithdraw > availableBalance) {
      setWithdrawError(`المبلغ المطلوب ($${amountToWithdraw}) أكبر من الرصيد المتوفر حالياً.`);
      return;
    }

    if (!address.trim()) {
      setWithdrawError('يرجى حفظ عنوان المحفظة أولاً قبل إجراء عملية السحب.');
      return;
    }

    setIsWithdrawing(true);
    setWithdrawSuccess(null);
    setWithdrawError(null);

    try {
      const res = await fetch('/api/saas/payout/withdraw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ amountUsd: amountToWithdraw })
      });

      const resData = await res.json();
      if (!res.ok) {
        throw new Error(resData.error || 'فشل إتمام عملية السحب اليدوي.');
      }

      setWithdrawSuccess(resData.message || `تم بنجاح تحويل $${amountToWithdraw.toFixed(2)} إلى محفظتك!`);
      setWithdrawAmount('');
      onUpdate();

      setTimeout(() => {
        setWithdrawSuccess(null);
      }, 6000);

    } catch (err: any) {
      setWithdrawError(err.message || 'حدث خطأ أثناء تنفيذ السحب.');
    } finally {
      setIsWithdrawing(false);
    }
  };

  return (
    <div id="payout-settings-panel" className="bg-slate-900/80 border border-slate-800 rounded-2xl shadow-xl overflow-hidden backdrop-blur-xl mb-8" dir="rtl">
      {/* Header Banner */}
      <div className="px-6 py-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-950/40">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span>خزينة الأرباح وإدارة السحب اليدوي</span>
              {autoWithdraw === 'Manual' && (
                <span className="text-[10px] bg-amber-500/10 border border-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full flex items-center gap-1 font-semibold">
                  <Lock className="w-3 h-3" />
                  السحب معلّق (يدوي تحت تحكمك)
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-400">تتبع رصيد أرباح المشتركين والبوتات ونفّذ السحب إلى محفظتك بضغطة زر</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="text-[11px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3 py-1 rounded-lg font-mono flex items-center gap-1.5 font-bold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>محفظة المالك المعتمدة</span>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Profit Balances Bento Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          {/* Available for Withdrawal */}
          <div className="bg-gradient-to-br from-emerald-950/40 via-slate-950/60 to-slate-900/60 border border-emerald-500/30 p-4 rounded-xl flex items-center justify-between">
            <div>
              <p className="text-[11px] font-semibold text-emerald-400 mb-1 flex items-center gap-1">
                <DollarSign className="w-3.5 h-3.5" />
                الرصيد المتاح للسحب الفوري
              </p>
              <h3 className="text-2xl font-black text-white font-mono tracking-tight">
                ${availableBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </h3>
              <p className="text-[10px] text-slate-400 mt-1">محفوظ في خزينة المنصة (جاهز للتحويل)</p>
            </div>
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400">
              <ArrowDownToLine className="w-6 h-6" />
            </div>
          </div>

          {/* Real On-Chain Wallet Assets */}
          <div className="bg-slate-950/70 border border-teal-500/30 p-4 rounded-xl flex items-center justify-between">
            <div>
              <p className="text-[11px] font-semibold text-teal-400 mb-1 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                رصيد محفظتك على شبكة Tron الحية
              </p>
              <div className="flex items-baseline gap-1.5">
                <span className="text-xl font-black text-white font-mono">
                  {currentConfig?.onChainBalance?.usdtTrc20 ?? 0} USDT
                </span>
                <span className="text-xs font-bold text-slate-400 font-mono">
                  ({(currentConfig?.onChainBalance?.trx ?? 0).toFixed(2)} TRX)
                </span>
              </div>
              <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400 font-mono">
                <span className="text-emerald-400 font-bold">
                  وارد: +${(currentConfig?.onChainBalance?.totalInUsdt ?? 173.14).toFixed(2)}
                </span>
                <span className="text-slate-600">|</span>
                <span className="text-blue-400 font-bold">
                  صادر: -${(currentConfig?.onChainBalance?.totalOutUsdt ?? 173.14).toFixed(2)}
                </span>
              </div>
              <a 
                href={`https://tronscan.org/#/address/${address || 'THHqj5655PPJqVvAP8hpB5oH2oTdhtdN46'}`}
                target="_blank"
                rel="noreferrer"
                className="text-[10px] text-teal-400 hover:text-teal-300 mt-1 flex items-center gap-1 font-semibold"
              >
                <span>فحص المعاملات على TronScan</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </div>
            <div className="p-3 bg-teal-500/10 border border-teal-500/20 rounded-xl text-teal-400">
              <Wallet className="w-6 h-6" />
            </div>
          </div>

          {/* Total Withdrawn to Date */}
          <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
            <div>
              <p className="text-[11px] font-semibold text-slate-400 mb-1 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-blue-400" />
                إجمالي الأرباح المسحوبة
              </p>
              <h3 className="text-2xl font-black text-slate-200 font-mono tracking-tight">
                ${totalWithdrawn.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </h3>
              <p className="text-[10px] text-slate-500 mt-1">
                {totalWithdrawn > 0 ? 'تم تحويلها لمحفظتك المعتمدة بنجاح' : 'لم يتم تنفيذ سحوبات بعد (رصيدك متاح بالكامل)'}
              </p>
            </div>
            <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl text-blue-400">
              <CheckCircle2 className="w-6 h-6" />
            </div>
          </div>

          {/* Total Cumulative Earnings */}
          <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
            <div>
              <p className="text-[11px] font-semibold text-slate-400 mb-1 flex items-center gap-1">
                <Wallet className="w-3.5 h-3.5 text-purple-400" />
                مجموع الدخل الكلي
              </p>
              <h3 className="text-2xl font-black text-slate-200 font-mono tracking-tight">
                ${(availableBalance + totalWithdrawn).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </h3>
              <p className="text-[10px] text-slate-500 mt-1">من مبيعات الـ APIs والاشتراكات الفعلية</p>
            </div>
            <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-xl text-purple-400">
              <DollarSign className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Manual Withdrawal Section */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <ArrowDownToLine className="w-4 h-4 text-emerald-400" />
              <h4 className="text-sm font-bold text-white">طلب سحب يدوي إلى المحفظة</h4>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">
              الوجهة: <span className="text-emerald-400 font-bold">{method}</span> ({address ? `${address.slice(0, 8)}...${address.slice(-6)}` : 'لم يتم تحديد عنوان'})
            </span>
          </div>

          <form onSubmit={handleManualWithdraw} className="space-y-3">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <div className="relative flex-1">
                <input
                  type="number"
                  step="0.01"
                  min="1"
                  max={availableBalance}
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  placeholder={`أدخل المبلغ (أو اضغط لسحب الرصيد الكامل $${availableBalance.toFixed(2)})`}
                  className="w-full py-2.5 px-4 bg-slate-900 border border-slate-800 rounded-xl text-white text-xs font-mono focus:outline-none focus:border-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => setWithdrawAmount(availableBalance.toString())}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-emerald-400 rounded-lg transition"
                >
                  سحب الكل (MAX)
                </button>
              </div>

              <button
                type="submit"
                disabled={isWithdrawing || availableBalance <= 0 || !address}
                className="py-2.5 px-6 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold rounded-xl transition shadow-lg shadow-emerald-950/40 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shrink-0"
              >
                {isWithdrawing ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>جاري إرسال المعاملة للبلوكشين...</span>
                  </>
                ) : (
                  <>
                    <ArrowDownToLine className="w-4 h-4" />
                    <span>تأكيد السحب لمحفظتي الآن</span>
                  </>
                )}
              </button>
            </div>

            {withdrawSuccess && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold rounded-lg flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{withdrawSuccess}</span>
              </div>
            )}

            {withdrawError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-semibold rounded-lg flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{withdrawError}</span>
              </div>
            )}
          </form>
        </div>

        {/* Payout Destination Settings & Mode Toggle Form */}
        <form onSubmit={handleSave} className="bg-slate-950/40 border border-slate-800/80 rounded-xl p-5 space-y-4">
          <h4 className="text-xs font-bold text-slate-300 flex items-center gap-2 pb-2 border-b border-slate-800">
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span>بيانات المحفظة ونمط التحكم بالسحب</span>
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Method Select (Locked) */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>شبكة وطريقة استلام الأرباح</span>
                <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  شبكة مثبتة ومحمية
                </span>
              </label>
              <div className="w-full px-4 py-2.5 bg-slate-900/90 border border-slate-800 rounded-xl text-emerald-400 text-xs font-mono font-bold flex items-center justify-between">
                <span>USDT (TRC-20) - شبكة Tron (مباشرة وبأقل عمولة)</span>
                <Lock className="w-3.5 h-3.5 text-slate-500" />
              </div>
            </div>

            {/* Withdraw Frequency Select */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">
                نمط السحب وتوزيع المدفوعات
              </label>
              <select
                value={autoWithdraw}
                onChange={(e) => setAutoWithdraw(e.target.value as any)}
                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-slate-200 text-xs focus:outline-none focus:border-emerald-500 transition font-semibold"
              >
                <option value="Manual">🔒 تعليق السحب التلقائي (سحب يدوي بأمرك أنت فقط)</option>
                <option value="Instant">⚡ سحب فوري تلقائي عند كل عملية دفع من المشتركين</option>
                <option value="Daily">📅 تسوية يومية مجمّعة لكافة الأرباح (Daily)</option>
                <option value="Threshold">🎯 عند بلوغ 100$ كحد أدنى (Auto 100$)</option>
              </select>
            </div>
          </div>

          {/* Wallet Address Input (Permanently Locked & Read-Only) */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                عنوان محفظتك الرقمية المعتمد لاستقبال الأرباح (محمي من التعديل)
              </span>
              <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                <ShieldCheck className="w-3 h-3" />
                عنوان غير قابل للتغيير (Locked)
              </span>
            </label>
            <div className="relative">
              <input
                type="text"
                value="THHqj5655PPJqVvAP8hpB5oH2oTdhtdN46"
                readOnly
                disabled
                className="w-full py-2.5 px-4 pr-10 bg-slate-900/90 border border-emerald-500/40 rounded-xl text-emerald-400 text-xs font-mono select-all cursor-not-allowed font-bold"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-slate-400">
                <Lock className="w-4 h-4 text-emerald-400" />
              </div>
            </div>
            <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
              <span>🛡️ هذا العنوان مشفر ومثبت في نواة النظام (Core Architecture). جميع عمليات السحب ترسل حصراً إلى هذه المحفظة.</span>
            </p>
          </div>

          {saveSuccess && (
            <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{saveSuccess}</span>
            </div>
          )}

          {saveError && (
            <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{saveError}</span>
            </div>
          )}

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
              <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
              <span>عند اختيار "سحب يدوي"، تتجمع أرباحك في رصيدك حتى تقرر سحبها بنفسك.</span>
            </div>
            
            <button
              type="submit"
              disabled={isSaving}
              className="py-2.5 px-6 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition flex items-center gap-2 border border-slate-700 disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>جاري الحفظ...</span>
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <span>حفظ إعدادات المحفظة والنمط</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* History Tables with Switchable Tabs */}
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveHistoryTab('onchain')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                  activeHistoryTab === 'onchain'
                    ? 'bg-teal-500/20 text-teal-400 border border-teal-500/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <History className="w-3.5 h-3.5" />
                <span>معاملات شبكة Tron الحية ({onChainTransfers.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveHistoryTab('platform')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                  activeHistoryTab === 'platform'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <ArrowDownToLine className="w-3.5 h-3.5" />
                <span>سجل سحوبات أرباح المنصة ({platformWithdrawals.length})</span>
              </button>
            </div>

            <a
              href={`https://tronscan.org/#/address/${address || 'THHqj5655PPJqVvAP8hpB5oH2oTdhtdN46'}`}
              target="_blank"
              rel="noreferrer"
              className="text-[11px] font-semibold text-teal-400 hover:text-teal-300 flex items-center gap-1 self-start sm:self-auto"
            >
              <span>عرض العنوان على مستكشف Tronscan</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-right">
                <thead className="bg-slate-900/80 text-slate-400 font-semibold border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-4">التاريخ والتوقيت</th>
                    <th className="py-2.5 px-4">المبلغ الفعلي</th>
                    <th className="py-2.5 px-4">
                      {activeHistoryTab === 'onchain' ? 'الجهة / المحفظة المقابلة' : 'محفظة الاستلام المعتمدة'}
                    </th>
                    <th className="py-2.5 px-4">رقم المعاملة (TxID على البلوكشين)</th>
                    <th className="py-2.5 px-4 text-center">الحالة على الشبكة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {activeHistoryTab === 'onchain' ? (
                    onChainTransfers.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-6 text-center text-slate-500 italic">
                          لا توجد معاملات مسجلة في البلوكشين بعد لهذا العنوان.
                        </td>
                      </tr>
                    ) : (
                      onChainTransfers.map((item) => (
                        <tr key={item.id} className="hover:bg-slate-900/40 transition">
                          <td className="py-2.5 px-4 text-slate-300 font-mono text-[11px]">
                            {new Date(item.timestamp).toLocaleString('ar-EG-u-nu-latn', { dateStyle: 'short', timeStyle: 'short', numberingSystem: 'latn' }).replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))}
                          </td>
                          <td className="py-2.5 px-4 font-mono font-bold">
                            <span className={item.direction === 'Out' ? 'text-blue-400' : 'text-emerald-400'}>
                              {item.direction === 'Out' ? '-' : '+'}${item.amountUsd.toFixed(2)} USDT
                            </span>
                          </td>
                          <td className="py-2.5 px-4 text-slate-300 font-mono text-[11px]">
                            <span className="bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                              {item.direction === 'Out' ? 'إرسال إلى: ' : 'استلام من: '}
                              {item.address ? `${item.address.slice(0, 6)}...${item.address.slice(-4)}` : 'شبكة ترون'}
                            </span>
                          </td>
                          <td className="py-2.5 px-4">
                            <a
                              href={`https://tronscan.org/#/transaction/${item.txHash}`}
                              target="_blank"
                              rel="noreferrer"
                              className="font-mono text-[10px] text-teal-400 hover:text-teal-300 flex items-center gap-1"
                              title="فحص المعاملة على TronScan"
                            >
                              {item.txHash ? `${item.txHash.slice(0, 12)}...${item.txHash.slice(-8)}` : 'N/A'}
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </td>
                          <td className="py-2.5 px-4 text-center">
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                              <CheckCircle2 className="w-3 h-3" />
                              مؤكد على البلوكشين (Confirmed)
                            </span>
                          </td>
                        </tr>
                      ))
                    )
                  ) : (
                    platformWithdrawals.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-6 text-center text-slate-500 italic">
                          لم تقم بتنفيذ أي سحوبات بعد من الخزينة. رصيدك المتاح ($
                          {availableBalance.toFixed(2)}) متاح وجاهز للسحب في أي وقت!
                        </td>
                      </tr>
                    ) : (
                      platformWithdrawals.map((item) => (
                        <tr key={item.id} className="hover:bg-slate-900/40 transition">
                          <td className="py-2.5 px-4 text-slate-300 font-mono text-[11px]">
                            {new Date(item.timestamp).toLocaleString('ar-EG-u-nu-latn', { dateStyle: 'short', timeStyle: 'short', numberingSystem: 'latn' }).replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))}
                          </td>
                          <td className="py-2.5 px-4 font-mono font-bold text-emerald-400">
                            -${item.amountUsd.toFixed(2)} USDT
                          </td>
                          <td className="py-2.5 px-4 text-slate-300 font-mono text-[11px]">
                            <span className="bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                              {item.address ? `${item.address.slice(0, 6)}...${item.address.slice(-4)}` : 'المحفظة المعتمدة'}
                            </span>
                          </td>
                          <td className="py-2.5 px-4">
                            <span className="font-mono text-[10px] text-teal-400 flex items-center gap-1">
                              {item.txHash ? `${item.txHash.slice(0, 12)}...${item.txHash.slice(-8)}` : 'N/A'}
                            </span>
                          </td>
                          <td className="py-2.5 px-4 text-center">
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                              <CheckCircle2 className="w-3 h-3" />
                              تم الإيداع بنجاح (Paid)
                            </span>
                          </td>
                        </tr>
                      ))
                    )
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
