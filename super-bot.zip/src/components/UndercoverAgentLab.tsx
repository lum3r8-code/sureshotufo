import React, { useState, useMemo, useEffect } from 'react';
import { 
  Trophy, 
  Send, 
  Clock, 
  ShieldAlert, 
  TrendingUp, 
  ChevronDown, 
  ChevronUp, 
  Search, 
  Sparkles, 
  Check, 
  BarChart3,
  Layers,
  Table,
  Globe,
  Activity,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import { 
  WORLD_TOURNAMENTS, 
  getUpcomingMatchesList, 
  formatTimeRemainingText as formatTimeRemaining,
  FootballMatchPrediction, 
  TournamentLeague 
} from '../services/sulionCupData';

export type { FootballMatchPrediction, TournamentLeague };
export { WORLD_TOURNAMENTS };

export interface UndercoverAgentLabProps {}

// ==========================================
// 2. Component Implementation
// ==========================================
export const UndercoverAgentLab: React.FC<UndercoverAgentLabProps> = () => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  // --- Real-time Clock State to filter out matches as soon as they start ---
  const [currentTime, setCurrentTime] = useState<number>(() => Date.now());

  useEffect(() => {
    // Tick every 10 seconds to strictly exclude any match that has started!
    const timer = setInterval(() => {
      setCurrentTime(Date.now());
    }, 10000);
    return () => clearInterval(timer);
  }, []);

  // --- States ---
  const [selectedLeagueId, setSelectedLeagueId] = useState<string>('ALL');
  const [footballFilter, setFootballFilter] = useState<'ALL' | 'DARK_ALERT' | 'HIGH_EV'>('ALL');
  const [footballViewMode, setFootballViewMode] = useState<'HEADLINES' | 'CARDS' | 'TABLE'>('HEADLINES');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedMatches, setExpandedMatches] = useState<Record<string, boolean>>({
    'ucl-rm-mci': true // Expand first match by default so user immediately sees SULION CUP explanation
  });
  const [sendingTelegramId, setSendingTelegramId] = useState<string | null>(null);
  const [sentTelegramMatchIds, setSentTelegramMatchIds] = useState<Record<string, boolean>>({});
  const [actionToast, setActionToast] = useState<string | null>(null);

  // --- Dynamic Matches Bank ---
  const [rawMatches] = useState<FootballMatchPrediction[]>(() => getUpcomingMatchesList());

  // --- CRITICAL FILTER: Show ONLY matches that have NOT started yet ---
  // Any match whose kickoffTimestamp <= currentTime is strictly eliminated!
  const strictlyUpcomingMatches = useMemo(() => {
    return rawMatches.filter(m => m.kickoffTimestamp > currentTime);
  }, [rawMatches, currentTime]);

  // Tournament count map
  const leagueMatchCounts = useMemo(() => {
    const counts: Record<string, number> = { ALL: strictlyUpcomingMatches.length };
    WORLD_TOURNAMENTS.forEach(t => {
      if (t.id !== 'ALL') {
        counts[t.id] = strictlyUpcomingMatches.filter(m => m.leagueId === t.id).length;
      }
    });
    return counts;
  }, [strictlyUpcomingMatches]);

  // --- Filtered Matches by League, Sub-filter, and Search ---
  const filteredMatches = useMemo(() => {
    return strictlyUpcomingMatches.filter(m => {
      // League Filter
      if (selectedLeagueId !== 'ALL' && m.leagueId !== selectedLeagueId) {
        return false;
      }
      // Sub Filters
      if (footballFilter === 'DARK_ALERT' && !m.darkVolumeAlert) return false;
      if (footballFilter === 'HIGH_EV' && (!m.valueEdgeEv || m.valueEdgeEv < 8)) return false;
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          m.homeTeamAr.toLowerCase().includes(q) ||
          m.awayTeamAr.toLowerCase().includes(q) ||
          m.leagueAr.toLowerCase().includes(q) ||
          m.homeTeamEn.toLowerCase().includes(q) ||
          m.awayTeamEn.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [strictlyUpcomingMatches, selectedLeagueId, footballFilter, searchQuery]);

  // --- Grouped by League for Headline View ---
  const groupedByLeague = useMemo<Record<string, FootballMatchPrediction[]>>(() => {
    const map: Record<string, FootballMatchPrediction[]> = {};
    filteredMatches.forEach(m => {
      const league = isAr ? m.leagueAr : m.leagueEn;
      if (!map[league]) map[league] = [];
      map[league].push(m);
    });
    return map;
  }, [filteredMatches, isAr]);

  // --- Handlers ---
  const toggleExpand = (id: string) => {
    setExpandedMatches(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleSendTelegram = async (match: FootballMatchPrediction) => {
    setSendingTelegramId(match.id);
    try {
      const res = await fetch('/api/send-telegram-match', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ match })
      });
      const data = await res.json();
      if (data.success) {
        setSentTelegramMatchIds(prev => ({ ...prev, [match.id]: true }));
        setActionToast(`✈️ تم إرسال نتيجة وتحليل (${match.homeTeamAr} ضد ${match.awayTeamAr}) إلى التلغرام بنجاح!`);
      } else {
        setActionToast('⚠️ تم تحضير الإشارة وحفظها بنجاح!');
      }
    } catch {
      setActionToast('⚠️ حدث خطأ أثناء الاتصال بالخادم.');
    } finally {
      setSendingTelegramId(null);
      setTimeout(() => setActionToast(null), 4000);
    }
  };

  const selectedTournamentObj = WORLD_TOURNAMENTS.find(t => t.id === selectedLeagueId);

  return (
    <div className="flex flex-col gap-5 w-full">
      {/* Toast Notification */}
      {actionToast && (
        <div className="fixed top-20 right-4 z-50 bg-emerald-600 text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-xl shadow-2xl border border-emerald-400 flex items-center gap-2 animate-bounce">
          <Check className="w-4 h-4" />
          <span>{actionToast}</span>
        </div>
      )}

      {/* =========================================================================
          SECTION 1: TOURNAMENT SELECTOR (اختيار البطولة العالمية الحالية)
         ========================================================================= */}
      <div className="bg-slate-900/95 border border-amber-500/30 rounded-2xl p-3.5 sm:p-4 shadow-xl flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400 animate-pulse" />
            <h2 className="text-sm sm:text-base font-black text-amber-300 tracking-wide">
              اختر البطولة العالمية الحالية
            </h2>
            <span className="text-[10px] sm:text-xs font-mono bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-md">
              {strictlyUpcomingMatches.length} مقابلات قادمة
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-[11px] text-amber-200/90 font-mono bg-slate-950/80 px-2.5 py-1 rounded-lg border border-amber-500/20">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>حصر المقابلات التي لم تبدأ بعد ⏳</span>
          </div>
        </div>

        {/* Tournaments Grid / Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-1.5 sm:gap-2">
          {WORLD_TOURNAMENTS.map((t) => {
            const isSelected = selectedLeagueId === t.id;
            const count = leagueMatchCounts[t.id] || 0;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setSelectedLeagueId(t.id)}
                className={`flex flex-col items-center justify-center p-2 rounded-xl border text-center transition-all cursor-pointer relative group ${
                  isSelected
                    ? 'bg-gradient-to-b from-amber-500/25 via-slate-800 to-slate-900 border-amber-400 text-amber-200 shadow-md shadow-amber-500/20 ring-1 ring-amber-400/50'
                    : 'bg-slate-950/80 hover:bg-slate-800/60 border-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                <span className="text-lg sm:text-xl group-hover:scale-110 transition-transform">{t.badge}</span>
                <span className="text-[11px] font-bold line-clamp-1 mt-1">{t.nameAr}</span>
                <span className={`text-[9px] font-mono mt-0.5 px-1.5 py-0.2 rounded-full ${
                  isSelected 
                    ? 'bg-amber-400 text-slate-950 font-black' 
                    : 'bg-slate-800 text-slate-400'
                }`}>
                  {count} قادمة
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* =========================================================================
          SECTION 2: CONTROL BAR (البحث، الفلاتر، وطرق العرض)
         ========================================================================= */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 p-3 rounded-2xl shadow-lg">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute right-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isAr ? "ابحث عن فريق، بطولة، أو مواجهة قادمة..." : "Search team, league..."}
            className="w-full pr-9 pl-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500/60"
          />
        </div>

        {/* View Mode Buttons */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 shrink-0">
          <button
            onClick={() => setFootballViewMode('HEADLINES')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              footballViewMode === 'HEADLINES' 
                ? 'bg-amber-500 text-slate-950 shadow-md' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>عناوين البطولات</span>
          </button>
          <button
            onClick={() => setFootballViewMode('CARDS')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              footballViewMode === 'CARDS' 
                ? 'bg-amber-500 text-slate-950 shadow-md' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>بطاقات تفصيلية</span>
          </button>
          <button
            onClick={() => setFootballViewMode('TABLE')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              footballViewMode === 'TABLE' 
                ? 'bg-amber-500 text-slate-950 shadow-md' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Table className="w-3.5 h-3.5" />
            <span>جدول الأودز</span>
          </button>
        </div>

        {/* Filters & App Link */}
        <div className="flex flex-wrap items-center gap-1.5 shrink-0">
          <button
            onClick={() => setFootballFilter('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
              footballFilter === 'ALL'
                ? 'bg-blue-600/30 border-blue-500 text-blue-300'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            الكل ({filteredMatches.length})
          </button>
          <button
            onClick={() => setFootballFilter('DARK_ALERT')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
              footballFilter === 'DARK_ALERT'
                ? 'bg-rose-600/30 border-rose-500 text-rose-300'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-rose-400'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
            <span>سيولة تدفق</span>
          </button>
          <button
            onClick={() => setFootballFilter('HIGH_EV')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
              footballFilter === 'HIGH_EV'
                ? 'bg-emerald-600/30 border-emerald-500 text-emerald-300'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-emerald-400'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>قيمة +EV</span>
          </button>

          {/* Our App Dedicated Button */}
          <a
            href={typeof window !== 'undefined' ? window.location.origin : '/'}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs shadow-md shadow-emerald-950/40 border border-emerald-400/50 transition-all cursor-pointer group shrink-0"
            title="الانتقال لتطبيقنا الأساسي (SURESHOT UFO VIP)"
          >
            <Globe className="w-3.5 h-3.5 group-hover:rotate-12 transition-transform" />
            <span>تطبيقنا الأساسي</span>
          </a>
        </div>
      </div>

      {/* Info Notice: Strictly Upcoming Matches */}
      <div className="px-4 py-2.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3 text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-400 animate-pulse shrink-0" />
          <span>
            البطولة الحالية: <strong className="text-amber-300">{selectedTournamentObj?.nameAr || 'الكل'}</strong> — يتم عرض المقابلات القادمة التي لم تبدأ بعد فقط لحضياً.
          </span>
        </div>
        <span className="text-[11px] font-mono text-slate-400 hidden sm:inline">
          نظام SULION CUP الذكي • تحديث فوري 24/7
        </span>
      </div>

      {/* =========================================================================
          VIEW 1: HEADLINES (عناوين حسب البطولة مع شرح سبب النتيجة بالتفصيل)
         ========================================================================= */}
      {footballViewMode === 'HEADLINES' && (
        <div className="flex flex-col gap-6">
          {Object.keys(groupedByLeague).length === 0 ? (
            <div className="p-12 text-center bg-slate-900/60 rounded-2xl border border-slate-800 text-slate-400 flex flex-col items-center gap-3">
              <AlertCircle className="w-8 h-8 text-amber-400/60" />
              <p className="text-sm font-bold text-slate-300">
                لا توجد مقابلات قادمة غير مبتدئة تطابق الفلتر أو البطولة المحددة حالياً.
              </p>
              <p className="text-xs text-slate-500 font-mono">
                يتم استبعاد أي مقابلة انطلقت أو انتهت تلقائياً من المنصة.
              </p>
            </div>
          ) : (
            (Object.entries(groupedByLeague) as [string, FootballMatchPrediction[]][]).map(([leagueName, leagueMatches]) => (
              <div key={leagueName} className="bg-slate-900/90 border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
                {/* League Header */}
                <div className="bg-gradient-to-r from-amber-500/20 via-slate-800 to-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <Trophy className="w-5 h-5 text-amber-400" />
                    <h2 className="text-sm sm:text-base font-black text-amber-300 tracking-wide">
                      بطولة {leagueName}
                    </h2>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-mono bg-slate-950/80 text-amber-400 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                      {leagueMatches.length} مقابلات لم تبدأ بعد
                    </span>
                  </div>
                </div>

                {/* Matches List */}
                <div className="divide-y divide-slate-800/60">
                  {leagueMatches.map((m, idx) => {
                    const isExp = !!expandedMatches[m.id];
                    const countdown = formatTimeRemaining(m.kickoffTimestamp, currentTime);
                    return (
                      <div key={m.id} className="transition-colors hover:bg-slate-800/30">
                        {/* Match Row */}
                        <div 
                          onClick={() => toggleExpand(m.id)}
                          className="px-4 py-3.5 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 cursor-pointer select-none"
                        >
                          <div className="flex items-center gap-3">
                            <span className="w-6 h-6 rounded-full bg-slate-950 border border-amber-500/40 text-amber-400 font-mono text-xs font-black flex items-center justify-center shrink-0">
                              {idx + 1}
                            </span>
                            <div className="flex items-center gap-2 text-xs sm:text-sm font-bold text-slate-100 flex-wrap">
                              <span className="text-base">{m.homeFlag}</span>
                              <span className="font-black text-slate-100">{m.homeTeamAr}</span>
                              <span className="text-amber-400 font-black px-1">ضد</span>
                              <span className="font-black text-slate-100">{m.awayTeamAr}</span>
                              <span className="text-base">{m.awayFlag}</span>
                            </div>
                          </div>

                          <div className="flex items-center justify-between md:justify-end gap-3 shrink-0">
                            {/* Timing & Countdown */}
                            <div className="flex items-center gap-2">
                              <div className="flex items-center gap-1 text-[11px] text-slate-300 font-mono bg-slate-950 px-2 py-1 rounded-md border border-slate-800">
                                <Calendar className="w-3 h-3 text-slate-400" />
                                <span>{m.matchDateStr}</span>
                              </div>
                              <div className="flex items-center gap-1 text-[11px] text-amber-300 font-mono bg-slate-950 px-2 py-1 rounded-md border border-amber-500/30">
                                <Clock className="w-3 h-3 text-amber-400" />
                                <span>{m.matchTime}</span>
                              </div>
                              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-950/80 border border-blue-500/40 text-blue-300 font-bold hidden sm:inline">
                                {countdown}
                              </span>
                            </div>

                            {/* Predicted Result Badge */}
                            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 font-mono font-black text-xs shadow-xs">
                              <span className="text-[10px] font-sans font-normal text-emerald-400/80">التوقع:</span>
                              <span>{m.homeTeamAr} ({m.expectedScoreHome}) - ({m.expectedScoreAway}) {m.awayTeamAr}</span>
                            </div>

                            {isExp ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                          </div>
                        </div>

                        {/* Expanded Explanation Details (SULION CUP Analysis Engine) */}
                        {isExp && (
                          <div className="px-5 py-4 bg-slate-950/85 border-t border-slate-800/80 flex flex-col gap-3.5 text-xs sm:text-sm">
                            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/60 pb-2.5">
                              <div className="flex items-center gap-2">
                                <Sparkles className="w-4 h-4 text-amber-400" />
                                <span className="font-bold text-amber-300">
                                  نظام تحليل SULION CUP وتوقع نتيجة المواجهة:
                                </span>
                                <span className="text-[10px] font-mono bg-amber-950/60 border border-amber-500/30 text-amber-300 px-2 py-0.5 rounded-md font-bold">
                                  نسبة الثقة {m.confidenceScore}%
                                </span>
                              </div>

                              <button
                                onClick={() => handleSendTelegram(m)}
                                disabled={sendingTelegramId === m.id}
                                className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-all cursor-pointer shadow-md disabled:opacity-50"
                              >
                                <Send className="w-3 h-3" />
                                <span>{sentTelegramMatchIds[m.id] ? 'تم الإرسال للتلغرام' : 'إرسال للتلغرام'}</span>
                              </button>
                            </div>

                            {/* Proprietary SULION CUP Analysis Explanation */}
                            <div className="p-3.5 bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/30 rounded-xl border border-amber-500/30 flex flex-col gap-2">
                              <div className="flex items-center gap-2 text-amber-300 font-bold">
                                <span>🔬 شرح سبب النتيجة المتوقعة عبر خوارزمية SULION CUP:</span>
                              </div>
                              <p className="text-slate-200 leading-relaxed text-xs sm:text-[13px]">
                                {m.sulionAnalysisReasonAr}
                              </p>
                            </div>

                            {/* Tactical Insight & Scenario */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                              <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800 flex flex-col gap-1.5 text-xs">
                                <span className="font-bold text-slate-200">⚔️ الرؤية التكتيكية للمواجهة:</span>
                                <p className="text-slate-400 leading-relaxed">
                                  {m.keyTacticalInsightAr}
                                </p>
                              </div>
                              <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800 flex flex-col gap-1.5 text-xs">
                                <span className="font-bold text-slate-200">📊 السيناريو المحسوب لمجريات المباراة:</span>
                                <p className="text-slate-400 leading-relaxed">
                                  {m.calculatedScenarioAr}
                                </p>
                              </div>
                            </div>

                            {/* Metrics & Probabilities & Odds */}
                            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-2 pt-1 font-mono text-center">
                              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                                <div className="text-[10px] text-slate-400">فوز المستضيف (1)</div>
                                <div className="text-xs sm:text-sm font-black text-emerald-400">{m.homeWinProb}%</div>
                                <div className="text-[9px] text-slate-500">أودز: {m.marketOddsHome}</div>
                              </div>
                              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                                <div className="text-[10px] text-slate-400">التعادل (X)</div>
                                <div className="text-xs sm:text-sm font-black text-amber-400">{m.drawProb}%</div>
                                <div className="text-[9px] text-slate-500">أودز: {m.marketOddsDraw}</div>
                              </div>
                              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                                <div className="text-[10px] text-slate-400">فوز الضيف (2)</div>
                                <div className="text-xs sm:text-sm font-black text-rose-400">{m.awayWinProb}%</div>
                                <div className="text-[9px] text-slate-500">أودز: {m.marketOddsAway}</div>
                              </div>
                              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                                <div className="text-[10px] text-slate-400">الأهداف المتوقعة xG</div>
                                <div className="text-xs sm:text-sm font-black text-cyan-400">{m.expectedXgHome} - {m.expectedXgAway}</div>
                                <div className="text-[9px] text-slate-500">+2.5 هدف: {m.marketOver25Odds}</div>
                              </div>
                              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 col-span-2 sm:col-span-1">
                                <div className="text-[10px] text-slate-400">القيمة الإيجابية (+EV)</div>
                                <div className="text-xs sm:text-sm font-black text-emerald-300">+{m.valueEdgeEv}%</div>
                                <div className="text-[9px] text-amber-300">كيلي: {m.kellyPercent}%</div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* =========================================================================
          VIEW 2: DETAILED CARDS (البطاقات الشاملة)
         ========================================================================= */}
      {footballViewMode === 'CARDS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredMatches.map((m) => (
            <div key={m.id} className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col justify-between gap-3.5">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <div className="flex items-center gap-1.5">
                  <span className="text-base">{m.leagueBadge}</span>
                  <span className="text-xs font-bold text-amber-400">{m.leagueAr}</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                  <span>{m.matchDateStr}</span>
                  <span>•</span>
                  <span className="text-amber-300">{m.matchTime}</span>
                </div>
              </div>

              {/* Match Teams Row */}
              <div className="flex items-center justify-between py-2">
                <div className="flex flex-col items-center gap-1 w-1/3 text-center">
                  <span className="text-2xl">{m.homeFlag}</span>
                  <span className="text-xs font-black text-slate-100">{m.homeTeamAr}</span>
                  <span className="text-[10px] font-mono text-emerald-400">{m.homeWinProb}%</span>
                  <span className="text-[9px] font-mono text-slate-400">أودز: {m.marketOddsHome}</span>
                </div>

                <div className="flex flex-col items-center justify-center">
                  <div className="text-xl font-black font-mono text-amber-400 bg-slate-950 px-3.5 py-1.5 rounded-xl border border-amber-500/30">
                    {m.expectedScoreHome} - {m.expectedScoreAway}
                  </div>
                  <span className="text-[10px] font-mono text-cyan-400 mt-1">xG: {m.expectedXgHome} - {m.expectedXgAway}</span>
                  <span className="text-[9px] font-mono text-slate-500 mt-0.5">ثقة: {m.confidenceScore}%</span>
                </div>

                <div className="flex flex-col items-center gap-1 w-1/3 text-center">
                  <span className="text-2xl">{m.awayFlag}</span>
                  <span className="text-xs font-black text-slate-100">{m.awayTeamAr}</span>
                  <span className="text-[10px] font-mono text-rose-400">{m.awayWinProb}%</span>
                  <span className="text-[9px] font-mono text-slate-400">أودز: {m.marketOddsAway}</span>
                </div>
              </div>

              {/* SULION CUP Explanation Box */}
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 text-xs text-slate-300 flex flex-col gap-1">
                <span className="text-amber-300 font-bold">🔬 سبب النتيجة بنظام SULION CUP:</span>
                <p className="leading-relaxed text-[11px] text-slate-300">
                  {m.sulionAnalysisReasonAr}
                </p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                <span className="text-xs font-mono text-amber-300 font-bold">{m.kellyRecommendationAr}</span>
                <button
                  onClick={() => handleSendTelegram(m)}
                  className="p-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white transition-all cursor-pointer shadow-sm"
                  title="إرسال للتلغرام"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* =========================================================================
          VIEW 3: TABLE VIEW (جدول الأودز والاحتمالات)
         ========================================================================= */}
      {footballViewMode === 'TABLE' && (
        <div className="overflow-x-auto bg-slate-900/90 border border-slate-800 rounded-2xl shadow-xl">
          <table className="w-full text-right text-xs font-sans">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-bold">
              <tr>
                <th className="p-3">المواجهة القادمة</th>
                <th className="p-3">البطولة</th>
                <th className="p-3">التوقيت (GMT)</th>
                <th className="p-3 text-center">النتيجة المتوقعة</th>
                <th className="p-3 text-center">أودز السوق (1 / X / 2)</th>
                <th className="p-3 text-center">القيمة EV</th>
                <th className="p-3 text-center">إجراء</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredMatches.map(m => (
                <tr key={m.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3 font-sans font-bold text-slate-100">
                    {m.homeFlag} {m.homeTeamAr} ضد {m.awayTeamAr} {m.awayFlag}
                  </td>
                  <td className="p-3 font-sans text-amber-400">{m.leagueAr}</td>
                  <td className="p-3 text-slate-300">
                    <div>{m.matchTime}</div>
                    <div className="text-[10px] text-slate-500">{m.matchDateStr}</div>
                  </td>
                  <td className="p-3 text-center font-bold text-emerald-400">
                    <span className="px-2 py-0.5 rounded-md bg-emerald-950/60 border border-emerald-500/40">
                      {m.expectedScoreHome} - {m.expectedScoreAway}
                    </span>
                  </td>
                  <td className="p-3 text-center text-blue-300 font-bold">
                    {m.marketOddsHome} | {m.marketOddsDraw} | {m.marketOddsAway}
                  </td>
                  <td className="p-3 text-center text-emerald-300 font-bold">
                    +{m.valueEdgeEv || 0}%
                  </td>
                  <td className="p-3 text-center">
                    <button
                      onClick={() => handleSendTelegram(m)}
                      className="p-1.5 rounded-lg bg-blue-600/30 text-blue-400 hover:bg-blue-600 hover:text-white transition-all cursor-pointer"
                      title="إرسال للتلغرام"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default UndercoverAgentLab;
