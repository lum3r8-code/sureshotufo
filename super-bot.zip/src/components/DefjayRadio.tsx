import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  X, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Radio, 
  Sparkles, 
  RotateCw,
  AlertCircle,
  Wifi,
  ExternalLink
} from 'lucide-react';
import { useLanguage } from '../LanguageContext';

export interface RadioStation {
  id: string;
  name: string;
  category: 'arabic' | 'silvacast' | 'focus';
  genreAr: string;
  genreEn: string;
  url: string;
  streamUrl: string; // added for metadata polling
  fallbackUrls?: string[];
  icon: string;
  accentColor: string;
  descAr: string;
  descEn: string;
}

export const RADIO_STATIONS: RadioStation[] = [
  {
    id: 'jil-fm',
    name: 'Jil FM (94.7 FM) - إذاعة جيل إف إم',
    category: 'arabic',
    genreAr: 'موسيقى شبابية، بوب وجزائري معاصر (Jil FM الجزائر)',
    genreEn: 'Algerian Youth Hit Radio, Pop & Hits (94.7 FM)',
    url: '/api/radio-stream?url=https%3A%2F%2Fradiojeunesse.ice.infomaniak.ch%2Fjeunesse.mp3',
    streamUrl: 'https://radiojeunesse.ice.infomaniak.ch/jeunesse.mp3',
    fallbackUrls: [
      'https://radiojeunesse.ice.infomaniak.ch/jeunesse.mp3',
      'http://radiojeunesse.ice.infomaniak.ch/jeunesse.mp3',
      'https://radiochaine3.ice.infomaniak.ch/chaine3.mp3',
      'https://radioelbahdja.ice.infomaniak.ch/elbahdja.mp3'
    ],
    icon: '⚡',
    accentColor: '#0ea5e9',
    descAr: 'الإذاعة الوطنية الشبابية الرسمية الأولى في الجزائر، أحدث الإصدارات الغنائية، الهيب هوب والموسيقى العصرية على مدار 24 ساعة',
    descEn: 'Official premier Algerian youth radio station live 24/7 with trending music, pop & beats'
  },
  {
    id: 'jow-fm',
    name: 'JOW FM / Radio - إذاعة جاو راديو الجزائر',
    category: 'arabic',
    genreAr: 'هيتس عصرية، إلكترونيك وراب شبابي (JOW Live)',
    genreEn: 'Modern Urban Hits, Rap & Algerian Vibes (JOW FM)',
    url: '/api/radio-stream?url=https%3A%2F%2Fazuracast.dataplayapps.com%2Flisten%2Flive%2Fradio.mp3',
    streamUrl: 'https://azuracast.dataplayapps.com/listen/live/radio.mp3',
    fallbackUrls: [
      'https://azuracast.dataplayapps.com/listen/live/radio.mp3',
      'https://azuracast.dataplayapps.com/listen/live1/radio.mp3',
      'https://azuracast.dataplayapps.com/listen/disco_maghreb/radio.mp3',
      'https://azuracast.dataplayapps.com/listen/rai/radio.mp3'
    ],
    icon: '🔥',
    accentColor: '#f97316',
    descAr: 'الإذاعة الإلكترونية الشبابية الأقوى في الجزائر، إيقاعات عصرية متواصلة وبث مباشر فائق النقاء',
    descEn: 'Top Algerian youth online radio live stream with high quality audio and trending tracks'
  },
  {
    id: 'dzair-rai',
    name: 'Radio Dzair Raï - راديو دزاير راي',
    category: 'arabic',
    genreAr: 'راي جزائري 100% (Dzair Raï)',
    genreEn: 'Algerian Raï Non-Stop (Dzair Raï)',
    url: '/api/radio-stream?url=http%3A%2F%2Furbanhitrai.ice.infomaniak.ch%2Furbanhitrai.mp3',
    streamUrl: 'http://urbanhitrai.ice.infomaniak.ch/urbanhitrai.mp3',
    fallbackUrls: [
      'http://urbanhitrai.ice.infomaniak.ch/urbanhitrai.mp3',
      'https://icecast.skyrock.net/s/alger_aac_64k',
      'https://radiozamen.ice.infomaniak.ch/zamen.mp3',
      'http://urbanhitus.ice.infomaniak.ch/urbanhitus-128.mp3'
    ],
    icon: '🇩🇿',
    accentColor: '#e11d48',
    descAr: 'الإذاعة الأولى لفن الراي الجزائري الأصيل والعصري (حسني، مامي، خالد، بلال، نصرو وغيرهم) بث حي 24/7',
    descEn: 'Authentic and modern Algerian Raï classics & hits live 24/7 (Cheb Hasni, Khaled, Mami, Bilal, Nasro)'
  },
  {
    id: 'dzair-orientale-mix',
    name: 'Radio Dzair Orientale / Raï Mix - دزاير أورينتال وراي ميكس',
    category: 'arabic',
    genreAr: 'راي ميكس وطرب شرقي ومغاربي (Raï & Orientale Mix)',
    genreEn: 'Raï Mix & Oriental Melodies',
    url: '/api/radio-stream?url=https%3A%2F%2Ficecast.skyrock.net%2Fs%2Falger_aac_64k',
    streamUrl: 'https://icecast.skyrock.net/s/alger_aac_64k',
    fallbackUrls: [
      'https://icecast.skyrock.net/s/alger_aac_64k',
      'https://radiozamen.ice.infomaniak.ch/zamen.mp3',
      'https://allzic33.ice.infomaniak.ch/allzic33.aac',
      'http://urbanhitrai.ice.infomaniak.ch/urbanhitrai.mp3'
    ],
    icon: '🪕',
    accentColor: '#06b6d4',
    descAr: 'توليفة ساحرة من ريمكسات الراي الجزائري والموسيقى الشرقية والمغاربية والطرب الأصيل على مدار الساعة',
    descEn: 'A rich blend of Algerian Raï remixes, North African grooves, and oriental classics 24/7'
  },
  {
    id: 'le-mouv',
    name: 'Mouv\' - Radio France',
    category: 'silvacast',
    genreAr: 'هيب هوب وأر أند بي (Le Mouv)',
    genreEn: 'Hip Hop & R&B (Le Mouv)',
    url: '/api/radio-stream?url=https%3A%2F%2Ficecast.radiofrance.fr%2Fmouv-midfi.mp3',
    streamUrl: 'https://icecast.radiofrance.fr/mouv-midfi.mp3',
    fallbackUrls: [
      'https://icecast.radiofrance.fr/mouv-hifi.mp3',
      'https://icecast.radiofrance.fr/mouv-midfi.mp3'
    ],
    icon: '🇫🇷',
    accentColor: '#10b981',
    descAr: 'إذاعة Mouv\' الفرنسية، أفضل أغاني الهيب هوب والموسيقى العصرية',
    descEn: 'French radio station featuring Hip Hop, R&B and urban music'
  },
  {
    id: 'gay-fm',
    name: 'GAY FM - Pure Dance',
    category: 'silvacast',
    genreAr: 'دانس وإلكترونيك بوب (GAY FM)',
    genreEn: 'Pure Dance & Club Hits',
    url: '/api/radio-stream?url=https%3A%2F%2Ficepool.silvacast.com%2FGAYFM.mp3',
    streamUrl: 'https://icepool.silvacast.com/GAYFM.mp3',
    fallbackUrls: [
      'https://icepool.silvacast.com/GAYFM.mp3',
      'https://stream.gayfm.de/gayfm.mp3',
      'https://0n-gay.radionetz.de/0n-gay.mp3'
    ],
    icon: '🌈',
    accentColor: '#ec4899',
    descAr: 'إيقاعات دانس وكلوب ميوزك نشطة وأغاني البوب الحماسية',
    descEn: 'High energy dance, EDM and top international club charts'
  },
  {
    id: 'nrj-egypt',
    name: 'NRJ Egypt (92.1 FM) - إينرجي مصر',
    category: 'arabic',
    genreAr: 'هيتس وبوب عالمي وعربي (NRJ Egypt)',
    genreEn: 'Hit Music & Pop (92.1 FM Cairo)',
    url: '/api/radio-stream?url=https%3A%2F%2Fnrjstreaming.ahmed-melege.com%2Fnrjegypt',
    streamUrl: 'https://nrjstreaming.ahmed-melege.com/nrjegypt',
    fallbackUrls: [
      'https://nrjstreaming.ahmed-melege.com/nrjegypt',
      'http://nrjstreaming.ahmed-melege.com/nrjegypt'
    ],
    icon: '📻',
    accentColor: '#ef4444',
    descAr: 'المحطة الإذاعية الأولى للموسيقى الشبابية والأغاني الحديثة في مصر',
    descEn: 'Hit music, pop & trending charts live from Egypt'
  }
];

interface DefjayRadioProps {
  isOpen: boolean;
  onClose: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const DefjayRadio: React.FC<DefjayRadioProps> = ({
  isOpen,
  onClose,
  soundEnabled,
  onToggleSound
}) => {
  const { language } = useLanguage();
  const [currentStation, setCurrentStation] = useState<RadioStation>(RADIO_STATIONS[0]);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'arabic' | 'silvacast' | 'focus'>('all');

  const filteredStations = selectedCategory === 'all' 
    ? RADIO_STATIONS 
    : RADIO_STATIONS.filter(s => s.category === selectedCategory);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(0.75);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [fallbackIndex, setFallbackIndex] = useState<number>(0);
  const [nowPlaying, setNowPlaying] = useState<Record<string, string>>({});

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const playPromiseRef = useRef<Promise<void> | null>(null);

  // Poll metadata for all stations
  useEffect(() => {
    let isMounted = true;
    const fetchMetadata = async () => {
      for (const station of RADIO_STATIONS) {
        try {
          const res = await fetch(`/api/radio-metadata?url=${encodeURIComponent(station.streamUrl)}`);
          if (res.ok) {
            const data = await res.json();
            if (data.title && isMounted) {
              setNowPlaying(prev => ({ ...prev, [station.id]: data.title }));
            }
          }
        } catch (err) {
          // Silent catch
        }
      }
    };

    if (isOpen) {
      fetchMetadata();
      const intervalId = setInterval(fetchMetadata, 20000);
      return () => {
        isMounted = false;
        clearInterval(intervalId);
      };
    }
  }, [isOpen]);

  // Play audio safely
  const startPlayback = useCallback((url: string) => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      // DO NOT set crossOrigin = 'anonymous' to avoid CORS rejections on icecast servers
    }

    const audio = audioRef.current;
    setIsLoading(true);
    setStatusMessage(language === 'ar' ? 'جاري الاتصال بالبث المباشر...' : 'Connecting to live stream...');

    audio.src = url;
    audio.load();

    const playPromise = audio.play();
    playPromiseRef.current = playPromise;

    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          setIsPlaying(true);
          setIsLoading(false);
          setStatusMessage(null);
        })
        .catch((err: any) => {
          // Check if station has fallbacks
          console.warn('Audio play attempt error:', err?.message);
          const allUrls = [currentStation.url, ...(currentStation.fallbackUrls || [])];
          setFallbackIndex((prevIdx) => {
            const nextIdx = prevIdx + 1;
            if (nextIdx < allUrls.length) {
              setStatusMessage(language === 'ar' ? 'جاري تجربة خادم بث بديل...' : 'Switching to backup server...');
              startPlayback(allUrls[nextIdx]);
              return nextIdx;
            } else {
              setIsLoading(false);
              setIsPlaying(false);
              setStatusMessage(
                language === 'ar' 
                  ? 'يرجى النقر على زر التشغيل لبدء البث المباشر' 
                  : 'Click play to start live stream'
              );
              return 0;
            }
          });
        });
    }
  }, [currentStation, language]);

  // Setup Audio Event Listeners
  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
    }

    const audio = audioRef.current;

    const handleWaiting = () => setIsLoading(true);
    const handleCanPlay = () => setIsLoading(false);
    const handlePlaying = () => {
      setIsLoading(false);
      setIsPlaying(true);
      setStatusMessage(null);
    };
    const handlePause = () => {
      setIsPlaying(false);
    };
    const handleError = () => {
      setIsLoading(false);
      setIsPlaying(false);
      const allUrls = [currentStation.url, ...(currentStation.fallbackUrls || [])];
      setFallbackIndex((prevIdx) => {
        const nextIdx = prevIdx + 1;
        if (nextIdx < allUrls.length) {
          setStatusMessage(language === 'ar' ? 'جاري التحويل لخادم احتياطي...' : 'Connecting to backup stream...');
          startPlayback(allUrls[nextIdx]);
          return nextIdx;
        } else {
          setStatusMessage(
            language === 'ar' 
              ? 'اضغط زر تشغيل لإعادة محاولة الاتصال' 
              : 'Click play to retry connection'
          );
          return 0;
        }
      });
    };

    audio.addEventListener('waiting', handleWaiting);
    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('playing', handlePlaying);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('waiting', handleWaiting);
      audio.removeEventListener('canplay', handleCanPlay);
      audio.removeEventListener('playing', handlePlaying);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('error', handleError);
    };
  }, [currentStation, startPlayback, language]);

  // Handle Volume Change
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  // Change Station Stream
  const handleSelectStation = (station: RadioStation) => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    setCurrentStation(station);
    setFallbackIndex(0);
    startPlayback(station.url);
  };

  // Toggle Play / Pause
  const handleTogglePlay = () => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
    }

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
      setIsLoading(false);
      setStatusMessage(null);
    } else {
      const allUrls = [currentStation.url, ...(currentStation.fallbackUrls || [])];
      const targetUrl = allUrls[fallbackIndex] || currentStation.url;
      startPlayback(targetUrl);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl max-h-[95vh] flex flex-col rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-rose-500/40 p-4 sm:p-6 shadow-[0_0_50px_rgba(225,29,72,0.22)] overflow-hidden">
        
        {/* Glowing Background Ambiance */}
        <div 
          className="absolute -top-16 -right-16 w-56 h-56 rounded-full blur-3xl opacity-20 transition-all pointer-events-none"
          style={{ backgroundColor: currentStation.accentColor }}
        />

        {/* Modal Top Bar */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 relative z-10 shrink-0">
          <div className="flex items-center gap-2.5">
            <div 
              className="p-2 sm:p-2.5 rounded-2xl border shadow-lg flex items-center justify-center text-xl shrink-0"
              style={{ 
                backgroundColor: `${currentStation.accentColor}20`,
                borderColor: `${currentStation.accentColor}50` 
              }}
            >
              <Radio className="w-5 h-5 text-rose-400" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm sm:text-base font-black text-rose-200 truncate">
                  {language === 'ar' ? 'مشغل الراديو الموسيقي' : 'Live Radio Lounge'}
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 shrink-0">
                  <Wifi className="w-2.5 h-2.5" />
                  LIVE
                </span>
              </div>
              <p className="text-[9px] sm:text-[10.5px] text-slate-400 truncate">
                {language === 'ar' ? 'بث مباشر لتعزيز التركيز أثناء التداول' : 'High quality direct audio streams for trading focus'}
              </p>
            </div>
          </div>

          <button
            id="close-defjay-radio-btn"
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer shrink-0 ml-2"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Now Playing Visualizer Box */}
        <div className="my-2 sm:my-3.5 p-3 sm:p-4 rounded-2xl bg-slate-950/90 border border-slate-800 relative z-10 shadow-inner shrink-0">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <div className="relative shrink-0">
                <div 
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl border shadow-lg transition-transform ${
                    isPlaying ? 'scale-105 shadow-rose-500/25' : 'opacity-80'
                  }`}
                  style={{
                    backgroundColor: `${currentStation.accentColor}25`,
                    borderColor: `${currentStation.accentColor}60`
                  }}
                >
                  {currentStation.icon}
                </div>
                {isPlaying && (
                  <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
                )}
              </div>

              <div className="flex-1 min-w-0">
                <span className="text-[10px] font-bold text-rose-400 font-mono tracking-wider flex items-center gap-1">
                  {isPlaying ? (
                    <>
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      {language === 'ar' ? 'بث مباشر متصل' : 'LIVE ON AIR'}
                    </>
                  ) : isLoading ? (
                    <>
                      <RotateCw className="w-2.5 h-2.5 animate-spin text-rose-400" />
                      {language === 'ar' ? 'جاري الاتصال...' : 'CONNECTING...'}
                    </>
                  ) : (
                    language === 'ar' ? '⏹ متوقف' : '⏹ PAUSED'
                  )}
                </span>
                <h3 className="text-sm font-black text-white tracking-wide truncate">
                  {currentStation.name}
                </h3>
                {nowPlaying[currentStation.id] && (
                  <span className="text-[11px] font-bold text-rose-300 truncate block mt-0.5">
                    🎵 {nowPlaying[currentStation.id]}
                  </span>
                )}
                <span className="text-[11px] text-slate-400 truncate block mt-0.5">
                  {language === 'ar' ? currentStation.genreAr : currentStation.genreEn}
                </span>
              </div>
            </div>

            {/* Equalizer Animation Bars */}
            <div className="hidden sm:flex items-end gap-1 h-7 px-2">
              {[0.4, 0.8, 0.5, 0.9, 0.3, 0.7].map((heightScale, i) => (
                <div
                  key={i}
                  className={`w-1 rounded-full transition-all duration-300 ${
                    isPlaying ? 'bg-rose-500 animate-pulse shadow-[0_0_8px_rgba(244,63,94,0.6)]' : 'bg-slate-700'
                  }`}
                  style={{
                    height: isPlaying ? `${Math.max(6, heightScale * 26)}px` : '4px',
                    animationDelay: `${i * 120}ms`
                  }}
                />
              ))}
            </div>

          </div>

          {/* Player Main Controls: Play/Pause + Volume Slider */}
          <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between gap-2 flex-wrap">
            
            {/* Play / Pause Big Button */}
            <button
              id="radio-toggle-play-btn"
              onClick={handleTogglePlay}
              disabled={isLoading}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 via-rose-500 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-black text-xs transition-all shadow-lg shadow-rose-600/30 active:scale-95 cursor-pointer disabled:opacity-75 border border-rose-400/30"
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <RotateCw className="w-3.5 h-3.5 animate-spin" />
                  <span>{language === 'ar' ? 'جاري التحميل...' : 'Buffering...'}</span>
                </span>
              ) : isPlaying ? (
                <span className="flex items-center justify-center gap-2">
                  <Pause className="w-4 h-4 fill-current" />
                  <span>{language === 'ar' ? 'إيقاف مؤقت' : 'PAUSE'}</span>
                </span>
              ) : (
                <span className="flex items-center justify-center gap-2">
                  <Play className="w-4 h-4 fill-current" />
                  <span>{language === 'ar' ? 'تشغيل البث المباشر' : 'PLAY LIVE'}</span>
                </span>
              )}
            </button>

            {/* Volume Control Bar */}
            <div className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-slate-900 px-3 py-2 rounded-xl border border-slate-800">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-rose-400" />}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={isMuted ? 0 : volume}
                onChange={(e) => {
                  setVolume(parseFloat(e.target.value));
                  if (isMuted) setIsMuted(false);
                }}
                className="w-full sm:w-24 h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-rose-500"
              />
            </div>

          </div>

          {/* Stream Status / Notice */}
          {statusMessage && (
            <div className="mt-2 text-[11px] text-rose-300/90 font-medium flex items-center gap-1.5 bg-rose-500/10 px-2.5 py-1.5 rounded-lg border border-rose-500/20">
              <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
              <span>{statusMessage}</span>
            </div>
          )}
        </div>

        {/* Stations Selection List */}
        <div className="space-y-2 relative z-10 flex-1 min-h-0 flex flex-col mt-2">
          <div className="flex items-center justify-between px-1 mb-1 gap-2 flex-wrap">
            <span className="text-[11px] font-bold text-slate-300">
              {language === 'ar' ? 'المحطات المتاحة:' : 'Available Stations:'}
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                  selectedCategory === 'all'
                    ? 'bg-gradient-to-r from-rose-600 to-rose-500 text-white shadow-sm border border-rose-400/30'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white'
                }`}
              >
                {language === 'ar' ? 'الكل' : 'All'}
              </button>
              <button
                onClick={() => setSelectedCategory('arabic')}
                className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                  selectedCategory === 'arabic'
                    ? 'bg-gradient-to-r from-rose-600 to-rose-500 text-white shadow-sm border border-rose-400/30'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white'
                }`}
              >
                {language === 'ar' ? '🇩🇿 جزائري وعربي' : '🇩🇿 Algerian'}
              </button>
              <button
                onClick={() => setSelectedCategory('silvacast')}
                className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                  selectedCategory === 'silvacast'
                    ? 'bg-gradient-to-r from-rose-600 to-rose-500 text-white shadow-sm border border-rose-400/30'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white'
                }`}
              >
                {language === 'ar' ? '🌍 عالمي' : '🌍 Global'}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-2 overflow-y-auto max-h-[220px] p-0.5 rounded-xl custom-scrollbar">
            {filteredStations.map((station) => {
              const isSelected = currentStation.id === station.id;
              return (
                <button
                  key={station.id}
                  id={`station-btn-${station.id}`}
                  onClick={() => handleSelectStation(station)}
                  className={`p-2 sm:p-2.5 rounded-xl border text-left rtl:text-right transition-all flex items-start gap-2.5 cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800/90 border-rose-500/60 shadow-md text-white ring-1 ring-rose-500/30'
                      : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-800/50'
                  }`}
                >
                  <span className="text-xl shrink-0 mt-0.5">{station.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <h4 className="text-xs font-bold text-white truncate">{station.name}</h4>
                      {isSelected && (
                        <span className="w-2 h-2 rounded-full bg-rose-400 shrink-0 animate-pulse shadow-[0_0_6px_rgba(244,63,94,0.8)]" />
                      )}
                    </div>
                    {nowPlaying[station.id] && (
                      <p className="text-[10px] font-bold text-rose-300/90 line-clamp-1 mt-0.5">
                        🎵 {nowPlaying[station.id]}
                      </p>
                    )}
                    <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
                      {language === 'ar' ? station.descAr : station.descEn}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Secondary Trading Signals Sound Effects Toggle */}
        <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between relative z-10 text-xs shrink-0">
          <div className="flex items-center gap-2 text-slate-300">
            <Sparkles className="w-4 h-4 text-rose-400" />
            <span>{language === 'ar' ? 'مؤثرات صفقات الشارت الصوتية:' : 'Chart Signal Audio Effects:'}</span>
          </div>
          <button
            onClick={onToggleSound}
            className={`px-3 py-1 rounded-lg font-bold transition-all text-xs cursor-pointer ${
              soundEnabled 
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
                : 'bg-slate-800 text-slate-500'
            }`}
          >
            {soundEnabled ? (language === 'ar' ? 'مفعلة ✅' : 'ON ✅') : (language === 'ar' ? 'معطلة ❌' : 'OFF ❌')}
          </button>
        </div>

      </div>
    </div>
  );
};
