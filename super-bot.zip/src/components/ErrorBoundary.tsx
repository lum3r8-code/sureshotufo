import { Component, ReactNode, ErrorInfo } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends (Component as any) {
  public state: State;
  public props: Props;
  public setState: (state: Partial<State>, callback?: () => void) => void;

  constructor(props: Props) {
    super(props);
    this.props = props;
    this.state = {
      hasError: false,
      error: null,
    };
    this.setState = (Component.prototype as any).setState?.bind(this) || ((newState: Partial<State>) => {
      Object.assign(this.state, newState);
    });
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    console.error('[ErrorBoundary] Intercepted runtime React component error:', error, errorInfo);
    
    // Automatic self-healing: purge corrupted localStorage keys that might cause React render crashes
    try {
      const keysToClean = ['quant_stats_', 'quant_logs_', 'saas_admin_token_corrupt'];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && keysToClean.some(k => key.includes(k))) {
          localStorage.removeItem(key);
        }
      }
    } catch {}

    // Auto-recovery attempt: silently try to reset boundary after short delay
    setTimeout(() => {
      try {
        if (this.state.hasError) {
          this.setState({ hasError: false, error: null });
        }
      } catch {}
    }, 1200);
  }

  private handleReset = (): void => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  public render(): ReactNode {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-6 dir-rtl">
          <div className="max-w-md w-full bg-slate-900 border border-emerald-500/30 rounded-2xl p-6 shadow-2xl text-center space-y-4">
            <div className="w-16 h-16 bg-red-500/10 border border-red-500/30 rounded-full flex items-center justify-center mx-auto text-red-400 text-2xl font-bold">
              ⚠️
            </div>
            <h2 className="text-xl font-bold text-slate-100">درع الحصانة التلقائية للنظام</h2>
            <p className="text-sm text-slate-400 leading-relaxed">
              تم رصد وتأمين استثناء غير متوقع في واجهة العرض بشكل تلقائي دون تأثر خوادم التداول.
            </p>
            {this.state.error?.message && (
              <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-3 text-xs font-mono text-amber-400 text-left overflow-x-auto dir-ltr">
                {this.state.error.message}
              </div>
            )}
            <button
              onClick={this.handleReset}
              className="w-full py-3 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl shadow-lg transition-all duration-200 cursor-pointer"
            >
              🔄 إعادة تنشيط الواجهة واستكمال التداول
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
