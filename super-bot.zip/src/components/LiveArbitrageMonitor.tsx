import React from 'react';
import { Activity, Coins, Zap, ShieldCheck, Globe, CheckCircle2 } from 'lucide-react';
import { CryptoSpread } from '../types';

interface LiveArbitrageMonitorProps {
  liveSpreads?: CryptoSpread[];
  arbitrageThreshold: number;
}

export default function LiveArbitrageMonitor({
  liveSpreads = [],
  arbitrageThreshold
}: LiveArbitrageMonitorProps) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 mb-6" id="live-market-feeds">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-850 pb-4 mb-5">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-extrabold text-white text-base">شاشة رصد أسعار البورصات العالمية الحية (Live Market Feeds)</h2>
            <p className="text-[10px] text-slate-400 mt-0.5">تغذية لحظية مباشرة لأسعار الأصول وفروقات البورصات (معلوماتية فقط للمطورين والمشتركين — خالية 100% من متطلبات رأس المال)</p>
          </div>
        </div>
        <div className="flex items-center gap-2 self-start sm:self-center">
          <span className="flex h-2 w-2 relative">
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/40 border border-emerald-900/40 px-2 py-0.5 rounded-md">
            بث لحظي مباشر (Zero-Capital Data Stream)
          </span>
        </div>
      </div>

      {/* Grid: Left side live prices, Right side Data Quality & Intelligence */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        
        {/* Left Card: Spreads Table */}
        <div className="bg-slate-950/50 rounded-xl border border-slate-850 p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Coins className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-bold text-white">الأسعار الحية بين البورصات (Binance vs Coinbase)</h3>
            </div>
            <span className="text-[9px] text-slate-400 font-mono">تحديث كل 3 ثوانٍ</span>
          </div>

          <div className="space-y-3">
            {liveSpreads.length === 0 ? (
              <div className="text-center py-6 text-[11px] text-slate-500">
                يجري استقطاب التغذية الحية لأسعار الأصول من البورصات...
              </div>
            ) : (
              liveSpreads.map((spread) => {
                const spreadDiff = Math.abs(spread.directPrice - spread.crossPrice);
                return (
                  <div 
                    key={spread.asset} 
                    className="p-3 rounded-lg border bg-slate-900/40 border-slate-850 hover:border-slate-800 transition duration-150"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-white px-1.5 py-0.5 bg-slate-800 rounded">
                          {spread.asset}/USDT
                        </span>
                        <span className="text-[10px] text-slate-400 flex items-center gap-1">
                          <Zap className="w-3 h-3 text-sky-400" /> استجابة: {spread.latencyAgeMs}ms
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] text-slate-500">التباين السعري:</span>
                        <span className="text-xs font-bold text-slate-200">
                          {spread.spreadPercent.toFixed(3)}% (${spreadDiff.toFixed(2)})
                        </span>
                      </div>
                    </div>

                    {/* Price details bar */}
                    <div className="grid grid-cols-3 gap-2 text-[10px] border-t border-slate-850/60 pt-2 mt-2">
                      <div>
                        <span className="block text-slate-500">سعر Binance</span>
                        <span className="font-bold text-white">${spread.directPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}</span>
                      </div>
                      <div>
                        <span className="block text-slate-500">سعر Coinbase</span>
                        <span className="font-bold text-white">${spread.crossPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}</span>
                      </div>
                      <div className="text-left">
                        <span className="block text-slate-500">معدل التذبذب 24h</span>
                        <span className="font-bold text-amber-500">±{spread.volatility.toFixed(1)}%</span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Card: Data Feed Analytics & Service Status (Zero Capital) */}
        <div className="bg-slate-950/50 rounded-xl border border-slate-850 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Globe className="w-4 h-4 text-sky-400" />
              <h3 className="text-xs font-bold text-white">حالة الاتصال ومصادر البيانات (Data Pipeline Status)</h3>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed mb-4">
              تعمل هذه المنصة كمزود بيانات برمجي سحابي (<span className="text-emerald-400 font-semibold">Data API Provider</span>). لا توجد أي حسابات تداول أو رأس مال مستخدم، حيث يتم جلب الأسعار وحركات الحيتان وتوزيعها للمشتركين عبر واجهات برمجية مدفوعة.
            </p>

            <div className="space-y-2.5">
              <div className="p-3 bg-slate-900/60 border border-slate-850 rounded-lg flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="text-slate-200 font-medium">اتصال منصة Binance الرسمية</span>
                </div>
                <span className="text-[10px] text-emerald-400 bg-emerald-950/40 border border-emerald-900/40 px-2 py-0.5 rounded font-bold">
                  متصل (200 OK)
                </span>
              </div>

              <div className="p-3 bg-slate-900/60 border border-slate-850 rounded-lg flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="text-slate-200 font-medium">اتصال منصة Coinbase Exchange</span>
                </div>
                <span className="text-[10px] text-emerald-400 bg-emerald-950/40 border border-emerald-900/40 px-2 py-0.5 rounded font-bold">
                  متصل (200 OK)
                </span>
              </div>

              <div className="p-3 bg-slate-900/60 border border-slate-850 rounded-lg flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="text-slate-200 font-medium">مستكشف بلوكشين Tron (TronScan)</span>
                </div>
                <span className="text-[10px] text-emerald-400 bg-emerald-950/40 border border-emerald-900/40 px-2 py-0.5 rounded font-bold">
                  متزامن مع المحفظة
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-850/60 flex items-center justify-between text-[10px] text-slate-500">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              خالٍ من مخاطر التداول المالي
            </span>
            <span className="font-mono text-slate-400">REST API v1 Live</span>
          </div>
        </div>

      </div>
    </div>
  );
}
