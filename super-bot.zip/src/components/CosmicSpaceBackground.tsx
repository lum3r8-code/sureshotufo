import React, { useEffect, useRef } from 'react';
// @ts-ignore
import nebulaBg from '../assets/images/deep_space_nebula_1790174744086.jpg';

export const CosmicSpaceBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    // Generate realistic twinkling stars
    const starsCount = Math.floor((width * height) / 4000);
    const stars: Array<{
      x: number;
      y: number;
      radius: number;
      baseAlpha: number;
      alpha: number;
      twinkleSpeed: number;
      color: string;
    }> = [];

    const starColors = ['#ffffff', '#e0f2fe', '#fde047', '#f43f5e', '#a855f7', '#38bdf8'];

    for (let i = 0; i < starsCount; i++) {
      stars.push({
        x: Math.random() * width,
        y: Math.random() * height,
        radius: Math.random() * 1.6 + 0.4,
        baseAlpha: Math.random() * 0.7 + 0.3,
        alpha: Math.random(),
        twinkleSpeed: 0.01 + Math.random() * 0.03,
        color: starColors[Math.floor(Math.random() * starColors.length)]
      });
    }

    // Shooting Star state
    let shootingStar: {
      x: number;
      y: number;
      length: number;
      speed: number;
      angle: number;
      opacity: number;
      active: boolean;
    } | null = null;

    // UFO State Engine (4 Distinct Realistic UFO Models)
    // Triggers every 8 minutes (480,000ms), or immediately when clicking the title!
    let ufoModelIndex = 0;
    let lastUfoTime = Date.now() - (480000 - 10000); // Showcase run 10s after load
    const ufoInterval = 8 * 60 * 1000; // Exactly 8 minutes

    interface UFOState {
      x: number;
      y: number;
      vx: number;
      vy: number;
      type: number; // 0: Cyberpunk Saucer, 1: Tri-Scout Mothership, 2: Quantum Orb, 3: Stealth Diamond
      scale: number;
      active: boolean;
      direction: number; // 1: Left to Right, -1: Right to Left
      angle: number;
      beamPulse: number;
    }

    let ufo: UFOState = {
      x: -200,
      y: 60,
      vx: 1.2,
      vy: 0,
      type: 0,
      scale: 0.85,
      active: false,
      direction: 1,
      angle: 0,
      beamPulse: 0
    };

    const launchNewUfo = () => {
      ufo.active = true;
      ufo.type = ufoModelIndex % 4; // Cycle through 4 distinct UFO models
      ufoModelIndex++;

      ufo.direction = Math.random() > 0.5 ? 1 : -1;
      ufo.x = ufo.direction === 1 ? -220 : width + 220;
      ufo.y = Math.random() * 60 + 35; // Gliding gracefully in the title & header area
      ufo.vx = (1.2 + Math.random() * 0.7) * ufo.direction;
      ufo.scale = 0.85 + Math.random() * 0.25;
      lastUfoTime = Date.now();
    };

    // Listen for title click event
    window.addEventListener('trigger-ufo-launch', launchNewUfo);

    let lastShootingStarTime = Date.now();
    const shootingStarInterval = 20000;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // 1. Render Twinkling Stars
      for (const star of stars) {
        star.alpha += star.twinkleSpeed;
        if (star.alpha > 1 || star.alpha < 0.2) {
          star.twinkleSpeed = -star.twinkleSpeed;
        }

        ctx.save();
        ctx.globalAlpha = Math.max(0.1, Math.min(1, star.alpha * star.baseAlpha));
        ctx.fillStyle = star.color;
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
        ctx.fill();

        if (star.radius > 1.4) {
          ctx.shadowBlur = 6;
          ctx.shadowColor = star.color;
          ctx.fill();
        }
        ctx.restore();
      }

      const now = Date.now();

      // 2. Trigger Shooting Star
      if (!shootingStar && now - lastShootingStarTime > shootingStarInterval + Math.random() * 8000) {
        shootingStar = {
          x: Math.random() * width,
          y: Math.random() * (height * 0.4),
          length: Math.random() * 90 + 70,
          speed: Math.random() * 8 + 6,
          angle: Math.PI / 4 + (Math.random() * 0.2 - 0.1),
          opacity: 1.0,
          active: true
        };
        lastShootingStarTime = now;
      }

      if (shootingStar && shootingStar.active) {
        ctx.save();
        ctx.strokeStyle = `rgba(255, 255, 255, ${shootingStar.opacity})`;
        ctx.lineWidth = 2;
        ctx.shadowBlur = 12;
        ctx.shadowColor = '#38bdf8';
        ctx.beginPath();
        ctx.moveTo(shootingStar.x, shootingStar.y);
        ctx.lineTo(
          shootingStar.x - Math.cos(shootingStar.angle) * shootingStar.length,
          shootingStar.y - Math.sin(shootingStar.angle) * shootingStar.length
        );
        ctx.stroke();
        ctx.restore();

        shootingStar.x += Math.cos(shootingStar.angle) * shootingStar.speed;
        shootingStar.y += Math.sin(shootingStar.angle) * shootingStar.speed;
        shootingStar.opacity -= 0.018;

        if (shootingStar.opacity <= 0 || shootingStar.x > width || shootingStar.y > height) {
          shootingStar = null;
        }
      }

      // 3. Auto Trigger UFO Every 8 Minutes
      if (!ufo.active && now - lastUfoTime >= ufoInterval) {
        launchNewUfo();
      }

      if (ufo.active) {
        ctx.save();

        // Realistic Organic Wave Gliding Motion
        const hoverY = ufo.y + Math.sin(now / 500) * 8 + Math.cos(now / 1200) * 4;
        const tiltAngle = (Math.cos(now / 400) * 0.06) * ufo.direction;

        ctx.translate(ufo.x, hoverY);
        ctx.scale(ufo.scale, ufo.scale);
        ctx.rotate(tiltAngle);

        const time = now / 1000;

        // Render Distinct Model Architecture
        if (ufo.type === 0) {
          // --- MODEL 1: CYBERPUNK DISK SAUCER ---
          const beamGrad = ctx.createLinearGradient(0, 0, 0, 180);
          beamGrad.addColorStop(0, 'rgba(56, 189, 248, 0.35)');
          beamGrad.addColorStop(1, 'rgba(56, 189, 248, 0.0)');
          ctx.fillStyle = beamGrad;
          ctx.beginPath();
          ctx.moveTo(-15, 6);
          ctx.lineTo(15, 6);
          ctx.lineTo(55, 180);
          ctx.lineTo(-55, 180);
          ctx.closePath();
          ctx.fill();

          ctx.shadowBlur = 15;
          ctx.shadowColor = '#06b6d4';
          const domeGrad = ctx.createRadialGradient(0, -8, 2, 0, -8, 16);
          domeGrad.addColorStop(0, '#c084fc');
          domeGrad.addColorStop(0.7, '#38bdf8');
          domeGrad.addColorStop(1, '#0284c7');
          ctx.fillStyle = domeGrad;
          ctx.beginPath();
          ctx.arc(0, -6, 16, Math.PI, 0, false);
          ctx.fill();

          const hullGrad = ctx.createLinearGradient(-50, 0, 50, 0);
          hullGrad.addColorStop(0, '#1e1b4b');
          hullGrad.addColorStop(0.5, '#e879f9');
          hullGrad.addColorStop(1, '#0f172a');
          ctx.fillStyle = hullGrad;
          ctx.beginPath();
          ctx.ellipse(0, 2, 52, 12, 0, 0, Math.PI * 2);
          ctx.fill();

          for (let i = 0; i < 6; i++) {
            const angle = time * 3 + (i * Math.PI / 3);
            const lx = Math.cos(angle) * 42;
            const ly = Math.sin(angle) * 6 + 2;
            ctx.fillStyle = (i % 2 === 0) ? '#fde047' : '#f43f5e';
            ctx.shadowBlur = 10;
            ctx.shadowColor = ctx.fillStyle;
            ctx.beginPath();
            ctx.arc(lx, ly, 3, 0, Math.PI * 2);
            ctx.fill();
          }

        } else if (ufo.type === 1) {
          // --- MODEL 2: TRIANGULAR STEALTH MOTHERSHIP ---
          ctx.shadowBlur = 20;
          ctx.shadowColor = '#a855f7';

          ctx.fillStyle = 'rgba(168, 85, 247, 0.4)';
          ctx.beginPath();
          ctx.moveTo(-ufo.direction * 40, -4);
          ctx.lineTo(-ufo.direction * 90, -12);
          ctx.lineTo(-ufo.direction * 90, 12);
          ctx.closePath();
          ctx.fill();

          const hullGrad = ctx.createLinearGradient(-45, -15, 45, 15);
          hullGrad.addColorStop(0, '#0f172a');
          hullGrad.addColorStop(0.5, '#581c87');
          hullGrad.addColorStop(1, '#3b0764');
          ctx.fillStyle = hullGrad;
          ctx.strokeStyle = '#c084fc';
          ctx.lineWidth = 1.5;

          ctx.beginPath();
          ctx.moveTo(ufo.direction * 50, 0);
          ctx.lineTo(-ufo.direction * 35, -22);
          ctx.lineTo(-ufo.direction * 25, 0);
          ctx.lineTo(-ufo.direction * 35, 22);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();

          ctx.fillStyle = '#f43f5e';
          ctx.shadowBlur = 15;
          ctx.shadowColor = '#f43f5e';
          ctx.beginPath();
          ctx.arc(0, 0, 6, 0, Math.PI * 2);
          ctx.fill();

        } else if (ufo.type === 2) {
          // --- MODEL 3: QUANTUM ORB SCOUT ---
          ctx.shadowBlur = 25;
          ctx.shadowColor = '#38bdf8';

          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.ellipse(0, 0, 32, 10, time * 2, 0, Math.PI * 2);
          ctx.stroke();

          ctx.strokeStyle = '#e879f9';
          ctx.beginPath();
          ctx.ellipse(0, 0, 32, 10, -time * 2.5, 0, Math.PI * 2);
          ctx.stroke();

          const coreGrad = ctx.createRadialGradient(0, 0, 2, 0, 0, 16);
          coreGrad.addColorStop(0, '#ffffff');
          coreGrad.addColorStop(0.5, '#38bdf8');
          coreGrad.addColorStop(1, '#1e1b4b');
          ctx.fillStyle = coreGrad;
          ctx.beginPath();
          ctx.arc(0, 0, 16, 0, Math.PI * 2);
          ctx.fill();

        } else {
          // --- MODEL 4: DIAMOND INTERCEPTOR ---
          ctx.shadowBlur = 18;
          ctx.shadowColor = '#10b981';

          const diamondGrad = ctx.createLinearGradient(-35, 0, 35, 0);
          diamondGrad.addColorStop(0, '#064e3b');
          diamondGrad.addColorStop(0.5, '#34d399');
          diamondGrad.addColorStop(1, '#022c22');
          ctx.fillStyle = diamondGrad;

          ctx.beginPath();
          ctx.moveTo(0, -18);
          ctx.lineTo(45, 0);
          ctx.lineTo(0, 18);
          ctx.lineTo(-45, 0);
          ctx.closePath();
          ctx.fill();

          ctx.fillStyle = '#6ee7b7';
          ctx.beginPath();
          ctx.ellipse(0, -2, 16, 6, 0, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();

        ufo.x += ufo.vx;

        if ((ufo.direction === 1 && ufo.x > width + 220) || (ufo.direction === -1 && ufo.x < -220)) {
          ufo.active = false;
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('trigger-ufo-launch', launchNewUfo);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden gpu-layer">
      {/* Deep Space Nebula Image Background */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat scale-105 transition-transform duration-1000"
        style={{
          backgroundImage: `url(${nebulaBg})`,
          filter: 'brightness(0.75) contrast(1.15) saturate(1.2)'
        }}
      />
      {/* Cinematic Dark Gradient Overlay for optimal readability */}
      <div className="absolute inset-0 bg-slate-950/50 backdrop-blur-[0.5px]" />
      
      {/* Twinkling Stars & UFO Canvas */}
      <canvas 
        ref={canvasRef} 
        className="absolute inset-0 w-full h-full pointer-events-none z-0" 
      />
    </div>
  );
};
