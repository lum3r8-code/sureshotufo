import React, { useState } from 'react';
import { Terminal, Play, AlertCircle, CheckCircle, ArrowLeftRight } from 'lucide-react';
import { SaaSAPIKey } from '../types';

interface SandboxConsoleProps {
  keys: SaaSAPIKey[];
}

export default function SandboxConsole({ keys }: SandboxConsoleProps) {
  const [selectedKey, setSelectedKey] = useState<string>('');
  const [selectedEndpoint, setSelectedEndpoint] = useState<string>('/api/v1/arbitrage/spreads');
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [responseHeaders, setResponseHeaders] = useState<Record<string, string> | null>(null);
  const [responseBody, setResponseBody] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [customKey, setCustomKey] = useState<string>('');
  const [useCustomKey, setUseCustomKey] = useState<boolean>(false);

  // Simple local JSON syntax highlighter
  const highlightJson = (jsonObj: any) => {
    if (!jsonObj) return [];
    const str = JSON.stringify(jsonObj, null, 2);
    const lines = str.split('\n');

    return lines.map((line, idx) => {
      // Find keys, strings, numbers, booleans
      let renderedLine = <span className="text-slate-300">{line}</span>;

      // Match keys
      const keyMatch = line.match(/^(\s*)"([^"]+)":/);
      if (keyMatch) {
        const indent = keyMatch[1];
        const keyName = keyMatch[2];
        const rest = line.substring(keyMatch[0].length);

        renderedLine = (
          <span>
            <span className="text-slate-500">{indent}</span>
            <span className="text-emerald-400">"{keyName}"</span>
            <span className="text-slate-400">:</span>
            {highlightValue(rest)}
          </span>
        );
      } else {
        renderedLine = highlightValue(line);
      }

      return (
        <div key={idx} className="leading-5 whitespace-pre">
          {renderedLine}
        </div>
      );
    });
  };

  const highlightValue = (valStr: string) => {
    // Check if it's a string, number, bool, or null
    const trimVal = valStr.trim();
    if (trimVal.startsWith('"') && trimVal.endsWith('"') || trimVal.endsWith('",')) {
      return <span className="text-amber-400">{valStr}</span>;
    }
    if (trimVal.match(/^[0-9.-]+,?$/)) {
      return <span className="text-sky-400">{valStr}</span>;
    }
    if (trimVal.startsWith('true') || trimVal.startsWith('false')) {
      return <span className="text-purple-400">{valStr}</span>;
    }
    if (trimVal.startsWith('null')) {
      return <span className="text-slate-500">{valStr}</span>;
    }
    return <span className="text-slate-300">{valStr}</span>;
  };

  const handleRunRequest = async () => {
    setIsLoading(true);
    setResponseStatus(null);
    setResponseHeaders(null);
    setResponseBody(null);

    const apiKey = useCustomKey ? customKey : selectedKey;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json'
    };
    if (apiKey) {
      headers['x-api-key'] = apiKey;
    }

    try {
      const response = await fetch(selectedEndpoint, {
        method: 'GET',
        headers,
      });

      setResponseStatus(response.status);
      
      // Build dummy mock response headers based on real response
      const headersMap: Record<string, string> = {
        'Content-Type': 'application/json; charset=utf-8',
        'X-Powered-By': 'Express',
        'Cache-Control': 'no-store, no-cache, must-revalidate',
        'Server': 'Superbot-Autonomous-Gateway',
        'Date': new Date().toUTCString(),
      };
      setResponseHeaders(headersMap);

      const data = await response.json();
      setResponseBody(data);
    } catch (err: any) {
      setResponseStatus(500);
      setResponseBody({
        error: 'Network Error',
        message: 'تعذر الاتصال بخادم واجهة برمجة التطبيقات المحلي.',
        code: 'CONNECTION_FAILED'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 mb-6">
      {/* Header */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-4 mb-4">
        <Terminal className="w-5 h-5 text-sky-400" />
        <h2 className="font-extrabold text-white text-base">منصة اختبار واجهة البرمجة (Interactive Sandbox Console)</h2>
      </div>

      {/* Inputs Column */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-5 items-end">
        {/* API Key Selector */}
        <div className="md:col-span-5 space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="block text-[10px] font-semibold text-slate-400">اختر مفتاح الوصول للتجربة</label>
            <button
              onClick={() => setUseCustomKey(!useCustomKey)}
              className="text-[10px] text-sky-400 hover:underline focus:outline-none"
            >
              {useCustomKey ? 'اختر من القائمة' : 'كتابة مفتاح مخصص'}
            </button>
          </div>

          {useCustomKey ? (
            <input
              type="text"
              value={customKey}
              onChange={(e) => setCustomKey(e.target.value)}
              placeholder="SAAS-KEY-XXXXXX"
              className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none transition duration-150"
            />
          ) : (
            <select
              value={selectedKey}
              onChange={(e) => setSelectedKey(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-lg px-3 py-2 text-xs text-white focus:outline-none transition duration-150"
            >
              <option value="">بدون ترويسة مفتاح (توقع خطأ 401)</option>
              {keys.map((k) => (
                <option key={k.id} value={k.key}>
                  {k.label} ({k.key}) [{k.status === 'Active' ? 'نشط' : 'معطل'}]
                </option>
              ))}
            </select>
          )}
        </div>

        {/* Endpoint Selector */}
        <div className="md:col-span-5 space-y-1.5">
          <label className="block text-[10px] font-semibold text-slate-400">مسار واجهة البرمجة (API Endpoint)</label>
          <select
            value={selectedEndpoint}
            onChange={(e) => setSelectedEndpoint(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-lg px-3 py-2 text-xs text-white focus:outline-none transition duration-150"
          >
            <option value="/api/v1/arbitrage/spreads">GET /api/v1/arbitrage/spreads (فروق العملات الفورية)</option>
            <option value="/api/v1/arbitrage/opportunities">GET /api/v1/arbitrage/opportunities (إشارات التحكيم المصفاة)</option>
          </select>
        </div>

        {/* Submit Run Button */}
        <div className="md:col-span-2">
          <button
            onClick={handleRunRequest}
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg bg-sky-600 hover:bg-sky-500 text-white border border-sky-500 hover:border-sky-400 transition duration-150 disabled:opacity-50"
          >
            <Play className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>تشغيل الطلب</span>
          </button>
        </div>
      </div>

      {/* Developer Console View (Interactive HTTP Inspector) */}
      <div className="bg-black border border-slate-850 rounded-xl p-4 font-mono text-xs overflow-hidden flex flex-col md:flex-row gap-4">
        {/* Left Side: Request / Response Headers */}
        <div className="w-full md:w-1/3 border-b md:border-b-0 md:border-l border-slate-850 pb-4 md:pb-0 md:pl-4 space-y-4">
          {/* Request Header Simulated */}
          <div>
            <p className="text-[10px] font-bold text-slate-500 mb-1.5">بيانات الطلب الصادر (Request Headers)</p>
            <div className="bg-slate-950/80 border border-slate-900 p-2.5 rounded text-[10px] text-sky-400 space-y-1">
              <div><span className="text-purple-400 font-bold">GET</span> {selectedEndpoint} HTTP/1.1</div>
              <div><span className="text-slate-400">Host:</span> api.superbot.io</div>
              {useCustomKey ? (
                <div><span className="text-slate-400">x-api-key:</span> {customKey || '(فارغ)'}</div>
              ) : (
                <div><span className="text-slate-400">x-api-key:</span> {selectedKey || '(بدون ترويسة)'}</div>
              )}
              <div><span className="text-slate-400">Accept:</span> application/json</div>
            </div>
          </div>

          {/* Response Header Simulated */}
          <div>
            <p className="text-[10px] font-bold text-slate-500 mb-1.5">ترويسات الاستجابة (Response Headers)</p>
            {responseStatus ? (
              <div className="bg-slate-950/80 border border-slate-900 p-2.5 rounded text-[10px] space-y-1">
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="text-slate-400">الحالة:</span>
                  <span className={`font-bold px-1.5 py-0.5 rounded ${
                    responseStatus === 200 
                      ? 'bg-emerald-500/10 text-emerald-400' 
                      : 'bg-red-500/10 text-red-400'
                  }`}>
                    {responseStatus} {responseStatus === 200 ? 'OK' : responseStatus === 401 ? 'Unauthorized' : responseStatus === 403 ? 'Forbidden' : responseStatus === 429 ? 'Too Many Requests' : 'Error'}
                  </span>
                </div>
                {responseHeaders && Object.entries(responseHeaders).map(([k, v]) => (
                  <div key={k} className="text-slate-400">
                    <span className="text-slate-500">{k}:</span> {v}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-slate-600 italic text-[10px] text-center py-4 bg-slate-950/20 border border-slate-900 rounded">
                في انتظار إرسال الطلب لجمع البيانات...
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Response Body Output */}
        <div className="flex-1 flex flex-col min-h-[220px] max-h-[350px]">
          <p className="text-[10px] font-bold text-slate-500 mb-1.5">مخرجات الاستجابة (Response Body JSON)</p>
          <div className="flex-1 bg-slate-950 border border-slate-900 p-3 rounded overflow-y-auto font-mono text-[11px] scrollbar-thin scrollbar-thumb-slate-800">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center h-full text-slate-500 gap-2">
                <ArrowLeftRight className="w-6 h-6 animate-spin text-sky-400" />
                <span className="text-[10px]">يجري جلب البيانات وتحليل الفروق السعرية...</span>
              </div>
            ) : responseBody ? (
              <div className="space-y-0.5">
                {highlightJson(responseBody)}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-slate-600 italic text-[10px] text-center">
                <Terminal className="w-8 h-8 text-slate-700 mb-1.5" />
                <span>انقر على زر "تشغيل الطلب" في الأعلى لمشاهدة استجابة خادم التداول الحية.</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
