import React from 'react';
import fs from 'fs';
import path from 'path';
import { createCanvas, Image, GlobalFonts } from '@napi-rs/canvas';

// -------------------------------------------------------------
// Register Arabic & System Fonts Globally for @napi-rs/canvas
// -------------------------------------------------------------
try {
  const fontBoldCandidates = [
    path.join(process.cwd(), 'fonts', 'NotoSansArabic-Bold.ttf'),
    path.join(process.cwd(), 'public', 'fonts', 'NotoSansArabic-Bold.ttf'),
    path.join(process.cwd(), 'src', 'assets', 'fonts', 'NotoSansArabic-Bold.ttf'),
    path.join(process.cwd(), 'dist', 'fonts', 'NotoSansArabic-Bold.ttf')
  ];
  for (const fontPath of fontBoldCandidates) {
    if (fs.existsSync(fontPath)) {
      try {
        GlobalFonts.registerFromPath(fontPath, 'NotoSansArabic');
        break;
      } catch (e) {
        console.warn('[chartCardRenderer] Failed registering font at:', fontPath, e);
      }
    }
  }

  const fontRegCandidates = [
    path.join(process.cwd(), 'fonts', 'NotoSansArabic-Regular.ttf'),
    path.join(process.cwd(), 'public', 'fonts', 'NotoSansArabic-Regular.ttf'),
    path.join(process.cwd(), 'src', 'assets', 'fonts', 'NotoSansArabic-Regular.ttf'),
    path.join(process.cwd(), 'dist', 'fonts', 'NotoSansArabic-Regular.ttf')
  ];
  for (const fontPath of fontRegCandidates) {
    if (fs.existsSync(fontPath)) {
      try {
        GlobalFonts.registerFromPath(fontPath, 'NotoSansArabicRegular');
        break;
      } catch (e) {
        console.warn('[chartCardRenderer] Failed registering reg font at:', fontPath, e);
      }
    }
  }
} catch (e) {
  console.error('[chartCardRenderer] GlobalFonts registration error:', e);
}

/**
 * Renders the exact original GRS LIVE CHART HUD signal card image matching Image 2 perfectly.
 * Uses dark ruby gem background (ruby_bg_1788773530546.jpg), registered NotoSansArabic font,
 * center triangle emblem, HUD capsules, and vector icons.
 */
export function renderChartSignalCard(options: {
  pairName: string;
  timeframe: string;
  direction: 'CALL' | 'PUT' | string;
  entryTime: string;
  price?: number | string;
  confidence?: number | string;
  countdownTimer?: string;
  isStagnant?: boolean;
  isAtypicalVolatility?: boolean;
  isWeakOrVolatile?: boolean;
  isLiquidityUp?: boolean;
  shortReason?: string;
  latestIntegration?: string;
  isPaywalled?: boolean;
  starsPrice?: number;
  previousOutcome?: 'win' | 'loss' | string;
  customDate?: string;
  customSession?: string;
}): Buffer {
  const width = 1000;
  const height = 1520;

  let canvas: any;
  
  if (typeof document !== 'undefined' && (document as any).createElement) {
    canvas = (document as any).createElement('canvas');
    canvas.width = width;
    canvas.height = height;
  } else {
    // Node.js environment: Use @napi-rs/canvas
    try {
      canvas = createCanvas(width, height);
    } catch (e) {
      console.error('[chartCardRenderer] Error creating canvas via @napi-rs/canvas:', e);
      return Buffer.from([]);
    }
  }

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return Buffer.from([]);
  }

  const isCall = (options.direction || 'CALL').toUpperCase() === 'CALL';
  const pairStr = (options.pairName || 'EUR/USD').toUpperCase();
  const rawTf = String(options.timeframe || '1');
  const tfMins = parseInt(rawTf, 10) || 1;
  const tfBadgeText = rawTf.includes('M') || rawTf.includes('H') ? rawTf.toUpperCase() : `${tfMins}M`;

  let priceVal = typeof options.price === 'number' ? options.price : parseFloat(String(options.price || '1.14520'));
  if (isNaN(priceVal)) priceVal = 1.14520;
  const priceStr = priceVal.toFixed(5);

  const confidenceStr = options.confidence ? `${Number(options.confidence).toFixed(1)}%` : '88.3%';

  // Format Entry Time cleanly (Western numerals 0-9 only per System Rule 13)
  let cleanTime = options.entryTime || '17:06:03';
  const matchTime = cleanTime.match(/(\d{2}:\d{2}(?::\d{2})?)/);
  if (matchTime) {
    cleanTime = matchTime[1];
    if (cleanTime.length === 5) cleanTime += ':03';
  } else if (cleanTime.length < 5) {
    cleanTime = '17:06:03';
  }

  // Radar detection timestamp (e.g. 3 minutes before entry time)
  const timeParts = cleanTime.split(':').map(Number);
  let radarHour = timeParts[0] || 16;
  let radarMin = (timeParts[1] || 6) - 3;
  if (radarMin < 0) { radarMin += 60; radarHour = (radarHour - 1 + 24) % 24; }
  const radarTimeStr = `${String(radarHour).padStart(2, '0')}:${String(radarMin).padStart(2, '0')}:46`;

  // Determine current active UTC/Algiers trading session
  const now = new Date();
  const algiersHour = (now.getUTCHours() + 1) % 24;
  let sessionName = options.customSession || 'جلسة نيويورك (NY Session)';
  if (!options.customSession) {
    if (algiersHour >= 8 && algiersHour < 15) {
      sessionName = 'جلسة لندن (London Session)';
    } else if (algiersHour >= 0 && algiersHour < 8) {
      sessionName = 'جلسة طوكيو (Asian Session)';
    }
  }

  const todayStr = options.customDate || `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, '0')}-${String(now.getUTCDate()).padStart(2, '0')}`;

  // -------------------------------------------------------------
  // 1. ORIGINAL DYNAMIC BACKGROUND IMAGE (ALWAYS STUNNING COBALT/DEEP SPACE BLUE)
  // -------------------------------------------------------------
  // Solid cobalt blue gradient foundation (guarantees the background is NEVER white or transparent)
  const bgGrad = ctx.createLinearGradient(0, 0, width, height);
  bgGrad.addColorStop(0, '#020617'); // Midnight blue
  bgGrad.addColorStop(0.3, '#07162c'); // Premium cobalt blue
  bgGrad.addColorStop(0.7, '#0b2545'); // Deep royal blue
  bgGrad.addColorStop(1, '#010409'); // Dark space blue
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  try {
    const bgCandidatePaths = [
      path.join(process.cwd(), 'src', 'assets', 'images', 'deep_space_nebula_1790174744086.jpg'),
      path.join(process.cwd(), 'dist', 'assets', 'images', 'deep_space_nebula_1790174744086.jpg'),
      path.join(process.cwd(), 'public', 'assets', 'images', 'deep_space_nebula_1790174744086.jpg'),
      path.join(process.cwd(), '..', 'src', 'assets', 'images', 'deep_space_nebula_1790174744086.jpg'),
    ];

    let finalBgPath = '';
    for (const p of bgCandidatePaths) {
      if (fs.existsSync(p)) {
        finalBgPath = p;
        break;
      }
    }

    if (finalBgPath) {
      const imgBuffer = fs.readFileSync(finalBgPath);
      const bgImg = new Image();
      bgImg.src = imgBuffer;
      ctx.drawImage(bgImg, 0, 0, width, height);
    }
  } catch (err) {
    console.error('[chartCardRenderer] Failed to load blue space bg image:', err);
  }

  // Premium dark overlay for optimal image contrast (matching yesterday's style perfectly)
  ctx.fillStyle = 'rgba(15, 23, 42, 0.25)';
  ctx.fillRect(0, 0, width, height);

  // Outer Thin Red Frame Line
  ctx.strokeStyle = 'rgba(225, 29, 72, 0.4)';
  ctx.lineWidth = 2;
  ctx.strokeRect(16, 16, width - 32, height - 32);

  // -------------------------------------------------------------
  // 2. TOP HEADER HUD BAR (Pair Name, Timeframe Badge, Live Price ECN)
  // -------------------------------------------------------------
  const headY = 38;
  const headH = 82;
  ctx.fillStyle = 'rgba(12, 18, 34, 0.88)';
  ctx.fillRect(38, headY, width - 76, headH);
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(38, headY, width - 76, headH);

  // Green Dot + Pair Name
  ctx.fillStyle = '#10b981';
  ctx.beginPath(); ctx.arc(68, headY + headH / 2, 9, 0, Math.PI * 2); ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 38px NotoSansArabic, sans-serif';
  ctx.fillText(pairStr, 92, headY + 54);

  // Timeframe Badge (Smooth Rounded Pill)
  const tfBadgeX = 295;
  const tfBadgeY = headY + 18;
  const tfBadgeW = 78;
  const tfBadgeH = 46;
  ctx.fillStyle = '#4c1d95';
  ctx.beginPath();
  ctx.roundRect(tfBadgeX, tfBadgeY, tfBadgeW, tfBadgeH, 14);
  ctx.fill();
  ctx.strokeStyle = '#8b5cf6';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 22px NotoSansArabic, sans-serif';
  ctx.fillText(tfBadgeText, tfBadgeX + 18, tfBadgeY + 31);

  // Right Side: Live Price & ECN Tag
  ctx.fillStyle = '#cbd5e1';
  ctx.font = 'bold 15px NotoSansArabic, sans-serif';
  ctx.fillText('LIVE PRICE • ECN', width - 265, headY + 32);

  ctx.fillStyle = '#34d399';
  ctx.font = 'bold 34px monospace';
  ctx.fillText(priceStr, width - 265, headY + 66);

  // -------------------------------------------------------------
  // 3. SUBHEADER LINE (Date + Rocket Accuracy + Target Icon)
  // -------------------------------------------------------------
  const subY = 145;
  const subH = 44;
  const subBorderColor = isCall ? '#00a884' : '#f43f5e';
  ctx.strokeStyle = subBorderColor;
  ctx.lineWidth = 1.5;
  ctx.strokeRect(38, subY, width - 76, subH);

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 22px NotoSansArabic, sans-serif';
  ctx.textAlign = 'center';

  // Format accuracy text exactly like the screenshots (e.g., 2026-09-22 • SURESHOT ROCKET 90.5%)
  const subText = `${todayStr} • SURESHOT ROCKET ${confidenceStr}`;
  const textMetrics = ctx.measureText(subText);
  const textWidth = textMetrics.width;
  const totalWidth = textWidth + 30; // 30px for diamond icon + padding

  const startX = (width - totalWidth) / 2;
  const diamX = startX + 8;
  const textX = startX + 30 + textWidth / 2;

  // Diamond shape colored to match direction
  ctx.fillStyle = isCall ? '#00f5ab' : '#ff5a79';
  ctx.beginPath();
  ctx.moveTo(diamX, subY + 22);
  ctx.lineTo(diamX + 8, subY + 13);
  ctx.lineTo(diamX + 16, subY + 22);
  ctx.lineTo(diamX + 8, subY + 31);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.fillText(subText, textX, subY + 30);
  ctx.textAlign = 'left'; // Reset

  // -------------------------------------------------------------
  // 4. CENTER GRAPHIC (Original Solid Triangles matching Yesterday's screenshots)
  // -------------------------------------------------------------
  const triCx = width / 2;

  ctx.save();
  // Apply glowing drop shadow matching direction
  ctx.shadowColor = isCall ? 'rgba(0, 168, 132, 0.45)' : 'rgba(244, 63, 94, 0.45)';
  ctx.shadowBlur = 24;

  if (isCall) {
    // 🟩 CALL: Solid teal-green upward pointing triangle (Image 1 & Image 3)
    ctx.fillStyle = '#00a884';
    ctx.beginPath();
    ctx.moveTo(triCx, 200);
    ctx.lineTo(triCx + 240, 580);
    ctx.lineTo(triCx - 240, 580);
    ctx.closePath();
    ctx.fill();

    // 🟥 Inner Emblem: Solid red downward pointing triangle sits 100% COMPLETELY inside outer green triangle
    ctx.fillStyle = '#f43f5e';
    ctx.beginPath();
    ctx.moveTo(triCx, 475); // Bottom tip at y=475 (deep inside outer green triangle, well above y=580 base)
    ctx.lineTo(triCx + 95, 310); // Top right (75.5px inside outer green triangle left/right edges)
    ctx.lineTo(triCx - 95, 310); // Top left
    ctx.closePath();
    ctx.fill();
    
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.stroke();
  } else {
    // 🟥 PUT: Solid red downward pointing triangle
    ctx.fillStyle = '#f43f5e';
    ctx.beginPath();
    ctx.moveTo(triCx, 580);
    ctx.lineTo(triCx + 240, 200);
    ctx.lineTo(triCx - 240, 200);
    ctx.closePath();
    ctx.fill();

    // Inner triangle for PUT (Glowing neon-red or green outlined downward triangle completely inside)
    ctx.shadowColor = '#ff5a79';
    ctx.shadowBlur = 12;
    ctx.fillStyle = 'rgba(244, 63, 94, 0.25)';
    ctx.strokeStyle = '#ff5a79';
    ctx.lineWidth = 4;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(triCx, 450);
    ctx.lineTo(triCx + 115, 260);
    ctx.lineTo(triCx - 115, 260);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  ctx.restore();

  // -------------------------------------------------------------
  // 5. TIME CAPSULE PILL (e.g. 11:28:03)
  // -------------------------------------------------------------
  const timePillW = 204;
  const timePillH = 48;
  const timePillX = (width - timePillW) / 2;
  const timePillY = 556; // Centered exactly overlapping the bottom of the triangle base/vertex

  ctx.save();
  ctx.fillStyle = isCall ? '#00a884' : '#f43f5e';
  ctx.beginPath();
  ctx.roundRect(timePillX, timePillY, timePillW, timePillH, 24);
  ctx.fill();
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 28px NotoSansArabic, monospace';
  ctx.textAlign = 'center';
  ctx.fillText(cleanTime, width / 2, timePillY + 34);
  ctx.restore();

  // -------------------------------------------------------------
  // 6. MAIN SIGNAL CAPSULE (CALL / PUT)
  // -------------------------------------------------------------
  const mainCapY = 640;
  const mainCapH = 210;

  ctx.fillStyle = isCall ? 'rgba(6, 78, 59, 0.3)' : 'rgba(159, 18, 57, 0.3)';
  ctx.fillRect(38, mainCapY, width - 76, mainCapH);
  ctx.strokeStyle = isCall ? '#10b981' : '#f43f5e';
  ctx.lineWidth = 2.5;
  ctx.strokeRect(38, mainCapY, width - 76, mainCapH);

  // Main Text Line: ▲ CALL • صعود مؤكد (BUY)
  ctx.fillStyle = isCall ? '#34d399' : '#f43f5e';
  ctx.font = 'bold 38px NotoSansArabic, sans-serif';
  ctx.textAlign = 'center';
  const signalMainLabel = isCall
    ? '▲ CALL • صعود مؤكد (BUY)'
    : '▼ PUT • هبوط مؤكد (SELL)';
  ctx.fillText(signalMainLabel, width / 2, mainCapY + 54);

  // Sub-box 3 Columns inside Main Capsule
  const subBoxY = mainCapY + 78;
  const subBoxH = 110;
  ctx.strokeStyle = isCall ? '#10b981' : '#f43f5e';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(52, subBoxY, width - 104, subBoxH);

  // Divider lines
  const colW = (width - 104) / 3;
  ctx.beginPath();
  ctx.moveTo(52 + colW, subBoxY); ctx.lineTo(52 + colW, subBoxY + subBoxH);
  ctx.moveTo(52 + colW * 2, subBoxY); ctx.lineTo(52 + colW * 2, subBoxY + subBoxH);
  ctx.stroke();

  // Column Contents with Native Vector Shapes (Centered with beautiful colored boxes)
  ctx.font = 'bold 22px NotoSansArabic, sans-serif';
  ctx.textAlign = 'center';

  // Left Column (Index 0): Movement Text (Cleanly centered without square boxes)
  const col0CenterX = 52 + colW * 0.5;
  const movementText = isCall ? 'حركة صعودية قوية' : 'حركة هبوطية قوية';
  ctx.fillStyle = '#ffffff';
  ctx.fillText(movementText, col0CenterX, subBoxY + 60);

  // Middle Column (Index 1): Previous Outcome
  const col1CenterX = 52 + colW * 1.5;
  const rawOutcome = options.previousOutcome;
  const isLoss = rawOutcome === 'loss' || rawOutcome === 'khada' || rawOutcome === 'خاسرة';
  const outcomeText = isLoss ? 'السابقة: خاسرة (تم التحصين)' : 'السابقة: رابحة';
  ctx.fillStyle = isLoss ? '#ff5a79' : '#ffffff';
  ctx.fillText(outcomeText, col1CenterX, subBoxY + 60);

  // Right Column (Index 2): TDI Signal (Cleanly centered without icons or small shapes)
  const col2CenterX = 52 + colW * 2.5;
  const indicatorText = options.shortReason || 'TDI تقاطع خطوط';
  ctx.fillStyle = '#ffffff';
  ctx.fillText(indicatorText, col2CenterX, subBoxY + 60);

  ctx.textAlign = 'left'; // Reset

  // -------------------------------------------------------------
  // 7. PURPLE INTEGRATION CAPSULE
  // -------------------------------------------------------------
  const purpCapY = 930;
  const purpCapH = 82;
  ctx.fillStyle = 'rgba(88, 28, 135, 0.35)';
  ctx.fillRect(38, purpCapY, width - 76, purpCapH);
  ctx.strokeStyle = '#c084fc';
  ctx.lineWidth = 2;
  ctx.strokeRect(38, purpCapY, width - 76, purpCapH);

  ctx.fillStyle = '#f0abfc';
  ctx.font = 'bold 22px NotoSansArabic, sans-serif';
  ctx.textAlign = 'center';
  const integrationText = options.latestIntegration
    ? `✦ (Zero-Lag ECN) ${options.latestIntegration} • UTC رصد الرادار: ${radarTimeStr} ✦`
    : `✦ (Zero-Lag ECN) الدمج: إكسبيرت السكالبينج الكمي فائق السرعة • UTC رصد الرادار: ${radarTimeStr} ✦`;
  ctx.fillText(integrationText, width / 2, purpCapY + 50);

  // -------------------------------------------------------------
  // 8. BLUE SESSION & PAIR CAPSULE (Left: Session Name | Right: Active Base Pair)
  // -------------------------------------------------------------
  const blueCapY = 1042;
  const blueCapH = 82;
  ctx.fillStyle = 'rgba(12, 74, 110, 0.35)';
  ctx.fillRect(38, blueCapY, width - 76, blueCapH);
  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 2;
  ctx.strokeRect(38, blueCapY, width - 76, blueCapH);

  ctx.fillStyle = '#38bdf8';
  ctx.font = 'bold 24px NotoSansArabic, sans-serif';

  // Left aligned session name (e.g., London Session / NY Session)
  ctx.textAlign = 'left';
  ctx.fillText(sessionName, 70, blueCapY + 50);

  // Right aligned pair name
  ctx.textAlign = 'right';
  ctx.fillText(`${pairStr} :الزوج الذي يحترم التحليل`, width - 70, blueCapY + 50);
  ctx.textAlign = 'left'; // Reset

  // -------------------------------------------------------------
  // 9. FOOTER CREDITS & RULES
  // -------------------------------------------------------------
  const footY = 1280;
  ctx.fillStyle = '#cbd5e1';
  ctx.font = 'bold 22px NotoSansArabic, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('✦ No Martingale • 0-Repaint Fixed • Interbank ECN SMC ✦', width / 2, footY);

  ctx.fillStyle = 'rgba(148, 163, 184, 0.65)';
  ctx.font = 'bold 17px monospace';
  ctx.fillText('GOLDEN ROCKET SYSTEM • GRS LIVE CHART HUD • PURE LIVE MARKET', width / 2, footY + 44);

  // -------------------------------------------------------------
  // 10. PAYWALL OVERLAY (If user is not VIP / hasn't paid 520 stars)
  // -------------------------------------------------------------
  if (options.isPaywalled) {
    ctx.save();
    ctx.fillStyle = 'rgba(15, 23, 42, 0.94)';
    ctx.fillRect(38, 600, width - 76, 490);

    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 3;
    ctx.strokeRect(38, 600, width - 76, 490);

    // Lock Icon
    ctx.fillStyle = '#fbbf24';
    ctx.beginPath(); ctx.arc(width / 2, 740, 38, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(width / 2 - 13, 730, 26, 30);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 32px NotoSansArabic, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('🔒 إشارة مشفرة - فلتر الحماية نشط', width / 2, 835);

    ctx.fillStyle = '#fde047';
    ctx.font = 'bold 24px NotoSansArabic, sans-serif';
    ctx.fillText(`ادفع ${options.starsPrice || 520} نجمة تيليجرام لفتح كافة صور الإشارات الحية لمدة يوم كامل`, width / 2, 885);
    ctx.restore();
  }

  // Convert Canvas to Buffer
  if (canvas.toBuffer) {
    return canvas.toBuffer('image/png');
  }

  return Buffer.from([]);
}
