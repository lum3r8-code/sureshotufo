const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const routes = `
app.get('/api/radio-stream', (req, res) => {
  const streamUrl = req.query.url;
  if (!streamUrl) return res.status(400).send('URL required');
  res.redirect(streamUrl);
});

app.get('/api/radio-metadata', async (req, res) => {
  try {
    // Return empty for now as proper icy-metadata parsing requires streams
    res.json({ title: "" });
  } catch (err) {
    res.json({ title: "" });
  }
});

// Start full-stack Express + Vite integration
`;

code = code.replace('// Start full-stack Express + Vite integration', routes);
fs.writeFileSync('server.ts', code);
