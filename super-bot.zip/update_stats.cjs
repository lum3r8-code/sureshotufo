const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

// Function 1: trackAutomaticCandleOutcome
code = code.replace(/if \(\!pairFeedbackRegistry\[regKey\]\) \{\s+const initPatch = GENIUS_VULNERABILITY_CATALOG\[0\];\s+pairFeedbackRegistry\[regKey\] = \{[\s\S]*?\}\s+return;\s+\}\s+const stats = pairFeedbackRegistry\[regKey\];/m, `const stats = getFeedbackStats(regKey);
  if (stats.lastCandleMinute === undefined) {
    stats.lastCandleMinute = currentCandlePeriod;
    stats.candleOpenPrice = candleOpenP ?? currentPrice;
    stats.candleDirection = currentDirection;
    stats.lastDiagnosis = \`النظام مستقر على فريم \${timeframe}m ويعمل بأعلى كفاءة مؤسسية\`;
    if (!tradeLogsRegistry[regKey]) {
      tradeLogsRegistry[regKey] = [
        { id: 'init-1', timestamp: now - 120000, outcome: 'win', direction: currentDirection, diagnosis: 'تحليل دقيق للسيولة (Real Sureshot - No MTG)', correction: 'تثبيت المعاملات' },
        { id: 'init-2', timestamp: now - 60000, outcome: 'win', direction: currentDirection, diagnosis: 'تأكيد إغلاق الشمعة بدون إعادة رسم (No Repaint)', correction: 'تعديل طفيف للأوزان' }
      ];
    }
    return;
  }`);

// Function 2: /api/binary/simulate-candle-close
code = code.replace(/if \(\!pairFeedbackRegistry\[regKey\]\) \{\s+const initPatch = GENIUS_VULNERABILITY_CATALOG\[0\];\s+pairFeedbackRegistry\[regKey\] = \{[\s\S]*?\}\s+\}\s+const stats = pairFeedbackRegistry\[regKey\];/m, `const stats = getFeedbackStats(regKey);`);

// Function 3: /api/binary/feedback
code = code.replace(/if \(\!pairFeedbackRegistry\[regKey\]\) \{\s+const initPatch = GENIUS_VULNERABILITY_CATALOG\[0\];\s+pairFeedbackRegistry\[regKey\] = \{[\s\S]*?\}\s+\}\s+const stats = pairFeedbackRegistry\[regKey\];/m, `const stats = getFeedbackStats(regKey);`);

// Function 4: /api/binary/audit
code = code.replace(/if \(\!pairFeedbackRegistry\[regKey\]\) \{\s+pairFeedbackRegistry\[regKey\] = \{[\s\S]*?\}\s+\}\s+const stats = pairFeedbackRegistry\[regKey\];/m, `const stats = getFeedbackStats(regKey);`);

// Function 5: setInterval
code = code.replace(/if \(\!pairFeedbackRegistry\[regKey\]\) \{\s+const initPatch = GENIUS_VULNERABILITY_CATALOG\[0\];\s+pairFeedbackRegistry\[regKey\] = \{[\s\S]*?\}\s+\}\s+const stats = pairFeedbackRegistry\[regKey\];/m, `const stats = getFeedbackStats(regKey);`);

// Function 6: app.get('/api/binary/feedback/:pairId/:timeframe?'
code = code.replace(/if \(\!pairFeedbackRegistry\[regKey\]\) \{\s+pairFeedbackRegistry\[regKey\] = \{[\s\S]*?\}\s+\}\s+const stats = pairFeedbackRegistry\[regKey\];/m, `const stats = getFeedbackStats(regKey);`);

fs.writeFileSync('server.ts', code);
