#!/bin/bash
# Quantum Engine & OSINT Telegram Bot - VPS Deployment Script (Ubuntu/Debian)
# Run this as root or with sudo

echo "🚀 Starting Deployment Process for Sureshot Quantum Bot..."

# 1. Update and install prerequisites
echo "📦 Updating system packages..."
sudo apt update && sudo apt upgrade -y
sudo apt install curl git build-essential -y

# 2. Install Node.js (LTS version) if not installed
if ! command -v node &> /dev/null
then
    echo "🟢 Installing Node.js 20.x..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
else
    echo "✅ Node.js is already installed."
fi

# 3. Install PM2 globally for 24/7 daemon process management
if ! command -v pm2 &> /dev/null
then
    echo "🔥 Installing PM2 (Process Manager)..."
    sudo npm install -g pm2
else
    echo "✅ PM2 is already installed."
fi

# 4. Install project dependencies
echo "📚 Installing project dependencies..."
npm install

# 5. Build the project (Vite frontend + Express/Typescript backend)
echo "🏗️ Building the application..."
npm run build

# 6. Stop any existing PM2 process for this app to update it
echo "🛑 Stopping old instances..."
pm2 stop quantum-bot 2>/dev/null || true
pm2 delete quantum-bot 2>/dev/null || true

# 7. Start the backend/bot server with PM2
echo "🚀 Starting the Quantum Bot via PM2..."
PORT=3000 pm2 start dist/server.cjs --name "quantum-bot" --time

# 8. Save PM2 state to restart on server reboot
echo "💾 Saving PM2 state for auto-restart on boot..."
pm2 save
# Generate startup script and run it (optional, may require manual root execution if not root)
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME 2>/dev/null || true

echo "✅ ==================================================="
echo "✅ DEPLOYMENT COMPLETE!"
echo "✅ The bot, Quantum Engine, and OSINT Scraper are now running 24/7."
echo "✅ To view live bot logs, run: pm2 logs quantum-bot"
echo "✅ ==================================================="
