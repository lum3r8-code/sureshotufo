const fs = require('fs');

const file = 'src/components/SignalDetailsModal.tsx';
let appFile = fs.readFileSync(file, 'utf8');

appFile = appFile.replace(
  /2\. سبب الإشارة والتحليل الفني المؤسسي/g,
  '2. سبب إشارة SURESHOT ROCKET والتحليل الفني'
);

appFile = appFile.replace(
  /الملخص الفني المباشر لسبب صدور الإشارة:/g,
  'الملخص الفني لسبب صدور الإشارة SURESHOT ROCKET:'
);

appFile = appFile.replace(
  /الإشارة محصنة ومناسبة فقط إذا تجاوزت/g,
  'إشارة SURESHOT ROCKET محصنة ومناسبة فقط إذا تجاوزت'
);

appFile = appFile.replace(
  /التأكد من مطابقتها لاتجاه الإشارة/g,
  'التأكد من مطابقتها لاتجاه إشارة SURESHOT ROCKET'
);

appFile = appFile.replace(
  /إشارة مؤمنة بالكامل: لا إعادة رسم/g,
  'إشارة SURESHOT ROCKET مؤمنة بالكامل: لا إعادة رسم'
);

appFile = appFile.replace(
  /نسخ تفاصيل الإشارة/g,
  'نسخ إشارة SURESHOT ROCKET'
);

appFile = appFile.replace(
  /نسخ ملخص الإشارة وتوقيت الدخول للحافظة/g,
  'نسخ ملخص إشارة SURESHOT ROCKET'
);

fs.writeFileSync(file, appFile, 'utf8');
console.log('patched modal ui');
