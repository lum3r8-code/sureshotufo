const fs = require('fs');

let server = fs.readFileSync('server.ts', 'utf8');

server = server.replace(/app\.get\('\/api\/intel\/live-innovations', \(req, res\) => {([\s\S]*?)const updatedInnovations/m, `app.get('/api/intel/live-innovations', (req, res) => {
  const now = new Date();
  
  const formatDate = (date) => {
    return date.toLocaleString('ar-EG', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  };

  const getOffsetDate = (mins) => {
    return new Date(now.getTime() - mins * 60000);
  };

  const timeLabels = [
    \`\${formatDate(now)} (الآن - مباشر عبر النفق)\`,
    \`\${formatDate(getOffsetDate(1))} (منذ دقيقة)\`,
    \`\${formatDate(getOffsetDate(2))} (منذ دقيقتين)\`,
    \`\${formatDate(getOffsetDate(4))} (منذ 4 دقائق)\`,
    \`\${formatDate(getOffsetDate(7))} (منذ 7 دقائق)\`,
    \`\${formatDate(getOffsetDate(12))} (منذ 12 دقيقة)\`,
    \`\${formatDate(getOffsetDate(18))} (منذ 18 دقيقة)\`,
    \`\${formatDate(getOffsetDate(25))} (منذ 25 دقيقة)\`,
    \`\${formatDate(getOffsetDate(34))} (منذ 34 دقيقة)\`,
    \`\${formatDate(getOffsetDate(45))} (منذ 45 دقيقة)\`
  ];
  const updatedInnovations`);

fs.writeFileSync('server.ts', server);
console.log('Fixed server.ts');
