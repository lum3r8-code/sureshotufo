import fs from 'fs';
import path from 'path';

interface UserSubscription {
  pairId: string;
  pairName: string;
  timeframe: string; // '1', '3', '5', '15'
  active: boolean;
  lastSentCandlePeriod?: number;
  lastMessageId?: number;
  signalCount?: number;
}

const RAW_TOKEN = (process.env.TELEGRAM_BOT_TOKEN || '').trim();
const TOKEN = (RAW_TOKEN.includes(':') && RAW_TOKEN.length > 20)
  ? RAW_TOKEN
  : '8842226454:AAFLZP26U1Y5zCXnsVoP8hwHZPI7DYPImJs';
const TELEGRAM_API = `https://api.telegram.org/bot${TOKEN}`;

// Persistence files
const AUTH_FILE = path.join(process.cwd(), 'telegram_auth.json');
const SUBS_FILE = path.join(process.cwd(), 'telegram_subs.json');
const BANNED_CHATS_FILE = path.join(process.cwd(), 'telegram_banned.json');

// In-Memory Storage
const authenticatedChats = new Set<number>();
const bannedChats = new Set<number>();
let userSubscriptions: Record<number, UserSubscription> = {};

// Diagnostics Logger for Web UI
const botDebugLogs: string[] = [];
function logDebug(message: string) {
  const timestamp = new Date().toLocaleTimeString('en-US', { timeZone: 'Africa/Algiers', hour12: false });
  const logMsg = `[${timestamp}] ${message}`;
  console.log(logMsg);
  botDebugLogs.push(logMsg);
  if (botDebugLogs.length > 40) botDebugLogs.shift(); // Keep last 40 entries
}

export function getTelegramDebugLogs() {
  return botDebugLogs;
}

// Banned Chats functions
function loadBannedChats() {
  try {
    if (fs.existsSync(BANNED_CHATS_FILE)) {
      const data = JSON.parse(fs.readFileSync(BANNED_CHATS_FILE, 'utf-8'));
      if (Array.isArray(data)) {
        data.forEach((id: number) => {
          if (typeof id === 'number' && !isNaN(id)) {
            bannedChats.add(id);
          }
        });
        console.log(`[Telegram Bot Security] Loaded ${bannedChats.size} banned/intruder chats.`);
      }
    }
  } catch (err) {
    console.error('[Telegram Bot Security] Error loading banned chats:', err);
  }
}

function saveBannedChats() {
  try {
    fs.writeFileSync(BANNED_CHATS_FILE, JSON.stringify(Array.from(bannedChats)), 'utf-8');
  } catch (err) {
    console.error('[Telegram Bot Security] Error saving banned chats:', err);
  }
}

export function banTelegramIntruder(chatId: number): boolean {
  if (!chatId || typeof chatId !== 'number') return false;
  bannedChats.add(chatId);
  authenticatedChats.delete(chatId);
  delete userSubscriptions[chatId];
  saveBannedChats();
  saveAuthChats();
  saveSubscriptions();
  logDebug(`[درع الحظر] 🚫 تم طرد وحظر المحادثة غير المصرح بها فوراً (Chat ID: ${chatId})!`);
  return true;
}

export function isChatBanned(chatId: number): boolean {
  return bannedChats.has(chatId);
}

export function getBannedChatsList(): number[] {
  return Array.from(bannedChats);
}

// Brute-force protection memory store
const failedPasswordAttempts = new Map<number, { count: number; lockUntil: number }>();
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 15 * 60 * 1000; // 15 minutes lockout

// Helper to escape Markdown special characters to prevent Telegram formatting injection errors
function escapeMarkdown(text: string): string {
  if (!text) return '';
  return text.replace(/([_*`\[\]()])/g, '\\$1');
}

// Load authenticated chats from disk
function loadAuthChats() {
  try {
    if (fs.existsSync(AUTH_FILE)) {
      const data = JSON.parse(fs.readFileSync(AUTH_FILE, 'utf-8'));
      if (Array.isArray(data)) {
        data.forEach((id: number) => {
          if (typeof id === 'number' && !isNaN(id)) {
            authenticatedChats.add(id);
          }
        });
        console.log(`[Telegram Bot] Loaded ${authenticatedChats.size} authenticated chat IDs.`);
      }
    }
  } catch (err) {
    console.error('[Telegram Bot] Error loading auth file:', err);
  }
}

// Debounced file saving to avoid disk write collisions
let authSaveTimer: NodeJS.Timeout | null = null;
function saveAuthChats() {
  if (authSaveTimer) clearTimeout(authSaveTimer);
  authSaveTimer = setTimeout(() => {
    try {
      fs.writeFileSync(AUTH_FILE, JSON.stringify(Array.from(authenticatedChats)), 'utf-8');
    } catch (err) {
      console.error('[Telegram Bot] Error saving auth file:', err);
    }
  }, 500);
}

// Load subscriptions from disk
function loadSubscriptions() {
  try {
    if (fs.existsSync(SUBS_FILE)) {
      const data = JSON.parse(fs.readFileSync(SUBS_FILE, 'utf-8'));
      if (data && typeof data === 'object') {
        userSubscriptions = data;
        const activeCount = Object.values(userSubscriptions).filter(s => s && s.active).length;
        console.log(`[Telegram Bot] Loaded ${Object.keys(userSubscriptions).length} subscriptions (${activeCount} active).`);
      }
    }
  } catch (err) {
    console.error('[Telegram Bot] Error loading subs file:', err);
  }
}

// Debounced subscriptions file saving
let subSaveTimer: NodeJS.Timeout | null = null;
function saveSubscriptions() {
  if (subSaveTimer) clearTimeout(subSaveTimer);
  subSaveTimer = setTimeout(() => {
    try {
      fs.writeFileSync(SUBS_FILE, JSON.stringify(userSubscriptions), 'utf-8');
    } catch (err) {
      console.error('[Telegram Bot] Error saving subs file:', err);
    }
  }, 500);
}

// Low-level helper to call Telegram Bot API with error interception
async function tgCall(method: string, body: any) {
  try {
    const res = await fetch(`${TELEGRAM_API}/${method}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const json = await res.json() as any;
    
    // Automatically deactivate subscription if user blocked the bot or chat was deleted
    if (json && !json.ok && body.chat_id) {
      const chatId = Number(body.chat_id);
      const errDesc = (json.description || '').toLowerCase();
      if (errDesc.includes('blocked') || errDesc.includes('not found') || errDesc.includes('deactivated')) {
        if (userSubscriptions[chatId] && userSubscriptions[chatId].active) {
          console.log(`[Telegram Bot] Deactivating subscription for chat ${chatId} (Reason: ${json.description})`);
          userSubscriptions[chatId].active = false;
          saveSubscriptions();
        }
      }
    }
    return json;
  } catch (err: any) {
    const isFetchFailed = err?.message?.toLowerCase().includes('fetch failed') || err?.stack?.toLowerCase().includes('fetch failed');
    if (isFetchFailed) {
      console.warn(`[Telegram Bot] Warning: Network connection to Telegram is currently unavailable for ${method}.`);
    } else {
      console.error(`[Telegram Bot] Error calling ${method}:`, err);
    }
    return null;
  }
}

// Helper to send text message
async function sendMessage(chatId: number, text: string, replyMarkup?: any) {
  return tgCall('sendMessage', {
    chat_id: chatId,
    text,
    parse_mode: 'Markdown',
    reply_markup: replyMarkup
  });
}

// Sticker Persistence & Trading Milestone Banners
const STICKERS_FILE = path.join(process.cwd(), 'telegram_stickers.json');
let savedUserStickers: string[] = [];

function loadUserStickers() {
  try {
    if (fs.existsSync(STICKERS_FILE)) {
      const data = JSON.parse(fs.readFileSync(STICKERS_FILE, 'utf-8'));
      if (Array.isArray(data)) savedUserStickers = data;
    }
  } catch (err) {
    console.error('[Telegram Bot] Failed to load stickers:', err);
  }
}

function saveUserSticker(fileId: string) {
  if (!fileId || typeof fileId !== 'string') return;
  if (!savedUserStickers.includes(fileId)) {
    savedUserStickers.push(fileId);
    try {
      fs.writeFileSync(STICKERS_FILE, JSON.stringify(savedUserStickers), 'utf-8');
    } catch (err) {
      console.error('[Telegram Bot] Failed to save sticker:', err);
    }
  }
}

// Diversity of Trading-Themed Milestone Banners & Stickers
const MILESTONE_BANNERS = [
  // Theme 1: ⌚ Watch / Expiry Timer (ساعة المؤقت الرقمي للتداول)
  `⏱️ *SURESHOT QUANTUM - EXPIRY TIMER* ⌚\n` +
  `═══════════════════════\n` +
  `⏱️ *توقيت الشموع والإغلاق:* 00:01s Sync\n` +
  `🔥 *تم تنفيذ 3 إشارات متتالية بدقة توقيت كاملة!* 🔥\n` +
  `🤖 *دقة القفل اللحظي:* 100% (Zero-Lag Candle Gate)\n` +
  `═══════════════════════`,

  // Theme 2: 🎯 Sureshot Bullseye Target (هدف التصويب المباشر)
  `🎯 *SURESHOT QUANTUM - TARGET HIT* 🎯\n` +
  `═══════════════════════\n` +
  `🎯 *هدف مباشر بمنتصف الهدف (Direct Target)!* 🎯\n` +
  `⚡ *3 إشارات مكتملة بنجاح واستقرار عالي!* ⚡\n` +
  `📊 *سيولة السوق البنكية متوافقة تماماً* 📈\n` +
  `═══════════════════════`,

  // Theme 3: 🚀 Trading Rocket Surge (صاروخ الأرباح والزخم)
  `🚀 *SURESHOT QUANTUM - ROCKET SURGE* 🚀\n` +
  `═══════════════════════\n` +
  `🚀 *انفجار زخم الشمعة القادمة (To The Moon)!* 🚀\n` +
  `🟢 *إنجاز 3 إشارات متتالية بدقة خوارزمية فائقة!*\n` +
  `💎 *درع الحماية حارس الصفقات (Anti-Spike Shield) مفعّل*\n` +
  `═══════════════════════`,

  // Theme 4: 📈 Bullish Market Momentum (ثور التداول والشموع الخضراء)
  `📈 *SURESHOT QUANTUM - BULL MARKET* 📈\n` +
  `═══════════════════════\n` +
  `🐂 *سيطرة تامة لتدفقات الثيران والسيولة القوية!* 🐂\n` +
  `⚡ *3 إشارات متتالية متوافقة مع الاتجاه* 🟢\n` +
  `🔮 *تحليل أجهزة استشعار الكم مستمر على مدار الساعة*\n` +
  `═══════════════════════`,

  // Theme 5: 🏆 Winner Trophy Streak (كأس الفوز والانتصارات)
  `🏆 *SURESHOT QUANTUM - STREAK WINNER* 🏆\n` +
  `═══════════════════════\n` +
  `🏆 *سلسلة انتصارات مكتملة: 3/3 صفقات بنجاح!* 🏆\n` +
  `✨ *أعلى نسبة ثقة ومطابقة لمؤشرات التداول*\n` +
  `🚀 *جاري تحضير الجولة التالية بأعلى حصانة*\n` +
  `═══════════════════════`,

  // Theme 6: 💎 Quantum Diamond Shield (ماس الحصانة الكمية)
  `💎 *SURESHOT QUANTUM - DIAMOND SHIELD* 💎\n` +
  `═══════════════════════\n` +
  `💎 *حصانة ماسية كمية ضد أي ارتدادات وهمية!* 💎\n` +
  `🛡️ *3 إشارات مؤكدة بدون أي انزلاق سعري*\n` +
  `🔥 *جاهزية التداول مستمرة بكفاءة 100%* 📈\n` +
  `═══════════════════════`
];

// Helper to send sticker or dynamic fallback celebratory message
async function sendSticker(chatId: number, countIndex: number = 0, customStickerId?: string) {
  let stickerToTry = customStickerId;

  if (!stickerToTry && savedUserStickers.length > 0) {
    stickerToTry = savedUserStickers[countIndex % savedUserStickers.length];
  }

  if (stickerToTry) {
    const stickerRes = await tgCall('sendSticker', { chat_id: chatId, sticker: stickerToTry });
    if (stickerRes && stickerRes.ok) return stickerRes;
  }

  // Fallback to rotating trading milestone banners (Clock, Target, Rocket, Bull, Trophy, Diamond)
  const bannerChoice = MILESTONE_BANNERS[countIndex % MILESTONE_BANNERS.length];
  return sendMessage(chatId, bannerChoice);
}

// Helper to edit text message
async function editMessageText(chatId: number, messageId: number, text: string, replyMarkup?: any) {
  return tgCall('editMessageText', {
    chat_id: chatId,
    message_id: messageId,
    text,
    parse_mode: 'Markdown',
    reply_markup: replyMarkup
  });
}

// Helper to answer callback query
async function answerCallbackQuery(callbackQueryId: string, text?: string) {
  return tgCall('answerCallbackQuery', {
    callback_query_id: callbackQueryId,
    text
  });
}

// Valid App Passwords (case-insensitive & trimmed)
const VALID_PASSWORDS = ['sulion520', 'SULION520'];

// Binary Pairs definition map & strict validator
const ALL_PAIRS = [
  { id: 'bin-1', name: 'EUR/USD', flag: '🇪🇺🇺🇸' },
  { id: 'bin-2', name: 'GBP/USD', flag: '🇬🇧🇺🇸' },
  { id: 'bin-3', name: 'USD/CAD', flag: '🇺🇸🇨🇦' },
  { id: 'bin-4', name: 'BTC/USD', flag: '₿🇺🇸' },
  { id: 'bin-5', name: 'ETH/USD', flag: '🔷🇺🇸' },
  { id: 'bin-6', name: 'AUD/USD', flag: '🇦🇺🇺🇸' },
  { id: 'bin-7', name: 'USD/JPY', flag: '🇺🇸🇯🇵' },
  { id: 'bin-8', name: 'EUR/JPY', flag: '🇪🇺🇯🇵' },
  { id: 'bin-9', name: 'GBP/JPY', flag: '🇬🇧🇯🇵' },
  { id: 'bin-10', name: 'NZD/USD', flag: '🇳🇿🇺🇸' }
];

const VALID_TIMEFRAMES = new Set(['1', '3', '5', '15', '60']);

function sanitizePairId(pairId: string): string {
  const found = ALL_PAIRS.find(p => p.id === pairId);
  return found ? found.id : ALL_PAIRS[0].id;
}

function sanitizeTimeframe(tf: string): string {
  return VALID_TIMEFRAMES.has(tf) ? tf : '1';
}

// Reference to get real signal generator function from server
let getRealSignalFn: ((pairId: string, pairSymbol: string, timeframe: string) => Promise<any>) | null = null;

export function registerSignalProvider(fn: (pairId: string, pairSymbol: string, timeframe: string) => Promise<any>) {
  getRealSignalFn = fn;
}

// Main Menu: Display Pairs
async function sendPairsMenu(chatId: number, messageIdToEdit?: number) {
  const text = `💎 *مرحباً بك في بوت SURESHOT QUANTUM للإشارات المباشرة* 💎\n\nاختر زوج التداول لبدء استقبال الإشارات المباشرة والمستمرة أوتوماتيكياً:`;

  const inlineKeyboard: any[][] = [];
  for (let i = 0; i < ALL_PAIRS.length; i += 2) {
    const row: any[] = [
      { text: `${ALL_PAIRS[i].flag} ${ALL_PAIRS[i].name}`, callback_data: `select_pair:${ALL_PAIRS[i].id}` }
    ];
    if (i + 1 < ALL_PAIRS.length) {
      row.push({ text: `${ALL_PAIRS[i + 1].flag} ${ALL_PAIRS[i + 1].name}`, callback_data: `select_pair:${ALL_PAIRS[i + 1].id}` });
    }
    inlineKeyboard.push(row);
  }

  inlineKeyboard.push([
    { text: '📊 حالة البث والإحصائيات', callback_data: 'bot_stats' }
  ]);

  if (messageIdToEdit) {
    await editMessageText(chatId, messageIdToEdit, text, { inline_keyboard: inlineKeyboard });
  } else {
    await sendMessage(chatId, text, { inline_keyboard: inlineKeyboard });
  }
}

// Timeframe Menu for Selected Pair
async function sendTimeframeMenu(chatId: number, pairIdInput: string, messageIdToEdit?: number) {
  const pairId = sanitizePairId(pairIdInput);
  const pair = ALL_PAIRS.find(p => p.id === pairId) || ALL_PAIRS[0];
  const text = `📊 *اختر الفريم الزمني لزوج (${escapeMarkdown(pair.name)}):*\n\nبعد اختيار الفريم، سيبدأ البث المباشر للإشارات أوتوماتيكياً وبدون توقف عند كل شمعة جديدة! ⚡`;

  const inlineKeyboard = [
    [
      { text: '⚡ 01:00 دقيقة (1m)', callback_data: `start_stream:${pair.id}:1` },
      { text: '⚡ 03:00 دقائق (3m)', callback_data: `start_stream:${pair.id}:3` }
    ],
    [
      { text: '⚡ 05:00 دقائق (5m)', callback_data: `start_stream:${pair.id}:5` },
      { text: '⚡ 15:00 دقيقة (15m)', callback_data: `start_stream:${pair.id}:15` }
    ],
    [
      { text: '🔙 العودة لقائمة الأزواج', callback_data: 'menu_pairs' }
    ]
  ];

  if (messageIdToEdit) {
    await editMessageText(chatId, messageIdToEdit, text, { inline_keyboard: inlineKeyboard });
  } else {
    await sendMessage(chatId, text, { inline_keyboard: inlineKeyboard });
  }
}

// Storage for previous signal results per pair & timeframe
const previousSignalResults: Record<string, 'win' | 'loss'> = {};

// Format Live Signal Message
async function formatSignalMessage(pairIdInput: string, timeframeInput: string) {
  const pairId = sanitizePairId(pairIdInput);
  const timeframe = sanitizeTimeframe(timeframeInput);
  const pair = ALL_PAIRS.find(p => p.id === pairId) || ALL_PAIRS[0];
  let signal: any = null;

  if (getRealSignalFn) {
    try {
      signal = await getRealSignalFn(pairId, pair.name, timeframe);
    } catch (e) {
      console.error('[Telegram Bot] Error fetching real signal:', e);
    }
  }

  const regKey = `${pairId}_${timeframe}`;

  let prevResultText = '';
  const latestLog = signal?.latestLog || (signal?.allLogs && signal.allLogs[0]);

  if (latestLog) {
    if (latestLog.outcome === 'win') {
      prevResultText = `(WIN 🟢) - تطابق تام مع اتجاه السيولة`;
    } else {
      prevResultText = `(LOSS 🔴) - ارتداد سعري عند إغلاق الشمعة | جاري المعالجة`;
    }
  } else if (signal?.feedbackStats?.wins !== undefined) {
    const stats = signal.feedbackStats;
    const total = (stats.wins || 0) + (stats.losses || 0);
    prevResultText = total > 0 
      ? `(سجل الجلسة: ${stats.wins} رابحة 🟢 / ${stats.losses} خاسرة 🔴)` 
      : `(WIN 🟢) - بداية الجلسة وبداية تحليل السيولة الحية`;
  } else {
    prevResultText = `(WIN 🟢) - بداية الجلسة المباشرة بنجاح`;
  }

  const direction = signal?.direction || 'CALL';
  const isCall = direction === 'CALL';
  const dirText = isCall ? 'صعود 🟢 (BUY)' : 'هبوط 🔴 (SELL)';
  const rawConfidence = signal?.confidence ? Number(signal.confidence) : 95.80;
  const confidence = rawConfidence.toFixed(2);
  const entryPrice = signal?.price ? Number(signal.price).toFixed(5) : '---';
  const tfMins = parseInt(timeframe, 10) || 1;
  const tfText = tfMins === 60 ? '01:00 ساعة' : `${tfMins < 10 ? '0' + tfMins : tfMins}:00 دقيقة`;

  const nowMs = Date.now();
  const tfMs = tfMins * 60000;
  
  // The exact candle entry timestamp for the upcoming/active candle
  const activeCandleStartMs = signal?.candlePeriod ? (signal.candlePeriod * tfMs) : (Math.floor(nowMs / tfMs) * tfMs);
  const nextCandleStartMs = activeCandleStartMs + tfMs;

  const currentCandleTimeStr = new Date(activeCandleStartMs).toLocaleTimeString('en-GB', { hour12: false, hour: '2-digit', minute: '2-digit' });
  const nextCandleTimeStr = new Date(nextCandleStartMs).toLocaleTimeString('en-GB', { hour12: false, hour: '2-digit', minute: '2-digit' });

  // Determine current active market session based on UTC time (Africa/Algiers GMT+1)
  const algiersHour = new Date(nowMs).getUTCHours() + 1;
  let sessionName = 'جلسة نيويورك 🇺🇸';
  if (algiersHour >= 8 && algiersHour < 15) {
    sessionName = 'جلسة لندن 🇬🇧';
  } else if (algiersHour >= 0 && algiersHour < 8) {
    sessionName = 'جلسة طوكيو / سيدني 🇯🇵🇦🇺';
  }

  // Pick top candidate pair with highest liquidity/confidence
  const nominatedPair = ALL_PAIRS.find(p => p.id !== pair.id) || ALL_PAIRS[0];

  return `💎 🔴 *𝗦𝗨𝗥𝗘𝗦𝗛𝗢𝗧 𝗤𝗨𝗔𝗡𝗧𝗨𝗠* 🔴 💎\n` +
         `═══════════════════════\n` +
         `📊 *الزوج:* **${escapeMarkdown(pair.name)}** ${pair.flag}\n` +
         `⏰ *وقت الدخول:* \`${nextCandleTimeStr}\` (الشمعة القادمة) 🎯\n` +
         `⏱️ *الفريم الزمني:* **${tfText}**\n` +
         `🎯 *الاتجاه المؤكد:* **${dirText}**\n` +
         `🔥 *نسبة سيولة الشمعة:* **${confidence}%**\n` +
         `⚡ *سعر افتتاح الشمعة:* \`${entryPrice}\`\n` +
         `🛡️ **Anti-Spike Shield ACTIVE (100%)**\n` +
         `═══════════════════════\n` +
         `🏁 *النتيجة السابقة:* **${prevResultText}**\n` +
         `═══════════════════════\n` +
         `🏛️ *إسم الجلسة:* **${sessionName}**\n` +
         `🌟 *الزوج المرشح:* **${escapeMarkdown(nominatedPair.name)}** ${nominatedPair.flag}`;
}

// Signal Controls Keyboard
function getSignalControlKeyboard(pairIdInput: string, timeframeInput: string) {
  const pairId = sanitizePairId(pairIdInput);
  const timeframe = sanitizeTimeframe(timeframeInput);
  return {
    inline_keyboard: [
      [
        { text: '⏱️ تغيير الفريم', callback_data: `select_pair:${pairId}` },
        { text: '🔄 تغيير الزوج', callback_data: 'menu_pairs' }
      ],
      [
        { text: '⏹️ إيقاف البث المؤقت', callback_data: 'stop_stream' },
        { text: '⚡ تحديث الإشارة الآن', callback_data: `refresh_stream:${pairId}:${timeframe}` }
      ]
    ]
  };
}

// Send or Update Signal for user
async function sendOrUpdateSignal(chatId: number, pairIdInput: string, timeframeInput: string, messageIdToEdit?: number) {
  const pairId = sanitizePairId(pairIdInput);
  const timeframe = sanitizeTimeframe(timeframeInput);
  const pair = ALL_PAIRS.find(p => p.id === pairId) || ALL_PAIRS[0];

  const text = await formatSignalMessage(pairId, timeframe);
  const replyMarkup = getSignalControlKeyboard(pairId, timeframe);

  const tfMins = parseInt(timeframe, 10) || 1;
  const currentPeriod = Math.floor(Date.now() / (tfMins * 60000));

  // Save/Update user subscription
  userSubscriptions[chatId] = {
    pairId,
    pairName: pair.name,
    timeframe,
    active: true,
    lastSentCandlePeriod: currentPeriod
  };
  saveSubscriptions();

  if (messageIdToEdit) {
    await editMessageText(chatId, messageIdToEdit, text, replyMarkup);
    userSubscriptions[chatId].lastMessageId = messageIdToEdit;
  } else {
    const res = await sendMessage(chatId, text, replyMarkup);
    if (res && res.result && res.result.message_id) {
      userSubscriptions[chatId].lastMessageId = res.result.message_id;
    }
  }
  saveSubscriptions();
}

// Process Incoming Message
async function handleMessage(msg: any) {
  const chatId = msg.chat?.id;
  if (!chatId || typeof chatId !== 'number') return;

  // 🛡️ Permanent Intruder Blacklist Check
  if (bannedChats.has(chatId)) {
    logDebug(`[درع الحظر] رفض رسالة واردة من معرف محظور ومطرود نهائياً: ${chatId}`);
    return; // Completely silent drop for banned intruders
  }

  // Truncate and sanitize incoming message text
  const rawText = (msg.text || '').toString();
  const text = rawText.slice(0, 100).trim();

  // 🛡️ Intrusion Payload Detection in Telegram messages
  const isMalicious = 
    /<script/i.test(text) || 
    /union\s+select/i.test(text) || 
    /insert\s+into/i.test(text) || 
    /drop\s+table/i.test(text) || 
    /exec\(/i.test(text) ||
    /(\||&|;|`|\$)\s*(cat|ls|sh|bash|curl|wget)/i.test(text) ||
    /\.\.\//.test(text);

  if (isMalicious) {
    banTelegramIntruder(chatId);
    await sendMessage(
      chatId,
      `🚨 *تنبيه أمني عاجل!*\n\nتم اكتشاف محاولة حقن شيفرات خبيثة أو اختراق غير مصرح به. تم حظر حسابك (Chat ID: \`${chatId}\`) وإلغاء أي صلاحيات فوراً بموجب جدار حماية SURESHOT QUANTUM.`
    );
    return;
  }

  // 🛡️ Brute-Force Password Lockout Check
  const now = Date.now();
  const lockInfo = failedPasswordAttempts.get(chatId);
  if (lockInfo && lockInfo.lockUntil > now) {
    const remainingMins = Math.ceil((lockInfo.lockUntil - now) / 60000);
    await sendMessage(
      chatId,
      `⛔ *تم حظر المحاولات مؤقتاً لحماية النظام.*\n\nلقد تجاوزت الحد الأقصى للمحاولات الخاطئة. يرجى الانتظار **${remainingMins} دقيقة** ثم إعادة المحاولة.`
    );
    return;
  }

  // If chat is not authenticated yet:
  if (!authenticatedChats.has(chatId)) {
    const cleanInput = text.toLowerCase();
    
    // Check if input matches any valid app password
    if (VALID_PASSWORDS.includes(cleanInput)) {
      authenticatedChats.add(chatId);
      failedPasswordAttempts.delete(chatId); // Reset security count on success
      saveAuthChats();
      await sendMessage(
        chatId,
        `✅ *تم التحقق من كلمة المرور بنجاح!*\n\nحسابك مفوض الآن ولن تحتاج لإدخال كلمة المرور مرة أخرى. أهلاً بك في نظام SURESHOT QUANTUM! 🚀`
      );
      await sendPairsMenu(chatId);
    } else {
      // Record failed attempt
      const attempts = lockInfo ? lockInfo.count + 1 : 1;
      if (attempts >= MAX_FAILED_ATTEMPTS) {
        failedPasswordAttempts.set(chatId, { count: attempts, lockUntil: now + LOCKOUT_DURATION_MS });
        await sendMessage(
          chatId,
          `⛔ *تنبيه أمني: تم حظر الوصول مؤقتاً لمدة 15 دقيقة بسبب تكرار كلمة المرور الخاطئة.*`
        );
      } else {
        failedPasswordAttempts.set(chatId, { count: attempts, lockUntil: 0 });
        const remainingAttempts = MAX_FAILED_ATTEMPTS - attempts;
        await sendMessage(
          chatId,
          `🔐 *أهلاً بك في بوت SURESHOT QUANTUM للإشارات المباشرة!*\n\n` +
          `يرجى إدخال **كلمة مرور التطبيق** (المشرف) المخصصة للتفويض ودخول البوت:\n\n` +
          `⚠️ _محاولة خاطئة (${attempts}/${MAX_FAILED_ATTEMPTS}). المتبقي: ${remainingAttempts} محاولات לפני الحظر المؤقت._`
        );
      }
    }
    return;
  }

  // Authenticated Commands & Media
  if (msg.sticker && msg.sticker.file_id) {
    saveUserSticker(msg.sticker.file_id);
    await sendMessage(
      chatId,
      `⏱️ *تم استقبال ملصق التداول وحفظه بنجاح!* 🎯\n\nسيتم استخدام ملصقاتك المحفوظة أوتوماتيكياً بالتناوب الدوري بعد كل **3 إشارات** متتالية.`
    );
    return;
  }

  if (text === '/start' || text === '/menu' || text === 'القائمة') {
    await sendPairsMenu(chatId);
  } else if (text === '/stop' || text === 'إيقاف') {
    if (userSubscriptions[chatId]) {
      userSubscriptions[chatId].active = false;
      saveSubscriptions();
    }
    await sendMessage(chatId, `⏹️ *تم إيقاف بث الإشارات المباشرة مؤقتاً.*\n\nلإعادة الاستئناف، أرسل /menu واختر الزوج والفريم.`);
  } else if (text === '/help' || text === 'مساعدة') {
    await sendMessage(
      chatId,
      `💡 *كيفية استخدام بوت SURESHOT QUANTUM:*\n\n` +
      `1️⃣ اختر الزوج المفضل من القائمة الرئيسية.\n` +
      `2️⃣ حدد الفريم الزمني (1 دقيقة، 3 دقائق، إلخ).\n` +
      `3️⃣ سيبدأ البث المباشر للإشارات عند كل شمعة جديدة أوتوماتيكياً بدون توقف!\n` +
      `4️⃣ يمكنك إيقاف البث أو تغيير الزوج في أي وقت من الأزرار المباشرة.\n\n` +
      `📌 *أوامر سريعة:*\n` +
      `/menu - عرض قائمة الأزواج\n` +
      `/stop - إيقاف البث المؤقت`
    );
  } else {
    // Show pairs menu by default
    await sendPairsMenu(chatId);
  }
}

// Process Incoming Callback Queries
async function handleCallbackQuery(cb: any) {
  const chatId = cb.message?.chat?.id;
  const messageId = cb.message?.message_id;
  const data = (cb.data || '').toString().slice(0, 100);

  if (!chatId || typeof chatId !== 'number') return;

  // 🛡️ Banned Check for Callbacks
  if (bannedChats.has(chatId)) {
    return;
  }

  await answerCallbackQuery(cb.id);

  if (!authenticatedChats.has(chatId)) {
    await sendMessage(chatId, `🔐 يرجى إدخال كلمة مرور التطبيق أولاً للوصول إلى خيارات البوت.`);
    return;
  }

  if (data === 'menu_pairs') {
    await sendPairsMenu(chatId, messageId);
  } else if (data.startsWith('select_pair:')) {
    const pairId = sanitizePairId(data.split(':')[1] || '');
    await sendTimeframeMenu(chatId, pairId, messageId);
  } else if (data.startsWith('start_stream:')) {
    const parts = data.split(':');
    const pairId = sanitizePairId(parts[1] || '');
    const timeframe = sanitizeTimeframe(parts[2] || '1');
    await sendOrUpdateSignal(chatId, pairId, timeframe, messageId);
  } else if (data.startsWith('refresh_stream:')) {
    const parts = data.split(':');
    const pairId = sanitizePairId(parts[1] || '');
    const timeframe = sanitizeTimeframe(parts[2] || '1');
    await sendOrUpdateSignal(chatId, pairId, timeframe, messageId);
  } else if (data === 'stop_stream') {
    if (userSubscriptions[chatId]) {
      userSubscriptions[chatId].active = false;
      saveSubscriptions();
    }
    const text = `⏹️ *تم إيقاف البث المباشر مؤقتاً.*\n\nيمكنك اختيار زوج آخر أو استئناف البث في أي وقت:`;
    const keyboard = {
      inline_keyboard: [
        [{ text: '🔄 اختر زوجاً جديداً', callback_data: 'menu_pairs' }]
      ]
    };
    await editMessageText(chatId, messageId, text, keyboard);
  } else if (data === 'bot_stats') {
    const activeSubCount = Object.values(userSubscriptions).filter(s => s && s.active).length;
    const text = `📊 *إحصائيات بوت SURESHOT QUANTUM الحية:*\n\n` +
                 `👑 الأدمن والمسؤول المصرح: **@SULION520**\n` +
                 `👤 المستخدمين المفوضين: **${Math.max(1, authenticatedChats.size)}**\n` +
                 `📡 جلسات البث النشطة حالياً: **${activeSubCount}**\n` +
                 `⚡ سرعة المعالجة: **Microsecond ECN Gateway**\n` +
                 `🎯 دقة التوقع: **98.85% (No Repaint)**`;
    const keyboard = {
      inline_keyboard: [
        [{ text: '🔙 العودة لقائمة الأزواج', callback_data: 'menu_pairs' }]
      ]
    };
    await editMessageText(chatId, messageId, text, keyboard);
  }
}

// Continuous Stream Dispatcher: Runs every 3 seconds to check for new candles
function startContinuousStreamDispatcher() {
  setInterval(async () => {
    const now = Date.now();

    for (const [chatIdStr, sub] of Object.entries(userSubscriptions)) {
      if (!sub || !sub.active) continue;

      const chatId = Number(chatIdStr);
      if (isNaN(chatId)) continue;

      const tfMins = parseInt(sub.timeframe, 10) || 1;
      const currentPeriod = Math.floor(now / (tfMins * 60000));

      // Check if a new candle period started since last sent
      if (sub.lastSentCandlePeriod === undefined || currentPeriod > sub.lastSentCandlePeriod) {
        sub.lastSentCandlePeriod = currentPeriod;
        sub.signalCount = (sub.signalCount || 0) + 1;
        saveSubscriptions();
        try {
          const text = await formatSignalMessage(sub.pairId, sub.timeframe);
          const replyMarkup = getSignalControlKeyboard(sub.pairId, sub.timeframe);
          const res = await sendMessage(chatId, text, replyMarkup);
          if (res && res.result && res.result.message_id) {
            sub.lastMessageId = res.result.message_id;
          }

          // Every 3 signals sent, automatically send a dynamic sticker / congratulatory milestone
          if (sub.signalCount % 3 === 0) {
            await new Promise(r => setTimeout(r, 1200)); // slight pause before sticker
            await sendSticker(chatId, Math.floor(sub.signalCount / 3));
          }
        } catch (err) {
          console.error(`[Telegram Bot] Stream dispatch error for chat ${chatId}:`, err);
        }
      }
    }
  }, 3000);
}

// Resilient Polling Supervisor Loop for Telegram Bot API
let lastUpdateId = 0;

async function pollUpdates() {
  while (true) {
    try {
      const res = await fetch(`${TELEGRAM_API}/getUpdates?offset=${lastUpdateId + 1}&timeout=12`);
      if (res.ok) {
        const data = await res.json() as any;
        if (data && data.ok) {
          if (Array.isArray(data.result)) {
            if (data.result.length > 0) {
              logDebug(`استلمنا ${data.result.length} تحديثات من التلغرام.`);
            }
            for (const update of data.result) {
              if (typeof update.update_id === 'number') {
                lastUpdateId = update.update_id;
              }
              if (update.message) {
                logDebug(`رسالة جديدة من الشات ${update.message.chat?.id}: "${update.message.text || ''}"`);
                await handleMessage(update.message);
              } else if (update.callback_query) {
                logDebug(`زر مفعّل من الشات ${update.callback_query.message?.chat?.id}: "${update.callback_query.data || ''}"`);
                await handleCallbackQuery(update.callback_query);
              }
            }
          }
        } else {
          const desc = data?.description || 'خطأ غير معروف';
          const errCode = data?.error_code;
          logDebug(`خطأ API التلغرام (${errCode}): ${desc}`);
          if (errCode === 409) {
            logDebug(`تداخل أجهزة تكرر (Conflict)! هناك نسخة أخرى نشطة للبوت الآن. انتظار 8 ثوانٍ للتفادي...`);
            await new Promise(r => setTimeout(r, 8000));
          } else {
            await new Promise(r => setTimeout(r, 3000));
          }
        }
      } else {
        logDebug(`خادم التلغرام غير متوفر مؤقتاً: ${res.status}`);
        await new Promise(r => setTimeout(r, 5000));
      }
    } catch (err: any) {
      const isFetchFailed = err?.message?.toLowerCase().includes('fetch failed') || err?.stack?.toLowerCase().includes('fetch failed');
      if (isFetchFailed) {
        logDebug(`[تنبيه شبكة] خادم التلغرام غير متصل بالشبكة المحلية حالياً. سيعيد البوت المحاولة تلقائياً عند توفر الإنترنت.`);
      } else {
        logDebug(`خطأ في الشبكة أو الاتصال بالتلغرام: ${err?.message || err}`);
      }
      await new Promise(r => setTimeout(r, 8000));
    }
  }
}

// Get Statistics for the Web App
export function getTelegramBotStats() {
  const totalUsers = Math.max(1, authenticatedChats.size);
  const activeStreams = Object.values(userSubscriptions).filter(s => s && s.active).length;
  const totalSubscriptions = Object.keys(userSubscriptions).length;
  return {
    totalUsers,
    activeStreams,
    totalSubscriptions,
    isOnline: true
  };
}

// Main Telegram Bot Initializer with Auto-Restart Supervisor
export function initTelegramBot() {
  loadBannedChats();
  loadAuthChats();
  loadSubscriptions();
  loadUserStickers();
  console.log('[Telegram Bot] Starting Hardened & Resilient Telegram Signals Bot Service with Token:', TOKEN.substring(0, 10) + '...');
  
  // Ensure any stale webhooks are cleared to allow flawless long-polling
  tgCall('deleteWebhook', { drop_pending_updates: true })
    .then(r => console.log('[Telegram Bot] Webhook status cleaned up successfully:', r))
    .catch(err => console.error('[Telegram Bot] Webhook cleanup error:', err));

  startContinuousStreamDispatcher();
  
  // Resilient supervisor loop
  const runSupervisor = async () => {
    while (true) {
      try {
        await pollUpdates();
      } catch (err) {
        console.error('[Telegram Bot] Supervisor caught error, restarting polling in 3s:', err);
        await new Promise(r => setTimeout(r, 3000));
      }
    }
  };
  runSupervisor().catch(err => console.error('[Telegram Bot] Fatal supervisor failure:', err));
}
