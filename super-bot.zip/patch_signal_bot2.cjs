const fs = require('fs');

const file = 'src/services/telegramBot.ts';
let appFile = fs.readFileSync(file, 'utf8');

appFile = appFile.replace(
  /\`إشارة مشكوك فيها - ممنوع الدخول\`/g,
  '\`إشارة غير صالحة ❌ SURESHOT ROCKET\`'
);

appFile = appFile.replace(
  /تحديث الإشارة الآن/g,
  'تحديث إشارة SURESHOT ROCKET'
);

appFile = appFile.replace(
  /بدء تدفق الإشارات الآن/g,
  'بدء تدفق إشارات SURESHOT ROCKET'
);

appFile = appFile.replace(
  /أول إشارة/g,
  'أول إشارة لـ SURESHOT ROCKET'
);

fs.writeFileSync(file, appFile, 'utf8');

const file2 = 'server.ts';
let serverFile = fs.readFileSync(file2, 'utf8');

serverFile = serverFile.replace(
  /إشارة اختبارية/g,
  'إشارة SURESHOT ROCKET اختبارية'
);

serverFile = serverFile.replace(
  /إشارة الاختبار/g,
  'إشارة SURESHOT ROCKET الاختبارية'
);

serverFile = serverFile.replace(
  /إشارة تحكيم فورية/g,
  'إشارة SURESHOT ROCKET فورية'
);

serverFile = serverFile.replace(
  /توجيه الإشارة إلى/g,
  'توجيه إشارة SURESHOT ROCKET إلى'
);

serverFile = serverFile.replace(
  /تثبيط أي إشارة/g,
  'تثبيط أي إشارة لـ SURESHOT ROCKET'
);

serverFile = serverFile.replace(
  /إشارة مؤكدة مطابقة/g,
  'إشارة SURESHOT ROCKET مؤكدة ومطابقة'
);

serverFile = serverFile.replace(
  /تسجيل إشارة صحيحة/g,
  'تسجيل إشارة SURESHOT ROCKET صحيحة'
);

serverFile = serverFile.replace(
  /تسجيل إشارة خاطئة/g,
  'تسجيل إشارة SURESHOT ROCKET خاطئة'
);

serverFile = serverFile.replace(
  /توليد إشارة تعزيز قوية/g,
  'توليد إشارة SURESHOT ROCKET لتعزيز قوي'
);

serverFile = serverFile.replace(
  /عدم تغيير الإشارة/g,
  'عدم تغيير إشارة SURESHOT ROCKET'
);

serverFile = serverFile.replace(
  /يعطي إشارة ارتداد/g,
  'يعطي إشارة SURESHOT ROCKET بالارتداد'
);

serverFile = serverFile.replace(
  /الإشارة الأساسية/g,
  'إشارة SURESHOT ROCKET الأساسية'
);

fs.writeFileSync(file2, serverFile, 'utf8');
console.log('patched all signals again');
