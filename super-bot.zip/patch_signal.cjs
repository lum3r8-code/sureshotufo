const fs = require('fs');

const file = 'src/services/telegramBot.ts';
let appFile = fs.readFileSync(file, 'utf8');

appFile = appFile.replace(
  /\`قيد المراقبة اللحظية ⏳ \(أول إشارة على فريم \$\{tfText\} \- بانتظار إغلاق الشمعة لتسجيل النتيجة الحقيقية\)\`/g,
  '\`قيد المراقبة اللحظية ⏳ (أول إشارة لـ SURESHOT ROCKET على فريم ${tfText} - بانتظار إغلاق الشمعة)\`'
);

appFile = appFile.replace(
  /\`إشارة مشكوك فيها \- ممنوع الدخول\`/g,
  '\`إشارة غير صالحة ❌ SURESHOT ROCKET\`'
);

appFile = appFile.replace(
  /⚡ الإشارة القادمة ستصلك فور افتتاح الشمعة الجديدة مباشرة\./g,
  '⚡ إشارة SURESHOT ROCKET القادمة ستصلك فور الافتتاح المباشر.'
);

appFile = appFile.replace(
  /⚡ طلب إشارة فورية الآن/g,
  '⚡ طلب إشارة SURESHOT ROCKET'
);

appFile = appFile.replace(
  /\/signal \- طلب إشارة تحليلية حية وفورية/g,
  '/signal - طلب إشارة SURESHOT ROCKET حية وفورية'
);

fs.writeFileSync(file, appFile, 'utf8');
console.log('patched bot signals');
