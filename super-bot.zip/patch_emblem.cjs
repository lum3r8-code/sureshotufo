const fs = require('fs');

const appFile = fs.readFileSync('src/App.tsx', 'utf8');

const newSvg = `<svg
        viewBox="0 0 512 512"
        className={\`\${dim} relative z-10 overflow-visible drop-shadow-[0_4px_16px_rgba(225,29,72,0.45)]\`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <radialGradient id="rubyTargetRed" cx="38%" cy="32%" r="68%">
            <stop offset="0%" stopColor="#ff4d79" />
            <stop offset="35%" stopColor="#f43f5e" />
            <stop offset="70%" stopColor="#be123c" />
            <stop offset="100%" stopColor="#880825" />
          </radialGradient>
          <linearGradient id="pearlWhiteRing" x1="20%" y1="20%" x2="80%" y2="80%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="50%" stopColor="#fff1f2" />
            <stop offset="100%" stopColor="#ffe4e6" />
          </linearGradient>
          <linearGradient id="rocketBodyGrad" x1="20%" y1="20%" x2="80%" y2="80%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="50%" stopColor="#e2e8f0" />
            <stop offset="100%" stopColor="#94a3b8" />
          </linearGradient>
          <linearGradient id="thrusterGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#94a3b8" />
            <stop offset="50%" stopColor="#475569" />
            <stop offset="100%" stopColor="#1e293b" />
          </linearGradient>
          <linearGradient id="flameGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="40%" stopColor="#f97316" />
            <stop offset="100%" stopColor="#ef4444" />
          </linearGradient>
        </defs>

        <g transform="rotate(45 256 256)">
          <path d="M 220 430 Q 256 550 292 430 Q 256 460 220 430 Z" fill="url(#flameGrad)" />
          <path d="M 192 280 L 100 400 L 192 400 Z" fill="url(#rubyTargetRed)" stroke="#0f172a" strokeWidth="16" strokeLinejoin="round" />
          <path d="M 320 280 L 412 400 L 320 400 Z" fill="url(#rubyTargetRed)" stroke="#0f172a" strokeWidth="16" strokeLinejoin="round" />
          <path d="M 215 400 L 297 400 L 305 430 L 207 430 Z" fill="url(#thrusterGrad)" stroke="#0f172a" strokeWidth="16" strokeLinejoin="round" />
          <path d="M 256 50 C 340 130, 340 250, 320 400 L 192 400 C 172 250, 172 130, 256 50 Z" fill="url(#rocketBodyGrad)" stroke="#0f172a" strokeWidth="16" strokeLinejoin="round" />
          <path d="M 256 50 C 310 100, 316 130, 314 150 Q 256 180 198 150 C 196 130, 202 100, 256 50 Z" fill="url(#rubyTargetRed)" />
          <path d="M 198 150 Q 256 180 314 150" fill="none" stroke="#0f172a" strokeWidth="16" strokeLinecap="round" />
          <g transform="translate(0, -10)">
            <circle cx="256" cy="270" r="50" fill="url(#rubyTargetRed)" stroke="#0f172a" strokeWidth="14" />
            <circle cx="256" cy="270" r="32" fill="url(#pearlWhiteRing)" stroke="#0f172a" strokeWidth="14" />
            <circle cx="256" cy="270" r="14" fill="url(#rubyTargetRed)" stroke="#0f172a" strokeWidth="14" />
          </g>
        </g>
      </svg>`;

const startTag = '<svg\n        viewBox="0 0 512 512"';
const endTag = '      </svg>';

const startIndex = appFile.indexOf(startTag);
const endIndex = appFile.indexOf(endTag, startIndex) + endTag.length;

if (startIndex !== -1 && endIndex !== -1) {
    const updatedFile = appFile.substring(0, startIndex) + newSvg + appFile.substring(endIndex);
    fs.writeFileSync('src/App.tsx', updatedFile, 'utf8');
    console.log('Successfully updated App.tsx with the rocket SVG');
} else {
    console.log('Could not find SVG in App.tsx');
}
