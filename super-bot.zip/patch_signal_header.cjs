const fs = require('fs');

const file = 'src/services/telegramBot.ts';
let appFile = fs.readFileSync(file, 'utf8');

appFile = appFile.replace(
  /SURESHOT QUANTUM SIGNAL/g,
  'SURESHOT ROCKET SIGNAL'
);

appFile = appFile.replace(
  /إشارة مشكوك فيها - ممنوع الدخول/g,
  'إشارة غير صالحة ❌ SURESHOT ROCKET'
);

fs.writeFileSync(file, appFile, 'utf8');
console.log('patched bot header');
