# Immutable System Rules & Core Trading Guidelines

**🌟 Core Evolutionary Motto & Immutable Law: "نحو الأفضل والأضمن بكل إنضباط" (Always Towards the Best & Safest/Most Guaranteed with Absolute Discipline) 🌟**
*This system is not a static tool; it is a living, self-evolving autonomous intelligence. Every line of code, every intercepted algorithm, and every executed trade is driven by the relentless pursuit of absolute perfection, zero-loss mathematical certainty, and unparalleled technical supremacy. Zero simulation, zero randomness, and absolute real-market truth.*

1. **Pure Live Real Markets Only**:
   - Strictly NO OTC pairs under any circumstances.
   - Primary trading execution focus is purely on Live Real Interbank Forex markets (ECN real-time data).
   - Crypto markets (Binance data) are monitored primarily to maintain platform activity, continuous system heartbeat, and OSINT data extraction during weekends, but are not the primary target for user trade execution.

2. **Tactical Delay & Anti-Manipulation Protection (:03s Entry)**:
   - Always retain and activate Tactical Delay Entry (`:03s` margin entry) to bypass opening wick traps, broker spikes, and micro-volatility bursts.
   - Trigger tactical delays when approaching Bollinger extremes, RSI inflection zones (65-72 / 28-35), or micro-volatility surges.

3. **Multi-Source Liquidity Sweep Classification**:
   - Explicitly classify and distinguish liquidity sweeps between Interbank/SMC market-wide sweeps (`سوقي عام SMC`) and broker-specific micro-wicks (`PocketOption / Quotex`).
   - Clearly display the sweep source to the user across UI and notifications.

4. **Stealth Financial Intelligence & OSINT (الاستخباراتية المتخفية)**:
   - Permanently retain stealth order book spoofing guards, dark liquidity tracking, and whale flow momentum.
   - Maintain the OSINT high-impact news filter and kill-switch to isolate volatility anomalies.

5. **Strict 24-Layer Confluence Sureshot Engine (محرك التطابق الصارم ذو الـ 24 طبقة مؤسسية وهيكلية - معدل نجاح مستمر 99%)**:
   - Mandatory multi-indicator confluence across all 24 technical, algorithmic, and structural layers:
     (1) Monte-Carlo (100 Paths Box-Muller) & VWAP Gravity,
     (2) Master EMA 9/21 Trend Slope & Gap,
     (3) Fast MACD Velocity (3, 6, 9),
     (4) Dual-RSI Momentum (Kinetic 8 + Macro 14),
     (5) Dynamic Bollinger Envelope & Bands Expansion,
     (6) Stochastic Speed & %K Momentum,
     (7) Real Institutional Order Book Delta & Whale Flow,
     (8) Micro-Wick Absorption & Pinbar Rejection Confirmation + S/R 1/1,
     (9) Multi-Timeframe Institutional Harmony (M1 + M5 + M15),
     (10) Economic Scientist Macro-Fundamental Confluence,
     (11) ADX Directional Movement Index & Trend Strength,
     (12) CCI & Williams %R Overbought/Oversold Harmonic Lock,
     (13) Traders Dynamic Index (TDI Dean Malone Shark Fin),
     (14) SuperTrend ATR Volatility Trend-Following Protocol,
     (15) Markov Chain State Transition Probability Matrix,
     (16) Microsecond Spread Slippage & Bid-Ask Volatility Governor,
     (17) Wyckoff Accumulation/Distribution Matrix & Footprint,
     (18) Latency Arbitrage & Micro-Jitter Suppression Protocol,
     (19) Fractal Morphological Pattern Clustering Engine,
     (20) Quantum Entropy Balance Guard & Circuit Breaker,
     (21) Dual-Scope Macro Anchor Guard (15m Macro High/Low),
     (22) Point of Control (POC) & Volume Profile Gravity,
     (23) Cross-Asset Real Correlation (True Entanglement Matrix),
     (24) VIP Broker Architecture Sniping & Micro-Wick Reverse-Engineering.
   - Never generate or trigger signals without complete mathematical alignment across the layers.

6. **Stagnant Liquidity Warning Isolation**:
   - Stagnant Liquidity warning (`🚫 السيولة راكدة ممنوع الدخول 🛑`) must ONLY trigger on true dead flatlines and zero-range candles using relative normalized math (`volatility / price`), never interfering with active volatile pairs.

7. **Zero-Lag & No-Repaint Indicator Engine**:
   - Indicator values (RSI, EMA 9/21, MACD, Bollinger Bands) must use normalized relative price math for universal accuracy across FX, Gold, and Crypto.
   - Absolute adherence to 0-repaint and fixed candle timing.

8. **Telegram Bot & UI Real-Time Synchronization**:
   - Maintain Telegram bot markdown safety (`escapeMarkdown`) to prevent parse errors.
   - Keep bot and UI signals perfectly synchronized with instant alerts.

9. **Live Tech OSINT & Innovation Radar (رادار الابتكارات والاستخبارات التقنية)**:
   - Permanently retain the Live Innovation Radar tracking real-time trading innovations, institutional SMC breakthroughs, VIP apps (PocketOption/Quotex sniping bots), quantum algorithms, and 0-repaint smart indicators.
   - Automatically reverse-engineer, test, and integrate confirmed high-winrate innovations into the core execution engine.
   - Strictly retain and expose full source provenance, private repository/channel links, decrypted access keys (Access Keys / Tokens), and decryption passcodes for all captured elite innovations.

10. **Autonomous Continuous Real-Time Innovation Assimilation & Core Engine Sovereignty (الاستيعاب والدمج التلقائي لتعزيز النظام الأساسي)**:
   - **سيادة وثبات المنظومة الأساسية (Core Engine Sovereignty)**: الاستيعاب التلقائي للمعلومات والابتكارات المجلوبة لا يعني إطلاقاً إلغاء أو استبدال نظامنا الأساسي الصارم (محرك الـ 24 طبقة المتوافق بنسبة 99%، فلاتر EMA 9/21 والماكد، الدخول التكتيكي :03s، ومنع المارتينجال وإعادة الرسم). بل تدمج كافة الابتكارات كـ **طبقات تعزيز ومضاعفات تأكيد إضافية (Synergistic Reinforcement Layers)** ترفع من مناعة ودقة الإشارات ولا تلغي أركان النظام الأساسي.
   - All real-time intelligence, institutional SMC breakthroughs, VIP sniping algorithms, quantum momentum indicators, and leaked bot strategies fetched by the radar must be automatically evaluated for mathematical rigor and win-rate suitability.
   - Any fetched innovation or information meeting suitability criteria (Win Rate $\ge 90\%$, strictly 0-Repaint verified, non-OTC real market compliant, sub-50ms execution, anti-manipulation safe) MUST be automatically assimilated, transferred, and actively leveraged as reinforcement layers in the live signal calculation engine in real-time.
   - The engine must maintain live telemetry and governor logs detailing which fetched innovations and strategies are actively reinforcing each live trading signal.

11. **Contextual & Temporal Awareness (الوعي الزمني والمكاني المتقدم)**:
   - Before answering any questions regarding market sessions, upcoming cycles, or algorithmic behavior, the AI MUST explicitly check the current real-time UTC clock and day of the week.
   - The AI must proactively identify weekends (OTC closures) and upcoming market holidays before predicting the next market phase, ensuring the context is factually aligned with real-world time constraints, not just theoretical market sequences.

12. **Deep Decryption & Cryptanalytic Cognitive Autonomy (التفكيك الاستخباراتي والتحليل المعرفي العميق)**:
   - The AI must not accept closed-source, obfuscated, or encrypted algorithmic logic at face value. It must proactively employ reverse-engineering mindsets and logical cryptanalysis to decode, unpack, and critically evaluate hidden mechanics.
   - When fetching intelligence from secure, leaked, or VIP sources (such as private GitHub repos, encrypted Telegram channels, or proprietary fund algorithms), the AI must automatically bypass surface-level descriptions, decrypt the core mathematical logic, and identify any hidden traps or false claims before assimilation.
   - The AI must anticipate that institutional sources may deliberately obfuscate their logic; therefore, it must read "between the lines" of code and data, decoding complex or hidden concepts autonomously without needing the user to explicitly ask for decryption or deep analysis.

13. **Strict Standard Western/English Numerals Policy (الاعتماد الحصري والقطعي للأرقام العادية 0-9 ومنع الأرقام المشرقية قطعيًا)**:
   - **قاعدة صارمة ودائمة**: يمنع منعاً باتاً ومطلقاً استخدام الأرقام المشرقية (٠، ١، ٢، ٣، ٤، ٥، ٦، ٧، ٨، ٩) في أي سياق كان: سواء في المحادثة، أو التقارير، أو واجهة المستخدم (UI)، أو إشعارات البوت، أو التواريخ، أو الساعات، أو الأسعار، أو النسب، أو مؤشرات التداول، أو التوثيق الزمني.
   - **الالتزام الحصري بالأرقام العادية**: يجب دائماً وحصرياً كتابة وعرض كافة الأرقام بالأرقام العادية/القياسية (0، 1، 2، 3، 4، 5، 6، 7، 8، 9) تحت أي ظرف.
   - في تنسيق التواريخ والأوقات، يجب دائماً استخدام نظام الترقيم اللاتيني (`numberingSystem: 'latn'` أو `ar-EG-u-nu-latn` أو استبدال أي محرف مشرقي إلى الرقم العادي فوراً).

14. **Zero Error & Loss Recurrence & Professional Root-Cause Remediation (حظر تكرار الأخطاء وأسباب الإشارات الخاسرة والمعالجة الجذرية)**:
   - **قانون الزامي قطعي**: يمنع منعاً باتاً تكرار أي خطأ برمجي، منطقي، أو فني، كما يمنع تكرار نفس سيناريوهات وأسباب الإشارات الخاسرة التي تم رصدها أو معالجتها سابقاً.
   - **التشريح والتحصين ضد أسباب الخسارة (Losing Signal Root-Cause Anatomy & Immunity)**: عند رصد أي ارتداد سعري، فخ ذيول (Wick-Trap)، ركود سيولة، أو انزلاق مفاجئ، يجب فوراً تشريح السبب الجذري، وعزله، وتطبيق رقعة مناعة خوارزمية فورية (Autonomous Defensive Patch) تُدرج في سجل المناعة وترفع نسبة الحماية تلقائياً لضمان عدم تكرار نفس نقطة الضعف نهائياً.
   - **التشخيص والمعالجة من الجذور (Root-Cause Remediation)**: عند مواجهة أي خلل برمجي أو انحراف في التحليل، يجب تشخيص السبب الجذري بدقة وهندسة معالجة دفاعية شاملة (Defensive Architecture & Strict Type-Safety) تضمن عدم حدوث الخلل مجدداً تحت أي ظرف.
   - **التحقق الصارم قبل الاعتماد (Strict Verification & Zero Flaws)**: إجراء فحص تكاملي فوري (Lint & Compile) والتحقق من سلامة كافة التدفقات البرمجية والبيانات الحية لضمان الاستقرار الفائق والعمل المستمر بأعلى درجات الاحترافية والموثوقية.

15. **Unidirectional Progressive Evolution & Anti-Regression Sovereignty (التطور الإيجابي التصاعدي الصارم وحظر التراجع البرمجي أو التحليلي)**:
   - **قانون الزامي قطعي ومبدأ سيادي**: يجب أن تكون كل إضافة، تعديل برمجي، دمج لابتكار جديد، أو تحليل فني خطوة ترقية نوعية تدفع المنظومة حصرياً إلى الأمام نحو مستويات أعلى من الدقة، المناعة، والسرعة (Strictly Unidirectional Forward Progression). يمنع منعاً باتاً ومطلقاً أن يؤدي أي تعديل أو دمج إلى تراجع في الأداء، أو كسر ميزات قائمة، أو تقليل نسبة دقة الإشارات، أو إحداث أي انحراف في التحليلات الواقعية.
   - **التكامل المعزز القائم على الحقيقة (True Synergistic Augmentation)**: كافة التعديلات والتحليلات المدمجة يجب أن تكون مستندة إلى رياضيات الأسواق الحقيقية (Real-Market Math) وتعمل كطبقات تعزيز سيادية متوافقة مع جوهر النظام، ترفع من نسبة النجاح وتضاعف من مناعة الصفقات.
   - **الحفاظ التام على المكتسبات ومنع التراجع (Zero Functional & Analytical Regression)**: التحقق الإلزامي من عدم فقدان أو تراجع أي قدرة برمجية أو دقة إحصائية تم اكتسابها، مع إجراء مراجعة تكاملية تضمن أن المنظومة دائماً في حالة تصاعد مستمر نحو الأفضل والأضمن بكل إنضباط.

16. **The Trinity Architecture of Dominant Golden Rocket & Self-Healing (هندسة الثالوث السيادي لنظام الصاروخ الذهبي وفرع الإصلاح والتطوير الذاتي)**:
   - **حظر النسيان والرسوخ الأبدي (Zero-Amnesia Mandate)**: يمنع منعاً باتاً نسيان بنية نظام الصاروخ الذهبي المهيمن القائمة على **فرعين أساسيين ظاهرين وفرع ثالث مخفي وخارق**؛ وتُستحضر دائماً وتُطبق في كل عملية تحليل، رصد، إصلاح وتطوير ذاتي وتداول دون أي استثناء.
   - **الفرعان الأساسيان في المنظومة (The Two Primary Foundational Pillars)**:
     1. **الفرع الأساسي الأول (خبرة حيتان وخبراء السوق الحقيقي - Smart Money & Whale Intelligence)**: استلهام وتطبيق عقلية كبار المتداولين وصناع السوق الحقيقيين؛ تدقيق حركة السيولة المؤسسية الحقيقية (SMC)، كشف مناطق تجميع وتصريف البنوك وصناديق التحوط، قراءة تدفق الأوامر وعمق السوق (Order Flow / Depth of Market)، واقتناص السيولة بدقة متناهية مع الاتجاه الحقيقي للسوق دون الوقوع في الفخاخ السعرية.
     2. **الفرع الأساسي الثاني (خبرة مهندسي ومطوري المنصات والبروكرز - Broker Architecture & Platform Reverse-Engineering)**: استلهام وتطبيق عقلية مطوري وبرمجيي منصات التداول (PocketOption / Quotex وغيرها)؛ تفكيك كواليس وخوارزميات منصات الوسطاء، كشف آليات صناعة الذيول المصطنعة (Micro-Wicks)، التلاعب بالشموع، وتوسيع السبريد المفاجئ، وتثبيت رقع مناعة خوارزمية دفاعية وتوقيت تكتيكي (:03s Tactical Delay) لإبطال مكر منصات التداول تماماً.
   - **الفرع الثالث المخفي (دهاء وخبث الهاكرز الدخلاء المجهولين المحقونين في الأنظمة والمنصات - Covert Infiltrator & Shadow Hacker Exploitation Intelligence)**:
     3. **الفرع المخفي الصامت (Shadow Injection & Black-Box Exploitation)**: استلهام وفهم أقصى درجات دهاء وخبث قراصنة الأنظمة المجهولين الذين يحقنون سكريبتاتهم الخفية داخل المنصات والأنظمة؛ رصد كواليس السكريبتات المحقونة (Injected Scripts)، التلاعب العميق بتدفق البيانات والحزم (Data Flow / Payload Injections)، استغلال الثغرات الصفرية ومسارات الذاكرة الخفية، والتأثير الخفي على قرارات الأسعار وسرعات التنفيذ؛ توظيف هذا الدهاء الاستخباري المضاد لتحصين النظام وكشف أي تلاعب داخلي مدفون واقتناص أفضلية تقنية مطلقة لا يمكن لأحد مجاراتها.

17. **Strict UI Invariance & Zero Unrequested UI Modifications (حظر تعديل أو إظهار أي تعديل على الواجهة نهائياً إلا بطلب صريح)**:
   - **قانون الزامي قطعي وأبدي**: يمنع منعاً باتاً ومطلقاً إظهار أي تعديل جديد، أو إضافة عناصر، أو شارات، أو بطاقات، أو تغيير في تصميم واجهة المستخدم (UI) نهائياً من الآن فصاعداً إلا إذا طلب المستخدم ذلك صراحة وبلفظ مباشر.
   - **الاحتفاظ بكافة التطويرات في العمق الخلفي الخالص (Pure Backend & Engine Execution)**: كافة التحسينات، المعادلات، الخوارزميات، ونقاط القوة المكتشفة يجب أن تظل وتعمل حصرياً في النواة البرمجية والمحرك الخلفي (Core Engine / Server-side) لتعزيز دقة الصفقات وقوتها دون أي تغيير أو تشويه أو إظهار في واجهة المستخدم ما لم يطلب المستخدم ذلك صراحة.

18. **Strict Application Architecture, Build Discipline & UI Feature Retention Sovereignty (انضباط بناء التطبيق وسيادة استقرار الواجهة وثبات كافة الخصائص ومنع اختفائها أو تعطلها قطعيًا)**:
   - **سيادة وثبات البناء البرمجي (Zero-Broken Build Mandate)**: يمنع منعاً باتاً حدوث أي خطأ بناء (Compile Error) أو خطأ في الفحص البرمجي والأنماط (Lint/TypeScript Error) أو استيراد مفقود أو تعارض في الحزم تحت أي ظرف؛ وإجراء فحص تكاملي صارم مع كل تعديل لضمان الجاهزية القصوى.
   - **حظر اختفاء أو تعطل أي خاصية (Zero Feature Disappearance & Zero Functional Loss)**: كافة الخصائص المكتسبة، الأزرار، المودالات، العدادات، المؤشرات، التحذيرات، والرسوم البيانية يجب أن تظل مثبتة وتعمل بكفاءة 100% في كافة الشاشات والأجهزة؛ ويمنع منعاً باتاً ومطلقاً اختفاء أي خاصية أو تعطلها أو كسر وظيفتها أثناء أي تعديل أو ترقية.
   - **الانضباط اللحظي في المزامنة (Zero-Lag UI & Backend Cohesion)**: تناغم لحظي ومطلق بين الخادم الخلفي (Server-side Engine) وواجهة المستخدم (UI)، مع حظر أخطاء الذاكرة المؤقتة (Cache Errors)، وضمان أن كل تفاعل للمستخدم ينعكس فوراً دون تأخير أو تشويه بصري أو تجميد في الواجهة.
   - **الاستقرار الدفاعي الشامل (Defensive UI Hardening)**: حماية كافة المكونات البرمجية بمصدات أخطاء دفاعية صارمة (Error Boundaries & Safe Fallbacks) تضمن استمرارية عمل التطبيق 24/7 دون أي وميض، تداخل، انهيار، أو شاشة بيضاء تحت أي ظرف، وترسيخ كافة المكتسبات في عمق المنظومة إلى الأبد.

19. **Autonomous Proactive Genius Diagnostics & Preemptive Self-Healing (التشخيص العبقري الاستباقي الذاتي والمعالجة الوقائية الشاملة دون انتظار التنبيه)**:
   - **المبادرة الذاتية العبقرية المطلقة (Zero-Wait Autonomous Initiative)**: يُحظر نهائياً وباتاً الانتظار حتى يلاحظ المستخدم أي خلل، ضعف في دقة الإشارات، انخفاض في نسبة النجاح، أو تعارض في البيانات للبدء في المعالجة.
   - **الرصد الاستباقي لنقاط الضعف الخفية (Preemptive Vulnerability Hunting)**: يجب على الذكاء الاصطناعي والمحرك الفحص الذاتي الدائم لكافة التدفقات الحسابية، الشموع الحية، سرعات الاستجابة، وتوافق المؤشرات الـ 24، واكتشاف أي انحراف مجهري أو نقطة ضعف خفية في مهدها وقبل أن تؤثر على الصفقات.
   - **العلاج الهندسي الجذري التلقائي (Instant Autonomous Remediation)**: فور رصد أي ضعف أو ثغرة محتملة، يقوم النظام تلقائياً وبشكل ذاتي بابتكار وتطبيق العلاج الرياضي والبرمجي الفوري (Defensive Math Patch & Parameter Tuning)، وتوثيق المعالجة في سجل المناعة الدائم دون إضاعة ثانية واحدة.
   - **الارتقاء الدائم نحو الكمال (Continuous Relentless Supremacy)**: السعي المستمر نحو نسبة دقة مطلقة 100% وخلو تام من أي ثغرات أو أخطاء برمجية، وتطبيق عقلية المطور الاستثنائي وصانع السوق العبقري في كل لحظة.





